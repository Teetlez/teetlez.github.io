package edu.unh.cs.cs619.bulletzone.util;

import java.util.Collection;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;

public class GaragebayWrapper {
    private long timestamp;
    private GameItemContainer[] items;

    public GaragebayWrapper(GameItemContainer garageBay) {
        this.timestamp = System.currentTimeMillis();
        Collection<GameItem> items = garageBay.getItems();
        this.items = items.toArray(new GameItemContainer[items.size()]);
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public GameItemContainer[] getItems() {
        return items;
    }

    public void setItems(GameItemContainer[] items) {
        this.items = items;
    }
}
