package edu.unh.cs.cs619.bulletzone.repository;

import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.IllegalTransitionException;
import edu.unh.cs.cs619.bulletzone.model.LimitExceededException;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.TankDoesNotExistException;

public interface GameRepository {

    Vehicle join(int presetId, String ip);

    int[][] getGrid(long playerId);

    int[][] getTerrainGrid();

    Vehicle getVehicle(long vehicleId);

    boolean turn(long vehicleId, Direction direction)
            throws TankDoesNotExistException, IllegalTransitionException, LimitExceededException;

    boolean move(long vehicleId, Direction direction)
            throws TankDoesNotExistException, IllegalTransitionException, LimitExceededException;

    boolean fire(long vehicleId, int strength)
            throws TankDoesNotExistException, LimitExceededException;

    boolean eject(long vehicleId, int preset) throws TankDoesNotExistException;

    public void leave(long vehicleId)
            throws TankDoesNotExistException;

    long getScore(long vehicleID);
}
