package edu.unh.cs.cs619.bulletzone.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Optional;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.repository.SingletonMonitor;

public final class Game {
    private static Game instance = new Game();

    // Game settings
    public static final int FIELD_DIM = 16;
    public static final int BULLET_PERIOD = 200;

    private final long id;
    private final ArrayList<FieldHolder> holderGrid = new ArrayList<>();

    private final ConcurrentMap<Long, Vehicle> vehicles = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Long> playersIP = new ConcurrentHashMap<>();
    private final ConcurrentMap<Long, Long> playersScore = new ConcurrentHashMap<>();
    private ArrayList<Bullet> bullets = new ArrayList<>();

    private final Timer timer = new Timer();

    private Game() {
        this.id = 0;
        create();
    }

    /**
     * Get the current instance for Game.
     * @return Game instance;
     */
    public static Game getInstance() {
        return instance;
    }

    /**
     * Creates a new game and stores it as the instance for the singleton.
     * @return New game instance;
     */
    public static Game newGame() {
        instance = new Game();
        return instance;
    }

    @JsonIgnore
    public long getId() {
        return id;
    }

    @JsonIgnore
    public ArrayList<FieldHolder> getHolderGrid() {
        return holderGrid;
    }

    public ArrayList<Bullet> getBullets() {
        return bullets;
    }

    public void addVehicle(String ip, Vehicle vehicle, long score) {
        synchronized (vehicles) {
            vehicles.put(vehicle.getId(), vehicle);
            playersIP.put(ip, vehicle.getId());
            playersScore.put(vehicle.getId(), score);
        }
    }

    public Vehicle getVehicle(long vehicleId) {
        return vehicles.get(vehicleId);
    }

    public ConcurrentMap<Long, Vehicle> getVehicles() {
        return vehicles;
    }

    public List<Optional<FieldEntity>> getGrid() {
        synchronized (holderGrid) {
            List<Optional<FieldEntity>> entities = new ArrayList<Optional<FieldEntity>>();

            FieldEntity entity;
            for (FieldHolder holder : holderGrid) {
                if (holder.isPresent()) {
                    entity = holder.getEntity();
                    entity = entity.copy();

                    entities.add(Optional.<FieldEntity>of(entity));
                } else {
                    entities.add(Optional.<FieldEntity>empty());
                }
            }
            return entities;
        }
    }

    public Vehicle getVehicle(String ip){
        if (playersIP.containsKey(ip)){
            return vehicles.get(playersIP.get(ip));
        }
        return null;
    }

    public void removeVehicle(long vehicleId){
        synchronized (vehicles) {
            Vehicle t = vehicles.remove(vehicleId);
            if (t != null) {
                playersIP.remove(t.getIp());
                playersScore.remove(vehicleId);
            }
        }
    }

    public void gainOrLostScore(long vehicleID, long value) {
        playersScore.put(vehicleID, getScore(vehicleID) + value);
    }

    public long getScore(long vehicleID) {
        if (playersScore.containsKey(vehicleID)) {
            return playersScore.get(vehicleID);
        }
        return -1;
    }

    public int[][] getGrid2D(long playerId) {
        int[][] grid = new int[FIELD_DIM][FIELD_DIM];

        synchronized (holderGrid) {
            FieldHolder holder;
            for (int i = 0; i < FIELD_DIM; i++) {
                for (int j = 0; j < FIELD_DIM; j++) {
                    holder = holderGrid.get(i * FIELD_DIM + j);
                    FieldEntity entity = holder.isPresent() ? holder.getEntity() : null;
                    int terrainID = holder.getTerrain().getID();
                    boolean hideable = (terrainID == 902 || terrainID == 1001 || terrainID == 2);
                    if (hideable && entity instanceof Vehicle) {
                        grid[i][j] = ((Vehicle) entity).getId() == playerId ?
                                holder.getEntity().getIntValue() : 0;
                    } else {
                        grid[i][j] = entity != null ? entity.getIntValue() : 0;
                    }
                }
            }
        }

        return grid;
    }

    /**
     * Fill the terrain map with terrain ID
     */
    public int[][] getTerrainGrid() {
        int [][] terrainGrid = new int[FIELD_DIM][FIELD_DIM];

        synchronized (holderGrid) {
            for (int i = 0; i < FIELD_DIM; i++) {
                for (int j = 0; j < FIELD_DIM; j++) {
                    terrainGrid[i][j] = holderGrid.get(i * FIELD_DIM + j).getTerrainID();
                }
            }
        }
        return terrainGrid;
    }

    /**
     * Create the game map
     */
    public void create() {
        synchronized (SingletonMonitor.getMonitor()) {
            createFieldHolderGrid();

            // map the terrain type
            for (int i = 0; i < FIELD_DIM * FIELD_DIM; i++) {
                if (i >= 96 && i <= 111 || i >= 128 && i <= 143) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, i));
                    holderGrid.get(i).setTerrainID(900);
                } else if ((i >= 164 && i <= 175) || (i >= 180 && i <= 191)) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Coast, i));
                    holderGrid.get(i).setTerrainID(40);
                } else if ((i >= 196 && i <= 207) || (i >= 212 && i <= 223) ||
                        (i >= 228 && i <= 239) || (i >= 244 && i <= 255)) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.OpenWater, i));
                    holderGrid.get(i).setTerrainID(50);
                } else if ((i >= 12 && i <= 15) || (i >= 28 && i <= 31) ||
                        (i >= 44 && i <= 47) || (i >= 60 && i <= 63)) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Forest, i));
                    holderGrid.get(i).setTerrainID(2);
                } else if ((i >= 160 && i <= 163) || i == 179 ||
                        i == 195 || i == 211 || i == 227 || i == 243) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Fortification, i));
                    holderGrid.get(i).setTerrainID(1001);
                } else if (i == 192 || i == 209 || i == 226 || i == 194 ||
                        i == 224 || i == 114 || i == 119 || i == 125) {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Building, i));
                    holderGrid.get(i).setTerrainID(902);
                } else {
                    holderGrid.get(i).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, i)); // Default terrain
                }
            }

            // Test // TODO XXX Remove & integrate map loader
            int [] wall = new int[]{1, 2, 3, 17 , 34, 35, 51, 5 , 21, 37, 53, 7, 23, 39, 8, 40, 72, 9, 25, 41, 57, 73};
            for (int pos: wall) {
                holderGrid.get(pos).setFieldEntity(new Terrain(BulletZoneData.getInstance().terrains.Wall, pos));
                holderGrid.get(pos).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Wall, pos));
                holderGrid.get(pos).setTerrainID(1000);
            }

            int [] destroyableWall = new int[]{33 , 49, 65, 66, 67, 69, 71, 72};
            for (int pos: destroyableWall) {
                holderGrid.get(pos).setFieldEntity(new Terrain(BulletZoneData.getInstance().terrains.IndestructibleWall, pos));
                holderGrid.get(pos).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.IndestructibleWall, pos));
                holderGrid.get(pos).setTerrainID(2000);
            }
        }
    }


    /**
     * Fill the map with items
     */
    private void createFieldHolderGrid() {
        synchronized (SingletonMonitor.getMonitor()) {
            holderGrid.clear();
            for (int i = 0; i < FIELD_DIM * FIELD_DIM; i++) {
                holderGrid.add(new FieldHolder(i));
            }

            FieldHolder targetHolder;
            FieldHolder rightHolder;
            FieldHolder downHolder;

            // Build connections
            for (int i = 0; i < FIELD_DIM; i++) {
                for (int j = 0; j < FIELD_DIM; j++) {
                    targetHolder = holderGrid.get(i * FIELD_DIM + j);
                    rightHolder = holderGrid.get(i * FIELD_DIM
                            + ((j + 1) % FIELD_DIM));
                    downHolder = holderGrid.get(((i + 1) % FIELD_DIM)
                            * FIELD_DIM + j);

                    targetHolder.addNeighbor(Direction.Right, rightHolder);
                    rightHolder.addNeighbor(Direction.Left, targetHolder);

                    targetHolder.addNeighbor(Direction.Down, downHolder);
                    downHolder.addNeighbor(Direction.Up, targetHolder);
                }
            }
        }
    }

    public Timer getTimer() {
        return timer;
    }

    /**
     * Get a vehicle entity at a given position.
     * @param position Position in the board.
     * @return Vehicle entity, otherwise null.
     */
    public Vehicle getVehicleAtPosition(int position) {
        try {
            FieldHolder fieldHolder = holderGrid.get(position);
            FieldEntity entity = fieldHolder.getEntity();
            if (entity instanceof Vehicle) return (Vehicle) entity;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
