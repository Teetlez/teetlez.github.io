package edu.unh.cs.cs619.bulletzone.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.ItemProperty;
import edu.unh.cs.cs619.bulletzone.datalayer.TerrainType;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.IllegalTransitionException;
import edu.unh.cs.cs619.bulletzone.model.LimitExceededException;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.TankDoesNotExistException;
import edu.unh.cs.cs619.bulletzone.repository.GameRepository;
import edu.unh.cs.cs619.bulletzone.repository.HistoryRepository;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.GridEventWrapper;
import edu.unh.cs.cs619.bulletzone.util.GridWrapper;
import edu.unh.cs.cs619.bulletzone.util.LongWrapper;
import edu.unh.cs.cs619.bulletzone.util.StringArrayWrapper;

@RestController
@RequestMapping(value = "/games")
class GamesController {

    private static final Logger log = LoggerFactory.getLogger(GamesController.class);

    private final GameRepository gameRepository;

    @Autowired
    public GamesController(GameRepository gameRepository) {
        this.gameRepository = gameRepository;
    }

    @RequestMapping(method = RequestMethod.POST, value = "join/{preset}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    @ResponseBody
    ResponseEntity<LongWrapper> join(HttpServletRequest request, @PathVariable int preset) {
        Vehicle vehicle;
        try {
            vehicle = gameRepository.join(preset, request.getRemoteAddr());
            log.info("Player joined: vehicleId={} IP={}", vehicle.getId(), request.getRemoteAddr());

            return new ResponseEntity<LongWrapper>(
                    new LongWrapper(vehicle.getId()),
                    HttpStatus.CREATED
            );
        } catch (RestClientException e) {
            e.printStackTrace();
        }
        return null;
    }

    @RequestMapping(method = RequestMethod.GET, value = "{vehicleID}/score", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<LongWrapper> getUserScore(@PathVariable long vehicleID)
    {
        // Log the request
        log.debug("getUserScore '" + vehicleID);

        return new ResponseEntity<LongWrapper>(new LongWrapper(gameRepository.getScore(vehicleID)), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.GET, value = "{playerId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    ResponseEntity<GridWrapper> grid(@PathVariable long playerId) {
        return new ResponseEntity<GridWrapper>(new GridWrapper(gameRepository.getGrid(playerId),
                gameRepository.getTerrainGrid()), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.GET, value = "terrainType/{terrainID}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    ResponseEntity<StringArrayWrapper> terrainType(@PathVariable int terrainID) {
        // Log the request
        log.debug("getTerrainType '" + terrainID + "'");
        TerrainType terrain = BulletZoneData.getInstance().terrains.get(terrainID);

        Collection<String> string = new ArrayList<>();
        string.add("Name: " + terrain.getName());
        string.add("Solid: " + terrain.isSolid());
        string.add("Liquid: " + terrain.isLiquid());
        string.add("Difficulty: " + terrain.getDifficulty());
        string.add("MaxSize: " + terrain.getMaxSize());
        string.add("Strength: " + terrain.getStrength());
        string.add("Hardness: " + terrain.getHardness());
        string.add("Damage: " + terrain.getDamage());
        return new ResponseEntity<>(new StringArrayWrapper(string.toArray(new String[string.size()])), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.GET, value = "history/{playerId}/{timestamp}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.OK)
    @ResponseBody
    ResponseEntity<GridEventWrapper> history(@PathVariable long timestamp, @PathVariable int playerId) {
        return new ResponseEntity<GridEventWrapper>(new GridEventWrapper(HistoryRepository
                .getInstance().getEventData(timestamp, playerId)), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{vehicleId}/turn/{direction}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<BooleanWrapper> turn(@PathVariable long vehicleId, @PathVariable byte direction)
            throws TankDoesNotExistException, LimitExceededException, IllegalTransitionException {
        return new ResponseEntity<BooleanWrapper>(
                new BooleanWrapper(gameRepository.turn(vehicleId, Direction.fromByte(direction))),
                HttpStatus.ACCEPTED
        );
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{vehicleId}/move/{direction}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<BooleanWrapper> move(@PathVariable long vehicleId, @PathVariable byte direction)
            throws TankDoesNotExistException, LimitExceededException, IllegalTransitionException {
        return new ResponseEntity<BooleanWrapper>(
                new BooleanWrapper(gameRepository.move(vehicleId, Direction.fromByte(direction))),
                HttpStatus.ACCEPTED
        );
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{vehicleId}/fire", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<BooleanWrapper> fire(@PathVariable long vehicleId)
            throws TankDoesNotExistException, LimitExceededException {
        return new ResponseEntity<BooleanWrapper>(
                new BooleanWrapper(gameRepository.fire(vehicleId, 1)),
                HttpStatus.ACCEPTED
        );
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{vehicleId}/eject/{preset}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<BooleanWrapper> eject(@PathVariable long vehicleId, @PathVariable int preset)
            throws TankDoesNotExistException, LimitExceededException {
        return new ResponseEntity<BooleanWrapper>(
                new BooleanWrapper(gameRepository.eject(vehicleId, preset)),
                HttpStatus.ACCEPTED
        );
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{vehicleId}/fire/{bulletType}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<BooleanWrapper> fire(@PathVariable long vehicleId, @PathVariable int bulletType)
            throws TankDoesNotExistException, LimitExceededException {
        return new ResponseEntity<BooleanWrapper>(
                new BooleanWrapper(gameRepository.fire(vehicleId, bulletType)),
                HttpStatus.ACCEPTED
        );
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "{vehicleId}/leave", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    HttpStatus leave(@PathVariable long vehicleId)
            throws TankDoesNotExistException {
        //System.out.println("Games Controller leave() called, tank ID: "+vehicleId);
        gameRepository.leave(vehicleId);
        return HttpStatus.ACCEPTED;
    }

    @RequestMapping(method = RequestMethod.GET, value = "{position}/stats", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    ResponseEntity<StringArrayWrapper> stats(@PathVariable int position) throws TankDoesNotExistException {
        try {
            Vehicle vehicle = Game.getInstance().getVehicleAtPosition(position);
            ArrayList<String> properties = new ArrayList<>();
            for (ItemProperty property : BulletZoneData.getInstance().properties.getAll()) {
                double propertyValue = vehicle.getEquipment().getProperty(property);
                if (propertyValue <= 0) continue;
                properties.add(property.getName() + ": " + propertyValue);
            }

            return new ResponseEntity<>(new StringArrayWrapper(properties.toArray(new String[0])),
                    HttpStatus.ACCEPTED);
        } catch(Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(new StringArrayWrapper(new String[0]), HttpStatus.ACCEPTED);
        }

    }

    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    String handleBadRequests(Exception e) {
        return e.getMessage();
    }
}
