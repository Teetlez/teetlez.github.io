package edu.unh.cs.cs619.bulletzone.model;

public enum VehicleType {
    TANK(1), TRUCK(2), SHIP(3), SOLDIER(4);

    // Represents what starting number to set when getting int value of vehicle
    private final int number;

    VehicleType(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

    /**
     * Get a vehicle type from the frame name.
     * @param itemType String for item type.
     * @return Corresponding vehicle type.
     */
    public static VehicleType fromType(String itemType) {
        switch (itemType) {
            case "Standard tank frame":
                return TANK;
            case "Standard truck frame":
                return TRUCK;
            case "Standard ship frame":
                return SHIP;
            case "Standard battle suit":
                return SOLDIER;
        }
        return null;
    }
}
