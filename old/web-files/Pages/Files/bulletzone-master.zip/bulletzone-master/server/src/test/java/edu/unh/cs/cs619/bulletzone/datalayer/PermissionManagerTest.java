package edu.unh.cs.cs619.bulletzone.datalayer;

import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Set;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

public class PermissionManagerTest {

    static BulletZoneData db;
    static GameUser basicUser;

    @BeforeClass
    static public void setup() {
        db = new BulletZoneData();
        db.rebuildData();
        basicUser = db.users.createUser("BasicUser", "BasicUser", "password");
    }

    @Test
    public void setOwner_onValidItem_updatesInternalStructures() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.setOwner(tank, basicUser);
        assertThat(basicUser.getOwnedItems().contains(tank), is(true));

        db.permissions.removeOwner(tank);
    }

    @Test
    public void removeOwner_onValidItem_updatesInternalStructures() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.setOwner(tank, basicUser);

        db.permissions.removeOwner(tank);
        assertThat(basicUser.getOwnedItems().contains(tank), is(false));
        assertThat(db.permissions.getUserPermissions(basicUser).getItems().size(), is(0));
    }

    @Test
    public void grant_OnValidPermission_updatesInternalStructures() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Add);
        assertThat(db.permissions.check(tank, basicUser, Permission.Add), is(true));
        db.permissions.revoke(tank, basicUser, Permission.Add);

    }

    @Test
    public void revoke_OnValidPermission_updatesInternalStructures() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Add);

        db.permissions.revoke(tank, basicUser, Permission.Add);
        assertThat(db.permissions.check(tank, basicUser, Permission.Add), is(false));

        assertThat(db.permissions.getUserPermissions(basicUser).getItems().size(), is(0));
    }

    @Test
    public void getItemPermissions_owner_returnsOwnerId() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);

        Set<Integer> users = db.permissions.getItemPermissions(tank.getItemID()).getUsers();

        assertTrue("Owner should show up when getting item permissions",
                users.contains(basicUser.userID));

        db.permissions.revoke(tank, basicUser, Permission.Owner);
    }

    @Test
    public void getItemPermissions_afterRemoving_returnsEmpty() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);

        Set<Integer> users = db.permissions.getItemPermissions(tank.getItemID()).getUsers();
        System.out.printf("Item has %d users with permissions\n", users.size());

        db.permissions.revoke(tank, basicUser, Permission.Owner);
        System.out.println("Revoked...");
        System.out.printf("Item has %d users with permissions\n", users.size());

        assertFalse("Owner should show up when getting item permissions",
                users.contains(basicUser.userID));
    }

    @Test
    public void getItemPermissions_multiple_returnsAll() {
        GameUser user = db.users.createUser("test2", "test2", "test2");
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);
        db.permissions.grant(tank, user, Permission.Use);

        Set<Integer> users = db.permissions.getItemPermissions(tank.getItemID()).getUsers();
        System.out.printf("Item has %d users with permissions\n", users.size());

        assertTrue("Item should have both users show up",
                users.contains(basicUser.userID) && users.contains(user.userID));

        db.permissions.revoke(tank, basicUser, Permission.Owner);
        db.permissions.revoke(tank, user, Permission.Use);
    }

    @Test
    public void getItemPermissions_multipleDeletedOne_returnsOne() {
        GameUser user = db.users.createUser("test3", "test3", "test3");
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);
        db.permissions.grant(tank, user, Permission.Use);

        Set<Integer> users = db.permissions.getItemPermissions(tank.getItemID()).getUsers();
        System.out.printf("Item has %d users with permissions\n", users.size());

        System.out.println("Revoking...");
        db.permissions.revoke(tank, user, Permission.Use);
        System.out.printf("Item has %d users with permissions\n", users.size());

        assertTrue("Item should have only owner show up",
                users.contains(basicUser.userID) && !users.contains(user.userID));

        db.permissions.revoke(tank, basicUser, Permission.Owner);
    }

    @Test
    public void getItemPermissions_noPermissions_returnsNone() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        Set<Integer> users = db.permissions.getItemPermissions(tank.getItemID()).getUsers();
        assertEquals(0, users.size());
    }

    @Test
    public void getItemPermissions_oneUserMultiplePermissions_oneUser() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);
        db.permissions.grant(tank, basicUser, Permission.Add);
        assertEquals(1, db.permissions.getItemPermissions(tank.getItemID())
                .getUsers().size());

        db.permissions.revoke(tank, basicUser, Permission.Owner);
        db.permissions.revoke(tank, basicUser, Permission.Add);
    }

    @Test
    public void getItemPermissions_oneRevokedOutOfMany_oneUserRemains() {
        GameItemContainer tank = db.items.createContainer(db.types.TankFrame);
        db.permissions.grant(tank, basicUser, Permission.Owner);
        db.permissions.grant(tank, basicUser, Permission.Add);
        System.out.printf("Item has %d user with permission\n",
                db.permissions.getItemPermissions(tank.getItemID()).getUsers().size());

        db.permissions.revoke(tank, basicUser, Permission.Add);
        System.out.printf("Item has %d user with permission\n",
                db.permissions.getItemPermissions(tank.getItemID()).getUsers().size());

        assertEquals(1, db.permissions.getItemPermissions(tank.getItemID())
                .getUsers().size());

        db.permissions.revoke(tank, basicUser, Permission.Owner);
    }
}