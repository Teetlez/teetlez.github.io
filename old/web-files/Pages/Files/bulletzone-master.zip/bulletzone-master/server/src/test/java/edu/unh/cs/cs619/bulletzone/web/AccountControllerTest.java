package edu.unh.cs.cs619.bulletzone.web;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.repository.InMemoryGameRepository;
import edu.unh.cs.cs619.bulletzone.util.StringArrayWrapper;

import static org.junit.Assert.*;

public class AccountControllerTest {
    private AccountController ac;

    @Before
    public void setUp() {
        BulletZoneData.enableTestMode();
        InMemoryGameRepository inMemoryGameRepository = new InMemoryGameRepository();
        BulletZoneData bzd = new BulletZoneData();

        ac = new AccountController(bzd);
    }

    @Test
    public void getCategory_returnsList() {
        ResponseEntity<StringArrayWrapper> category = ac.getCategory();
        StringArrayWrapper body = category.getBody();
        String[] categoryNames = body.getGrid();
        assertTrue("Category list should be greater than 0",
                categoryNames.length > 0);
    }

    @Test
    public void getItem_FromCategory_ReturnsItems() {
        String[] categories = ac.getCategory().getBody().getGrid();
        ArrayList<String> itemNames = new ArrayList<>();
        for (String category : categories) {
            System.out.println("Grabbing items from category: " + category);
            String[] items = ac.getItem(category).getBody().getGrid();
            for (String item : items) {
                System.out.println("\t" + item);
                itemNames.add(item);
            }
        }

        assertTrue("Items retrieved should be greater than 0",
                itemNames.size() > 0);
    }

    @Test
    public void getItemStatus_FromItem_ReturnsItemStatus() {
        String[] properties = ac.getItemWithName("Standard tank engine").getBody().getGrid();
        ArrayList<String> itemNames = new ArrayList<>();
        System.out.println("Grabbing items property for Standard tank engine: ");
        for (String property : properties) {
            System.out.println(property);
        }

        assertTrue("Items property count should be greater than 0",
                properties.length > 0);
    }


    @Test(expected=NullPointerException.class)
    public void getItemStatus_FromWrongItem_ReturnsNothing() throws Exception{
        String[] properties = ac.getItemWithName("incorrect").getBody().getGrid();
    }

    @Test
    public void getItem_WrongCategory_ReturnsNothing() {
        String[] items = this.ac.getItem("incorrect").getBody().getGrid();

        assertTrue("Items retrieved should be 0",
                items.length == 0);
    }

    @Test
    public void reqRegisterNew_NewAccount_Pass() {
        boolean result = this.ac.reqRegisterNew("newaccount", "password")
                .getBody().isResult();
        assertTrue("Registering new account works", result);
    }

    @Test
    public void reqRegisterNew_ExistingAccount_Fails() {
        this.ac.reqRegisterNew("existingaccount", "password");
        boolean result = this.ac.reqRegisterNew("existingaccount", "password")
                .getBody().isResult();
        assertFalse("Registering an existing account should fail", result);
    }

    @Test
    public void reqLogin_RealAccount_Works() {
        this.ac.reqRegisterNew("realaccount", "password");
        long result = this.ac.reqLogin("realaccount", "password")
                .getBody().getResult();
        assertTrue("Logging into an existing account should work",
                result > -1);
    }

    @Test
    public void reqLogin_IncorrectPassword_Fails() {
        this.ac.reqRegisterNew("incorrect", "password");
        long result = this.ac.reqLogin("incorrect", "password2")
                .getBody().getResult();
        assertTrue("Logging in with wrong password shouldn't work",
                result == -1);
    }
}