package edu.unh.cs.cs619.bulletzone.repository;

import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;

import static org.junit.Assert.*;

public class GaragebayRepositoryTest {
    // Used to make new users per test
    private static int counter = 0;

    private GaragebayRepository garagebayRepository;
    private BulletZoneData bulletZoneData;

    @Before
    public void setUp() throws Exception {
        bulletZoneData = new BulletZoneData();
        garagebayRepository = new GaragebayRepository(bulletZoneData);
        bulletZoneData.rebuildData();
    }

    @Test
    public void addContainerToGarageBay_MultipleContainers_Exist() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");

        // Empty presets
        garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());
        garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TruckFrame.getName());
        garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.ShipFrame.getName());

        GameItemContainer garageBay = garagebayRepository.getGarageBay(user.getUserID());

        System.out.printf("[TEST] Checking contents of garage bay...\n");
        for (GameItem item : garageBay.getItems()) {
            System.out.printf("[TEST] Item found: %s\n", item);
        }
        assertTrue("Garage bay should contain multiple containers",
                garageBay.getItems().size() > 0);
    }

    @Test
    public void addContainerToGarageBay_SameContainers_Exist() {
        int presetAmount = 500;

        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");

        // Empty presets
        for (int i = 0; i < presetAmount; i++) {
            garagebayRepository.addContainerToGarageBay(user.getUserID(),
                    bulletZoneData.types.TankFrame.getName());
        }

        GameItemContainer garageBay = garagebayRepository.getGarageBay(user.getUserID());

        System.out.printf("[TEST] Checking contents of garage bay...\n");
        for (GameItem item : garageBay.getItems()) {
            System.out.printf("[TEST] Item found: %s\n", item);
        }
        assertTrue("Garage bay should contain multiple containers",
                garageBay.getItems().size() == presetAmount);
    }

    @Test
    public void addContainerToGarageBay_AddGarageBay_ShouldFail() {
        GameUser user = bulletZoneData.users
                .createUser("user", "addgaragebay" + counter++, "pass");

        int id = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.GarageBay.getName());

        assertTrue("Should not be allowed to add a garage bay to the garage bay",
                id == -1);
    }

    @Test
    public void removeContainerFromGarageBay_OneItem_EmptyBay() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");

        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());

        GameItemContainer garageBay = garagebayRepository.getGarageBay(user.getUserID());

        System.out.printf("[TEST] Garage bay has %d item\n", garageBay.getItems().size());
        garagebayRepository.removeContainerFromGarageBay(user.getUserID(), container);
        System.out.printf("[TEST] Deleted item %d from garage bay\n", container);
        System.out.printf("[TEST] Garage bay has %d item\n", garageBay.getItems().size());
        assertTrue("Garage bay should be empty after deleting the only item",
                garageBay.getItems().size() == 0);
    }

    @Test
    public void removeContainerFromGarageBay_EmptyContainer_Fails() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");

        boolean result = garagebayRepository.removeContainerFromGarageBay(user.getUserID(), -1);
        assertFalse("Removing a nonexistent container from a garage bay should not work",
                result);
    }

    @Test
    public void removeContainerFromGarageBay_NoContainerRelationship_Fails() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");

        GameItemContainer container = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);

        boolean result = garagebayRepository.removeContainerFromGarageBay(user.getUserID(),
                container.getItemID());
        assertFalse("Removing a container from unassociated bay should not work",
                result);
    }

    @Test
    public void removeContainerFromGarageBay_FilledContainer_NoItemLeaks() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());

        System.out.printf("[TEST] Adding items to container %d\n", container);
        ArrayList<Integer> itemIDs = new ArrayList<>();
        itemIDs.add(garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TankCannon.getName()));
        itemIDs.add(garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TankDriveTracks.getName()));
        itemIDs.add(garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TankEngine.getName()));

        for (Integer itemID : itemIDs) {
            System.out.printf("[TEST] Vehicle frame %d contains item %d\n", container, itemID);
        }

        garagebayRepository.removeContainerFromGarageBay(user.getUserID(), container);

        System.out.println("[TEST] Removed container from garage bay");
        System.out.println("[TEST] Checking for leaked items...");

        for (Integer itemID : itemIDs) {
            System.out.printf("[TEST] Checking leak for item %d\n", itemID);
            GameItem item = bulletZoneData.items.getItem(itemID);
            assertTrue(item == null);
        }

    }

    @Test
    public void removeContainerFromGarageBay_RemoveGarageBay_Fails() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        GameItemContainer garageBay = garagebayRepository.getGarageBay(user.getUserID());
        boolean b = garagebayRepository.removeContainerFromGarageBay(user.getUserID(),
                garageBay.getItemID());
        assertFalse("Removing garage bay from garage bay should return false", b);
    }

    @Test
    public void removeItemFromContainer_OneItem_EmptyContainer() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());

        int item = garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TankCannon.getName());

        GameItemContainer containerObj = bulletZoneData.items.getContainer(container);
        int initial = containerObj.getItems().size();

        garagebayRepository.removeItemFromContainer(item, container);

        assertTrue("Deleting the only item in a container should make it empty",
                initial != 0 && containerObj.getItems().size() == 0);
    }

    @Test
    public void addItemToContainer_MultipleItems_Works() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());
        GameItemContainer itemsContainer = bulletZoneData.items.getContainer(container);

        for (int i = 0; i < 10; i++) {
            garagebayRepository.addItemToContainer(container,
                    bulletZoneData.types.TankCannon.getName());
        }

        assertTrue("Container should have multiple items",
                itemsContainer.getItems().size() > 0);
    }

    @Test
    public void addItemToContainer_NestedGarageBay_Fails() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TankFrame.getName());
        GameItemContainer itemsContainer = bulletZoneData.items.getContainer(container);

        int id = garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.GarageBay.getName());

        assertTrue("Garage bay should not be added to a container",
                id == -1);
    }

    @Test
    public void addItemToContainer_EnoughWeight_ReturnsTrue() {
        GameUser user = bulletZoneData.users
                .createUser("user", "226" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TruckFrame.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckEngine.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckDriveTracks.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckGenerator.getName());

        GameItemContainer container1 = bulletZoneData.items.getContainer(container);
        assertEquals("Truck frame should have 3 items", 3,
                container1.getItems().size());
    }

    @Test
    public void addItemToContainer_TooMuchWeight_ReturnsFalse() {
        GameUser user = bulletZoneData.users
                .createUser("user", "user" + counter++, "pass");
        int container = garagebayRepository.addContainerToGarageBay(user.getUserID(),
                bulletZoneData.types.TruckFrame.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckEngine.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckDriveTracks.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckGenerator.getName());

        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.PlasmaCannon.getName());

        // This should fail
        garagebayRepository.addItemToContainer(container,
                bulletZoneData.types.TruckEngine.getName());

        GameItemContainer container1 = bulletZoneData.items.getContainer(container);
        assertEquals("Truck frame should have 4 items", 4,
                container1.getItems().size());

    }
}