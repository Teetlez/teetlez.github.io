package edu.unh.cs.cs619.bulletzone.repository;

import org.springframework.stereotype.Component;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.IllegalTransitionException;
import edu.unh.cs.cs619.bulletzone.model.LimitExceededException;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.TankDoesNotExistException;
import edu.unh.cs.cs619.bulletzone.model.VehicleType;

import static com.google.common.base.Preconditions.checkNotNull;

@Component
public class InMemoryGameRepository implements GameRepository {

    private final AtomicLong idGenerator = new AtomicLong();
    private Game game = Game.newGame();

    /**
     * Let the vehicle join the game map
     *
     * @param presetId ID of the container (frame) that contains the items. -1 if none.
     * @param ip The ip for the vehicle
     * @return True if the vehicle is allowed to join.
     */
    @Override
    public Vehicle join(int presetId, String ip) {
        synchronized (SingletonMonitor.getMonitor()) {
            Vehicle vehicle;

            if ((vehicle = game.getVehicle(ip)) != null) {
                return vehicle;
            }

            Long vehicleId = this.idGenerator.getAndIncrement() + 1;

            // -2 for soldier
            // -1 for tank
            // find the data base
            GameItemContainer preset = BulletZoneData.getInstance().getPresetOrDefault(presetId);
            VehicleType vehicleType = VehicleType.fromType(preset.getTypeName());
            vehicle = new Vehicle(vehicleType, vehicleId, Direction.Up, ip);
            vehicle.setEquipment(preset);

            Random random = new Random();
            int x;
            int y;

            // This may run for forever.. If there is no free space. XXX
            for (; ; ) {
                x = random.nextInt(Game.FIELD_DIM);
                y = random.nextInt(Game.FIELD_DIM);
                FieldHolder fieldElement = game.getHolderGrid().get(x * Game.FIELD_DIM + y);
                if (CollisionHandler.handleTerrainInteraction(vehicle, fieldElement)) {
                    fieldElement.setFieldEntity(vehicle);
                    vehicle.setParent(fieldElement);
                    vehicle.getPreviousOwner().add(vehicle.getId());
                    break;
                }
            }

            game.addVehicle(ip, vehicle, 0);

            return vehicle;
        }
    }

    /**
     * Get the map in 2D array
     * @param playerId ID of the player making the request.
     * @return The 2d map
     */
    @Override
    public int[][] getGrid(long playerId) {
        return game.getGrid2D(playerId);
    }

    /**
     * Get the terrain map in 2D array
     * @return The 2d map
     */
    public int[][] getTerrainGrid() {
        return game.getTerrainGrid();
    }

    public long getScore(long vehicleID) {
        return game.getScore(vehicleID);
    }

    public void gainOrLostScore(long vehicleID, long value) {
        game.gainOrLostScore(vehicleID, value);
    }

    /**
     * Let the vehicle turn direction
     * @param vehicleId The id for the vehicle
     * @param direction Direction of vehicle turning.
     * @return True if the vehicle is allowed to turn.
     */
    @Override
    public boolean turn(long vehicleId, Direction direction)
            throws TankDoesNotExistException, IllegalTransitionException, LimitExceededException {
        synchronized (SingletonMonitor.getMonitor()) {
            checkNotNull(direction);

            // Find vehicle or soldier
            Vehicle vehicle = game.getVehicle(vehicleId);

            // return false if the validation fail
            if (!Validator.validateTurn(vehicle, direction)) return false;

            vehicle.turn(direction);

            return true;
        }
    }

    /**
     * Let the vehicle move in a direction
     * @param vehicleId The id for the vehicle
     * @param direction Direction of vehicle moving.
     * @return True if the vehicle is allowed to move.
     */
    @Override
    public boolean move(long vehicleId, Direction direction)
            throws TankDoesNotExistException, IllegalTransitionException, LimitExceededException {
        synchronized (SingletonMonitor.getMonitor()) {
            // Find vehicle or soldier
            Vehicle vehicle = game.getVehicle(vehicleId);

            // return false if the validation fail
            if (!Validator.validateMove(vehicle, direction)) return false;

            vehicle.move(direction);
            return true;
        }
    }

    /**
     * Let the vehicle fire and track of what is hit by bullet
     * @param vehicleId The id for the vehicle
     * @param bulletType Type of bullet is being fired.
     * @return True if the vehicle is allowed to fire.
     */
    @Override
    public boolean fire(long vehicleId, int bulletType)
            throws TankDoesNotExistException, LimitExceededException {
        synchronized (SingletonMonitor.getMonitor()) {
            // Find vehicle or soldier
            Vehicle vehicle = game.getVehicles().get(vehicleId);

            // return false if the validation fail
            if (!Validator.validateFire(vehicle, bulletType)) return false;
            vehicle.fire(bulletType);
            return true;
        }
    }

    /**
     * Let the vehicle eject the soldier if vehicle is not destroyed
     * and soldier have not ejected
     *
     * @param vehicleId The id for the vehicle
     * @return A position that vehicle can eject the soldier
     */
    @Override
    public boolean eject(long vehicleId, int presetId) throws TankDoesNotExistException {
        synchronized (SingletonMonitor.getMonitor()) {
            // if soldier is already ejected
            if (game.getVehicle(vehicleId).toString().equals("SOLDIER")) return false;

            Vehicle vehicle = game.getVehicles().get(vehicleId);

            // return position that can eject soldier
            FieldHolder fieldHolder = Validator.validateEject(vehicle);
            if (fieldHolder == null) return false;

            Vehicle soldier = new Vehicle(VehicleType.SOLDIER, vehicleId, vehicle.getDirection(), vehicle.getIp());

            // get a preset or default set
            soldier.setEquipment(BulletZoneData.getInstance().getPresetOrDefault(presetId));
            vehicle.eject(fieldHolder, soldier);

            return true;
        }
    }


    /**
     * Let the leave the game and remove the vehicle off the map
     * @param vehicleId The id for the vehicle
     */
    @Override
    public void leave(long vehicleId)
            throws TankDoesNotExistException {
        synchronized (SingletonMonitor.getMonitor()) {
            if (!this.game.getVehicles().containsKey(vehicleId)) {
                throw new TankDoesNotExistException(vehicleId);
            }

            System.out.println("leave() called, vehicle ID: " + vehicleId);

            Vehicle vehicle = game.getVehicles().get(vehicleId);
            FieldHolder parent = vehicle.getParent();
            parent.clearField();
            game.removeVehicle(vehicleId);
        }
    }

    @Override
    public Vehicle getVehicle(long vehicleId) {
        return game.getVehicle(vehicleId);
    }
}
