package edu.unh.cs.cs619.bulletzone.repository;

import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;

import static edu.unh.cs.cs619.bulletzone.model.Direction.*;

public class Validator {
    /**
     * Validate a request to move a given vehicle.
     * Will not modify anything.
     * @param vehicle Vehicle object to validate.
     * @param direction Direction that the vehicle is trying to move
     * @return True if the vehicle is allowed to move. False otherwise.
     */
    public static boolean validateMove(Vehicle vehicle, Direction direction) {
        // Check if vehicle is null first
        if (vehicle == null) return false;

        // Check if the vehicle is allowed to move due to time
        long millis = System.currentTimeMillis();

        if(millis < vehicle.getNextAllowMoveTime()) return false;

        if (!vehicle.toString().equals("SOLDIER")) {
            // if there is no power generated each second
            if (vehicle.getTotalElectricPower() <= 0 || vehicle.getEnginePowerUsage() > vehicle.getAvailablePower() + (System.currentTimeMillis() - vehicle.getLastTimePowerUsed()) / 1000 * vehicle.getTotalElectricPower()) {
                return false;
            }
            // Check if vehicle is facing in the correct direction
            // Also allow the vehicle to move backward
            Direction vehicleDirection = vehicle.getDirection();
            switch (vehicleDirection) {
                case Down:
                case Up:
                    if (direction != Up && direction != Down) return false;
                    break;
                case Left:
                case Right:
                    if (direction != Right && direction != Left) return false;
                    break;
                default:
                    return false;
            }
        }

        // Check if vehicle has space in front of it
        FieldHolder parent = vehicle.getParent();
        if (parent == null) return false;
        FieldHolder neighbor = parent.getNeighbor(direction);
        if (neighbor == null) return false;

        // only apply if you are a soldier and next field is vehicle
        if (neighbor.isPresent() && neighbor.getEntity() instanceof Vehicle)
            return CollisionHandler.handleCommandeeringVehicle(vehicle, neighbor);

        // Instead of check if neighbor contains entity already
        // CollisionHandler will check what is there and interaction
        if (!CollisionHandler.handleTerrainInteraction(vehicle, neighbor)) return false;

        return true;
    }

    /**
     * Validates a turn request.
     * @param vehicle Vehicle to verify against.
     * @param direction Direction of vehicle turning.
     * @return True if the vehicle is allowed to turn.
     */
    public static boolean validateTurn(Vehicle vehicle, Direction direction) {
        // Check if vehicle is null first
        if (vehicle == null) return false;

        if (vehicle.toString().equals("SOLDIER")) return true;

        // Check if the vehicle is allowed to move due to time
        long millis = System.currentTimeMillis();
        if(millis < vehicle.getNextAllowMoveTime()) return false;

        // Ensure that the vehicle is not turning 180 degrees
        Direction vehicleDirection = vehicle.getDirection();
        switch (vehicleDirection) {
            case Down:
                if (direction == Up) return false;
                break;
            case Left:
                if (direction == Right) return false;
                break;
            case Right:
                if (direction == Left) return false;
                break;
            case Up:
                if (direction == Down) return false;
                break;
            default:
                return false;
        }

        return true;
    }

    /**
     * Validate a fire request.
     * @param vehicle Given vehicle object.
     * @param bulletType Type of the bullet to fire.
     * @return True if it can fire. False if the vehicle is null or it cannot fire.
     */
    public static boolean validateFire(Vehicle vehicle, int bulletType) {
        // Check if vehicle is null first
        if (vehicle == null) return false;

        // Check if the vehicle is allowed to fire due to time
        long millis = System.currentTimeMillis();
        if(millis < vehicle.getLastFireTime()) return false;

        // Check if the vehicle has too many bullets
        if (vehicle.getNumberOfBullets() >= vehicle.getAllowedNumberOfBullets()) return false;

        if (vehicle.getWeaponPowerUsage() > vehicle.getAvailablePower() + (System.currentTimeMillis() - vehicle.getLastTimePowerUsed()) /1000 * vehicle.getTotalElectricPower()) return false;

        // TODO: Do something with bullet type. This isn't something required in milestone 1.

        return true;
    }

    public static FieldHolder validateEject(Vehicle vehicle) {
        // Check if vehicle is null first
        if (vehicle == null) return null;

        // Check if the vehicle is allowed to fire due to time
        long millis = System.currentTimeMillis();
        if(millis < vehicle.getNextAllowEjectTime()) return null;

        // Instead of check if neighbor contains entity already
        // CollisionHandler will check what is there and interaction

        if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Left)))
            return vehicle.getParent().getNeighbor(Left);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Up)))
            return vehicle.getParent().getNeighbor(Up);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Right)))
            return vehicle.getParent().getNeighbor(Right);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Down)))
            return vehicle.getParent().getNeighbor(Down);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Left).getNeighbor(Up)))
            return vehicle.getParent().getNeighbor(Left).getNeighbor(Up);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Right).getNeighbor(Up)))
            return vehicle.getParent().getNeighbor(Right).getNeighbor(Up);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Left).getNeighbor(Down)))
            return vehicle.getParent().getNeighbor(Left).getNeighbor(Down);
        else if (CollisionHandler.handleTerrainInteraction(vehicle, vehicle.getParent().getNeighbor(Right).getNeighbor(Down)))
            return vehicle.getParent().getNeighbor(Right).getNeighbor(Down);
        else {
            System.out.println("In else - validator");
            return null;
        }
    }
}
