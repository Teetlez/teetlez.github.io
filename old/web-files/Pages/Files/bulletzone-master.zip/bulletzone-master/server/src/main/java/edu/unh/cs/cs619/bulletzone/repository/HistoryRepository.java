package edu.unh.cs.cs619.bulletzone.repository;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import edu.unh.cs.cs619.bulletzone.history.GridEvent;
import edu.unh.cs.cs619.bulletzone.history.GridEventData;

/**
 * Class to contain history in the form of GridEvent objects.
 */
public class HistoryRepository {
    private static HistoryRepository instance = new HistoryRepository();

    private final ArrayList<GridEventData> eventData;
    private Timer timer;

    /**
     * Private constructor for history repository.
     */
    private HistoryRepository() {
        eventData = new ArrayList<>();
        timer = new Timer();
    }

    /**
     * Get the current history repository instance.
     * @return History repository object.
     */
    public static HistoryRepository getInstance() {
        return instance;
    }

    /**
     * Add event to the history repository if player is not hiding.
     * @param position Position of the field holder.
     * @param terrain Terrain ID.
     * @param playerValue Value of the player.
     */
    public void addEvent(int position, int terrain, int playerValue) {
        addEvent(position, terrain, -1, playerValue, System.currentTimeMillis());
    }

    /**
     * Add event to the history repository if the player is hiding.
     * @param position Position of the field holder.
     * @param terrain Terrain ID.
     * @param playerId Player ID.
     * @param playerValue Player int value.
     */
    public void addEvent(int position, int terrain, int playerId, int playerValue) {
        addEvent(position, terrain, playerId, playerValue, System.currentTimeMillis());
    }

    /**
     * Add event to the history repository.
     * @param position Positon of the field holder.
     * @param terrain Value of the terrain.
     * @param playerId Player ID if they are hiding. Otherwise, give -1.
     * @param playerValue Value of the player entity.
     * @param timestamp Specific timestamp to set the grid event to.
     */
    void addEvent(int position, int terrain, int playerId, int playerValue, long timestamp) {
        synchronized (eventData) {
            GridEventData data = new GridEventData(position, terrain, playerId,
                    playerValue, timestamp);
            eventData.add(data);

            timer.schedule(new TimerTask() {
                @Override
                public void run() {
                    synchronized (eventData) {
                        eventData.remove(data);
                    }
                }
            }, 1000 * 60 * 3);
        }
    }

    /**
     * Get grid event arraylist.
     * Mainly used for testing purposes.
     * You shouldn't typically need to use it.
     * @return Arraylist reference.
     */
    public ArrayList<GridEventData> getEventData() {
        return eventData;
    }

    /**
     * Get grid events with a given timestamp.
     * @param timestamp Timestamp in milliseconds.
     * @param playerId
     * @return Grid events that took place after the given timestamp.
     */
    public GridEvent[] getEventData(long timestamp, int playerId) {
        ArrayList<GridEvent> result = new ArrayList<>();
        long minTimeStamp = System.currentTimeMillis() - 1000 * 60 * 3;
        synchronized (eventData) {
            for (GridEventData eventData : eventData) {
                long eventTime = eventData.getTimestamp();
                if (eventTime >= minTimeStamp && eventTime >= timestamp) {
                    result.add(eventData.toGridEvent(playerId));
                }
            }
        }
        return result.toArray(new GridEvent[0]);
    }
}
