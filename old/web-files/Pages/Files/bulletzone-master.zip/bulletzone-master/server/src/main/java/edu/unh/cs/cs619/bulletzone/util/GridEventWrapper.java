package edu.unh.cs.cs619.bulletzone.util;

import edu.unh.cs.cs619.bulletzone.history.GridEvent;

public class GridEventWrapper {
    private GridEvent[] grid;
    private long timestamp;

    public GridEventWrapper(GridEvent[] grid) {
        this.grid = grid;
        this.timestamp = System.currentTimeMillis();
    }

    public long getTimestamp() {
        return timestamp;
    }

    public GridEvent[] getGrid() {
        return grid;
    }

    public void setGrid(GridEvent[] grid) {
        this.grid = grid;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
