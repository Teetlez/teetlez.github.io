package edu.unh.cs.cs619.bulletzone.repository;

import java.util.TimerTask;

import edu.unh.cs.cs619.bulletzone.model.Bullet;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;

public class BulletTask extends TimerTask {
    private final Bullet bullet;

    public BulletTask(Bullet bullet) {
        this.bullet = bullet;
    }

    @Override
    public void run() {
        synchronized (SingletonMonitor.getMonitor()) {
            Vehicle vehicle = bullet.getVehicle();
            System.out.println("Active Bullet: " + bullet.getBulletId()
                    + "---- Bullet Value: " + bullet.getIntValue());
            FieldHolder currentField = bullet.getParent();
            Direction direction = bullet.getDirection();
            FieldHolder nextField = currentField
                    .getNeighbor(direction);

            // Is the bullet visible on the field?
            boolean isVisible = currentField.isPresent()
                    && (currentField.getEntity() == bullet);

            if (nextField.isPresent() || nextField.getTerrainID() == 902 || nextField.getTerrainID() == 2 || nextField.getTerrainID() == 1001) {
                // Something is there, hit it
                if (nextField.getTerrainID() == 902 || nextField.getTerrainID() == 2 || nextField.getTerrainID() == 1001) {
                    nextField.getTerrain().hit(bullet);
                }else
                    nextField.getEntity().hit(bullet);

                if (isVisible) {
                    // Remove bullet from field
                    currentField.clearField();
                }
                vehicle.getActiveBullets().set(bullet.getBulletId(), 0);
                vehicle.setNumberOfBullets(vehicle.getNumberOfBullets() - 1);
                cancel();

            } else {
                if (isVisible) {
                    // Remove bullet from field
                    currentField.clearField();
                }

                nextField.setFieldEntity(bullet);
                bullet.setParent(nextField);
            }
        }
    }
}
