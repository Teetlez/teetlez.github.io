package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;

public class Wall extends FieldEntity {
    int destructValue, pos;
    Double strength, hardness;

    public Wall(){
        this.destructValue = 1000;
        this.pos = -1;
    }

    public Wall(int destructValue, int pos){
        this.destructValue = destructValue;
        this.pos = pos;
        strength = 100.0;
        hardness = 1.0;
    }

    @Override
    public FieldEntity copy() {
        return new Wall();
    }

    @Override
    public int getIntValue() {
        return destructValue;
    }

    @Override
    public String toString() {
        return "Wall";
    }

    public int getPos(){
        return pos;
    }

    @Override
    public void hit(Bullet bullet) {
        super.hit(bullet);
        if (pos == -1) return;
        if (getIntValue() == 2000 && bullet.getDamage() > hardness) {
            strength -= bullet.getDamage();
            System.out.println("Wall life: " + strength + "/" + BulletZoneData.getInstance().terrains.Wall.getStrength());
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), bullet.getDamage());
        }
        if (strength <= 0) {
            Game.getInstance().getHolderGrid().get(getPos()).clearField();
            Game.getInstance().getHolderGrid().get(getPos()).setTerrainID(10);
            Game.getInstance().getHolderGrid().get(getPos()).updateHistory();
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), 100 * -1);
        }
    }
}
