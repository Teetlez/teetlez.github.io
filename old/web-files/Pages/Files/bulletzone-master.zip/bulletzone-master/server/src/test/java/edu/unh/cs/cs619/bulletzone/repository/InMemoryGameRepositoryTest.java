package edu.unh.cs.cs619.bulletzone.repository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.model.Bullet;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldEntity;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Forest;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.Terrain;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.VehicleType;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class InMemoryGameRepositoryTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @InjectMocks
    InMemoryGameRepository repo;

    @BeforeClass
    public static void init() {
        BulletZoneData.enableTestMode();
    }

    @Before
    public void setUp() throws Exception {
        Game.getInstance();
    }

    @Test
    public void testJoin() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        Assert.assertNotNull(vehicle);
        Assert.assertTrue(vehicle.getId() >= 0);
        Assert.assertNotNull(vehicle.getDirection());
        Assert.assertTrue(vehicle.getDirection() == Direction.Up);
        Assert.assertNotNull(vehicle.getParent());
    }

    @Test
    public void testJoin_SoldierPreset_ReturnTrue() throws Exception {
        Vehicle soldier = repo.join(-2, "0.0.0.0");
        Assert.assertNotNull(soldier);
        Assert.assertTrue(soldier.getId() >= 0);
        Assert.assertNotNull(soldier.getDirection());
        Assert.assertTrue(soldier.getDirection() == Direction.Up);
        Assert.assertNotNull(soldier.getParent());
        Assert.assertTrue(soldier.toString() == "SOLDIER");
    }

    @Test
    public void testJoin_TankPreset_ReturnTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        Assert.assertNotNull(vehicle);
        Assert.assertTrue(vehicle.getId() >= 0);
        Assert.assertNotNull(vehicle.getDirection());
        Assert.assertTrue(vehicle.getDirection() == Direction.Up);
        Assert.assertNotNull(vehicle.getParent());
        Assert.assertTrue(vehicle.toString() == "TANK");
    }

    @Test
    public void validateVehicleFire_LostScore_ReturnTrue() {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        Game.getInstance().gainOrLostScore(vehicle.getId(), 50);
        vehicle.setFireCount(9);
        vehicle.fire(1);
        long score = Game.getInstance().getScore(vehicle.getId());
        assertTrue("Vehicle fire will lost point base on bullet type should return ture",
                score == 49);
    }

    @Test
    public void validateWightStats_WeightChangeOnEquipItem_ReturnTrue() {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        GameItemContainer container = BulletZoneData.getInstance().getDefaultTank();
        vehicle.setEquipment(container);
        double old_stats = vehicle.getWeight();
        container.getItems().add(BulletZoneData.getInstance().items.create("Standard tank engine"));
        vehicle.setEquipment(container);
        double new_stats = vehicle.getWeight();
        System.out.println("Weight change from " + old_stats + " to " + new_stats);
        assertTrue("equip item will change tank weight stats", new_stats != old_stats);
    }

    @Test
    public void validateWightStats_WeightChangeTimeBetweenMovement_ReturnTrue() {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        GameItemContainer container = BulletZoneData.getInstance().getDefaultTank();
        vehicle.setEquipment(container);
        double old_stats = vehicle.getAllowedMoveInterval();
        System.out.println("Tank with weight:" + vehicle.getWeight() + "  Speed: " + vehicle.getAllowedMoveInterval());
        container.getItems().add(BulletZoneData.getInstance().items.create("Standard tank engine"));
        vehicle.setEquipment(container);
        double new_stats = vehicle.getAllowedMoveInterval();
        System.out.println("Tank with weight:" + vehicle.getWeight() + "  Speed: " + vehicle.getAllowedMoveInterval());
        assertTrue("equip item will change tank weight stats", new_stats != old_stats);
    }

    @Test
    public void validateElectricPowerStats_FireReducePower_ReturnTrue() {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        GameItemContainer container = BulletZoneData.getInstance().getDefaultTank();
        vehicle.setEquipment(container);

        double o = vehicle.getAvailablePower();
        vehicle.fire(99);
        double n = vehicle.getAvailablePower();
        assertTrue("Tank fire a bullet reduce available power should return true"
                , o != n);
    }

    @Test
    public void validateElectricPowerStats_PowerIsGeneratedOverTime_ReturnTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        GameItemContainer container = BulletZoneData.getInstance().getDefaultTank();
        vehicle.setEquipment(container);
        vehicle.setTotalElectricPower(100.00);
        double o =vehicle.getAvailablePower();
        vehicle.fire(1);
        Thread.sleep(1000);
        repo.fire(vehicle.getId(),1);
        System.out.println(vehicle.getAllowedFireInterval());
        double n =vehicle.getAvailablePower();
        assertTrue("Tank gain power after time waited should return true"
                , o < n);
    }

    @Test
    public void validateUpdateStats_EquipOneMoreItem_ReturnTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        // join and use default set
        GameItemContainer container = BulletZoneData.getInstance().getDefaultTank();
        vehicle.setEquipment(container);

        System.out.println("Tank has:");
        for (GameItem item:container.getItems()) System.out.println(item.toString());

        int oldCount = vehicle.getAllowedNumberOfBullets();

        // add one new item
        container.getItems().add(BulletZoneData.getInstance().items.create("Plasma cannon"));
        vehicle.setEquipment(container);

        int newCount = vehicle.getAllowedNumberOfBullets();

        System.out.println("Bullet count increase from" + oldCount + " to " + newCount);

        assertTrue("Bullet allow increased when add more weapon should return true",
                oldCount < newCount);
    }

    @Test
    public void validateTurn_UpToDown_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(500);

        assertTrue("Vehicle turning from Up to Left should return true",
                repo.turn(vehicle.getId(), Direction.Left));
        assertFalse("Vehicle turning from Up to Down should return false",
                repo.turn(vehicle.getId(), Direction.Down));
    }

    @Test
    public void validateTurn_DownToUp_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(500);
        vehicle.setDirection(Direction.Down);

        assertTrue("Vehicle turning from Down to Left should return true",
                repo.turn(vehicle.getId(), Direction.Left));
        assertFalse("Vehicle turning from Down to Up should return false",
                repo.turn(vehicle.getId(), Direction.Up));
    }

    @Test
    public void validateTurn_LeftToRight_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(500);
        vehicle.setDirection(Direction.Left);

        assertTrue("Vehicle turning from Left to Up should return true",
                repo.turn(vehicle.getId(), Direction.Up));
        assertFalse("Vehicle turning from Left to Right should return false",
                repo.turn(vehicle.getId(), Direction.Right));
    }

    @Test
    public void validateTurn_RightToLeft_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(500);
        vehicle.setDirection(Direction.Right);

        assertTrue("Vehicle turning from Right to Down should return true",
                repo.turn(vehicle.getId(), Direction.Down));
        assertFalse("Vehicle turning from Right to Left should return false",
                repo.turn(vehicle.getId(), Direction.Left));
    }


    @Test
    public void validateTurn_TooFast_ReturnsFalse() throws Exception {
        long fixedTime = System.currentTimeMillis();
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(500);

        Assert.assertTrue("Vehicle turning first time should return true",
                repo.turn(vehicle.getId(), Direction.Left));

        // update vehicle direction
        vehicle.setDirection(Direction.Left);

        // Simulate already done move
        vehicle.setNextAllowMoveTime(fixedTime + 2 * vehicle.getAllowedMoveInterval());

        Assert.assertFalse("Vehicle turning second time should return true",
                repo.turn(vehicle.getId(), Direction.Down));
    }

    @Test
    public void validateMove_OffTheMapWillLoopAround_ReturnTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");

        FieldHolder parent;
        FieldHolder nextField;

        // move the vehicle up 16 time
        // the vehicle will loop around the map
        for (int i = 0; i < 16; i++) {
            parent = vehicle.getParent();
            // Ensure that the cell you're moving into is clear.
            nextField = parent.getNeighbor(Direction.Up);
            nextField.clearField();
            nextField.setTerrainID(-1);
            nextField.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));

            // Test validate moving off the map will loop around
            Assert.assertTrue("Vehicle moving Up should return true",
                    repo.move(vehicle.getId(), Direction.Up));

            Thread.sleep(600);
        }
    }

    @Test
    public void validateMove_MoveSidewaysWhileFacingUpOrDown_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = vehicle.getParent();

        // join() places vehicle in random empty field
        // clear whatever is in front of the vehicle for testing

        parent.getNeighbor(Direction.Down).clearField();
        parent.getNeighbor(Direction.Down).setTerrainID(-1);
        parent.getNeighbor(Direction.Down).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        parent.getNeighbor(Direction.Left).clearField();
        parent.getNeighbor(Direction.Left).setTerrainID(-1);
        parent.getNeighbor(Direction.Left).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));

        // Test validate moving sideways while facing up
        Assert.assertFalse("Vehicle moving sideways should return false",
                repo.move(vehicle.getId(), Direction.Left));

        // Test validate moving backward
        Assert.assertTrue("Vehicle moving backward should return true",
                repo.move(vehicle.getId(), Direction.Down));
    }

    @Ignore
    public void validateMove_MoveSidewaysWhileFacingLeftOrRight_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setDirection(Direction.Right);
        FieldHolder parent = vehicle.getParent();

        // join() places vehicle in random empty field
        // clear whatever is in front of the vehicle for testing

        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        parent.getNeighbor(Direction.Left).clearField();
        parent.getNeighbor(Direction.Left).setTerrainID(-1);


        // Test validate moving sideways while facing up
        Assert.assertFalse("Vehicle moving sideways should return false",
                repo.move(vehicle.getId(), Direction.Up));

        // Test validate moving backward
        Assert.assertTrue("Vehicle moving backward should return true",
                repo.move(vehicle.getId(), Direction.Left));
    }

    @Test
    public void validateMove_EmptyNeighbor_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");


        // join() places vehicle in random empty field
        // clear whatever is in front of the vehicle for testing
        FieldHolder parent = vehicle.getParent();
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);


        Assert.assertTrue("Moving up into empty fieldholder should return true",
                repo.move(vehicle.getId(), Direction.Up));
    }

    @Test
    public void validateMove_NeighborWithEntity_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = vehicle.getParent();

        // Create an occupied field and place in front of the vehicle
        Vehicle blcokVehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        FieldHolder neighbor = new FieldHolder(0);
        blcokVehicle.setParent(neighbor);
        neighbor.setFieldEntity(blcokVehicle);

        // join() places vehicle in random empty field
        // clear whatever is in front of the vehicle for testing
        parent.getNeighbor(Direction.Up).clearField();
        parent.addNeighbor(Direction.Up, neighbor);

        // Test validate moving up
        Assert.assertFalse("Moving into occupied field should return false",
                repo.move(vehicle.getId(), Direction.Up));
    }

    @Ignore
    public void validateMove_TooFast_ReturnsFalse() throws Exception {
        long fixedTime = System.currentTimeMillis();
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = vehicle.getParent();
        vehicle.setParent(parent);

        // clear field for move up
        // move up first time should return true
        // move up second time should return false
        parent.getNeighbor(Direction.Up).clearField();
        Assert.assertTrue("Moving up first time should return true",
                repo.move(vehicle.getId(), Direction.Up));

        parent.getNeighbor(Direction.Down).clearField();

        // Simulate already done move
        vehicle.setNextAllowMoveTime(System.currentTimeMillis() * 2 + vehicle.getNextAllowMoveTime());

        Assert.assertFalse("Moving up second time should return false",
                repo.move(vehicle.getId(), Direction.Down));
    }

    @Test
    public void validateMove_MoveIntoRoad_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = Game.getInstance().getHolderGrid().get(112);
        FieldHolder up = Game.getInstance().getHolderGrid().get(96);
        parent.clearField();
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);

        // clear field for move up
        // move up first time should return true
        // move up second time should return false
        parent.getNeighbor(Direction.Up).clearField();
        Assert.assertTrue("Moving up first time should return true",
                repo.move(vehicle.getId(), Direction.Up));

    }

    @Test
    public void validateMove_MoveOutForestDoNotDeleteForest_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");

        // Use a ship config
        GameItemContainer container = BulletZoneData.getInstance().items.createContainer(BulletZoneData.getInstance().types.BattleSuit);
        container.getItems().add(BulletZoneData.getInstance().items.create("Portable generator"));
        container.getItems().add(BulletZoneData.getInstance().items.create("Battle-suit power converter"));
        container.getItems().add(BulletZoneData.getInstance().items.create("Battle-suit leg assists"));
        vehicle.setEquipment(container);

        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(12);
        parent.clearField();
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);

        vehicle.setDirection(Direction.Down);
        vehicle.setAllowedMoveInterval(10);

        repo.move(playerID, Direction.Down);
        Thread.sleep(100);
        repo.move(playerID, Direction.Down);
        Assert.assertTrue("1 Move inside forest will not delete forest",
                vehicle.getParent().getNeighbor(Direction.Up).getTerrain().toString().equals("Forest"));
        Thread.sleep(100);
        repo.move(playerID, Direction.Down);
        Assert.assertTrue("2 Move inside forest will not delete forest",
                vehicle.getParent().getNeighbor(Direction.Up).getTerrain().toString().equals("Forest"));
        Thread.sleep(100);
        repo.move(playerID, Direction.Down);
        Assert.assertTrue("3 Move inside forest will not delete forest",
                vehicle.getParent().getNeighbor(Direction.Up).getTerrain().toString().equals("Forest"));
        Assert.assertTrue("Move out the forest should return true",
                vehicle.getParent().getPosition() == 76);
    }

    @Test
    public void validateMove_EnterEmptyVehicle_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);

        // Eject the soldier
        repo.eject(vehicle.getId(), -2);
        Vehicle soldier = Game.getInstance().getVehicle(playerID);

        // Soldier move back into the tank
        soldier.setDirection(Direction.Down);
        repo.move(playerID, Direction.Down);
        System.out.println(Game.getInstance().getVehicle(playerID).toString());
        // User control switch to tank
        Assert.assertTrue("Soldier enter empty tank will switch user control should return true",
                Game.getInstance().getVehicle(playerID).toString().equals("TANK"));
    }

    @Test
    public void validateMove_EnterEmptyVehicleFromSide_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setAllowedMoveInterval(0);
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
//        repo.turn(vehicle.getId(), Direction.Left); // if we comment this out, the soldier variable will be a tank

        // Eject the soldier
        repo.eject(vehicle.getId(), -2);
        Vehicle soldier = Game.getInstance().getVehicle(playerID);
        System.out.println("After eject = " + soldier.toString());

        // Soldier move back into the tank
        soldier.setDirection(Direction.Down);
        repo.move(playerID, Direction.Down);
        System.out.println(Game.getInstance().getVehicle(playerID).toString());
        // User control switch to tank
        Assert.assertTrue("Soldier enter empty tank will switch user control should return true",
                Game.getInstance().getVehicle(playerID).toString().equals("TANK"));
        System.out.println(repo.turn(playerID, Direction.Right));
        assertTrue(repo.turn(playerID, Direction.Right));
    }

    @Test
    public void validateMove_EnterEmptyVehicleGainScore_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);

        // Eject the soldier
        repo.eject(vehicle.getId(), -2);
        Vehicle soldier = Game.getInstance().getVehicle(playerID);

        // Soldier move back into the tank
        soldier.setDirection(Direction.Down);
        repo.move(playerID, Direction.Down);

        System.out.println(Game.getInstance().getScore(playerID));
        // User control switch to tank
        Assert.assertTrue("Soldier enter empty tank will not score should return true",
                Game.getInstance().getScore(playerID) == 0);

        vehicle.getPreviousOwner().remove(0);
        long old_score = Game.getInstance().getScore(playerID);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
        repo.eject(vehicle.getId(), -2);
        soldier = Game.getInstance().getVehicle(playerID);
        soldier.setDirection(Direction.Down);
        repo.move(playerID, Direction.Down);
        System.out.println(Game.getInstance().getScore(playerID));

        Assert.assertTrue("Soldier reenter empty tank will gain score should return true",
                Game.getInstance().getScore(playerID) > old_score);
    }

    @Test
    public void validateMove_EnterNonemptyVehicle_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);

        // Eject the soldier
        repo.eject(vehicle.getId(), -2);
        Vehicle soldier = Game.getInstance().getVehicle(playerID);

        // Soldier move back into the tank
        soldier.setDirection(Direction.Down);
        vehicle.setId(50);
        repo.move(playerID, Direction.Down);
        System.out.println(Game.getInstance().getVehicle(playerID).toString());
        // User control switch to tank
        Assert.assertTrue("Soldier enter nonempty tank do not switch user control should return true",
                Game.getInstance().getVehicle(playerID).toString().equals("SOLDIER"));
    }

    @Test
    public void validateEject_NoOpenLocation_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        Assert.assertFalse("Eject soldier when surrounded by wall should return false",
                repo.eject(vehicle.getId(), -2));
    }

    @Test
    public void validateEject_OpenUpLocation_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
        Assert.assertTrue("Eject soldier with one open location should return true",
                repo.eject(vehicle.getId(), -2));
    }

    @Test
    public void validateEject_EjectTwoTime_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
        repo.eject(playerID, -2);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
//        Game.getInstance().addSoldier("0,0,0,0", new Vehicle(VehicleType.SOLDIER, vehicle.getId(), Direction.Up, "0,0,0,0"));
        Assert.assertFalse("Eject soldier second time should return false",
                repo.eject(playerID, -2));
    }

    @Test
    public void validateEject_EjectSwitchControl_ReturnsTrue() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        long playerID = vehicle.getId();
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
        repo.eject(vehicle.getId(), -2);
        vehicle = Game.getInstance().getVehicle(playerID);
        Assert.assertTrue("Eject soldier switch user control should return true",
                vehicle.toString().equals("SOLDIER"));
    }

    @Test
    public void validateFire_TooManyBullets_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");
        vehicle.setNumberOfBullets(vehicle.getAllowedNumberOfBullets());
        Assert.assertFalse("Vehicle shooting too many bullets should return false",
                repo.fire(vehicle.getId(), 1));
    }

    @Test
    public void validateFire_TooFast_ReturnsFalse() throws Exception {
        Vehicle vehicle = repo.join(-1, "0.0.0.0");

        Assert.assertTrue("Fire first time should return true",
                repo.fire(vehicle.getId(), 1));

        // Simulate already done fire
        vehicle.setLastFireTime(System.currentTimeMillis() * 2 + vehicle.getLastFireTime());

        Assert.assertFalse("Fire second time should return false",
                repo.fire(vehicle.getId(), 1));
    }
}