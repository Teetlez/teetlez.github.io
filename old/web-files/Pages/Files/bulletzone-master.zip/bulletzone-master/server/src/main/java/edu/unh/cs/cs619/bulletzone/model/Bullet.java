package edu.unh.cs.cs619.bulletzone.model;

public class Bullet extends FieldEntity {

    private Vehicle vehicle;
    private Direction direction;
    private int damage, bulletId;

    public Bullet(Vehicle vehicle, Direction direction, int damage) {
        this.setDamage(damage);
        this.setVehicle(vehicle);
        this.setDirection(direction);
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    @Override
    public int getIntValue() {
        return (int) (2000000 + 1000 * getVehicleId() + damage * 10 + bulletId);
    }

    @Override
    public String toString() {
        return "B";
    }

    @Override
    public FieldEntity copy() {
        return new Bullet(vehicle, direction, damage);
    }

    public long getVehicleId() {
        return vehicle.getId();
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setBulletId(int bulletId){
        this.bulletId = bulletId;
    }

    public int getBulletId(){
        return bulletId;
    }
}
