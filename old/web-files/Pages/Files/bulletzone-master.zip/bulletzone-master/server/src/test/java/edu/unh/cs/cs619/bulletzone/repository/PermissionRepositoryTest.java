package edu.unh.cs.cs619.bulletzone.repository;

import org.junit.Before;
import org.junit.Test;

import java.util.HashMap;
import java.util.HashSet;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;
import edu.unh.cs.cs619.bulletzone.datalayer.Permission;

import static org.junit.Assert.*;

public class PermissionRepositoryTest {
    static int counter = 0;

    BulletZoneData bulletZoneData;
    PermissionRepository permissionRepository;
    GameUser user;
    GameItemContainer frame;
    GaragebayRepository garagebayRepository;

    @Before
    public void setup() {
        bulletZoneData = new BulletZoneData();
        user = createUser();
        frame = bulletZoneData.items.createContainer(bulletZoneData.types.TruckFrame);
        bulletZoneData.permissions.grant(frame.getItemID(), user.getUserID(), Permission.Owner);
        garagebayRepository = new GaragebayRepository(bulletZoneData);
        permissionRepository = new PermissionRepository(bulletZoneData, garagebayRepository);
    }

    private GameUser createUser() {
        return bulletZoneData.users.createUser("name",
                "userPermissionRepo" + counter++, "p");
    }

    private GameItemContainer createGarageBay(GameUser owner) {
        GameItemContainer gb = bulletZoneData.items
                .createContainer(bulletZoneData.types.GarageBay);
        bulletZoneData.permissions.setOwner(gb, owner);
        return gb;
    }

    @Test
    public void getPermissionOnItemID_noPermissions_returnsZero() {
        GameItemContainer temp = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        assertEquals(0, permissionRepository
                .getPermissionOnItemID(temp.getItemID()).size());
    }

    @Test
    public void getPermissionOnItemID_afterAddingPermission_returnsOne() {
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                user.getUsername(), Permission.Owner);
        assertEquals(1, permissionRepository
                .getPermissionOnItemID(frame.getItemID()).size());
    }

    @Test
    public void getPermissionOnItemID_oneUser_returnsName() {
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                user.getUsername(), Permission.Owner);
        HashMap<Integer, HashSet<Permission>> perm = permissionRepository
                .getPermissionOnItemID(frame.getItemID());

        boolean contain = perm.containsKey(user.getUserID());
        assertTrue(contain);
    }

    @Test
    public void getPermissionOnItemID_oneUser_returnsPermission() {
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                user.getUsername(), Permission.Owner);
        HashMap<Integer, HashSet<Permission>> perm = permissionRepository
                .getPermissionOnItemID(frame.getItemID());

        boolean contain = perm.get(user.getUserID()).contains(Permission.Owner);
        assertTrue(contain);
    }

    @Test
    public void addPermissionToItem_realUser_WorksOnce() {
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                user.getUsername(), Permission.Owner);
        assertFalse(permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                user.getUsername(), Permission.Owner));
    }

    @Test
    public void addPermissionToItem_realUser_updatesGaragebay() {
        GameUser secondUser = createUser();
        GameItemContainer garageBay = createGarageBay(secondUser);

        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                secondUser.getUsername(), Permission.Add);
        assertEquals(1, garageBay.getItems().size());
    }

    @Test
    public void addPermissionToItem_multipleTimes_updatesGaragebayOnce() {
        GameUser secondUser = createUser();
        GameItemContainer garageBay = createGarageBay(secondUser);

        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                secondUser.getUsername(), Permission.Add);
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                secondUser.getUsername(), Permission.Remove);
        assertEquals(1, garageBay.getItems().size());
    }

    @Test
    public void addPermissionToItem_fakeUser_returnsFalse() {
        boolean added = permissionRepository.addPermissionToItem(frame.getItemID(),
                user.getUserID(), "fakeuserrrrr1234", Permission.Add);
        assertFalse(added);
    }

    @Test
    public void addPermissionToItem_nonOwner_returnsFalse() {
        GameUser newUser = createUser();
        boolean added = permissionRepository.addPermissionToItem(frame.getItemID(),
                newUser.getUserID(), user.getUsername(), Permission.Add);
        assertFalse(added);
    }

    @Test
    public void removePermissionFromItem_noPermission_returnsFalse() {
        GameItemContainer temp = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        assertFalse(permissionRepository.removePermissionFromItem(temp.getItemID(),
                user.getUserID(), user.getUsername(), Permission.Owner));
    }

    @Test
    public void removePermissionFromItem_onePermission_returnsTrue() {
        GameUser newUser = createUser();
        permissionRepository.addPermissionToItem(frame.getItemID(), this.user.getUserID(),
                newUser.getUsername(), Permission.Add);
        assertTrue(permissionRepository.removePermissionFromItem(frame.getItemID(),
                this.user.getUserID(), newUser.getUsername(), Permission.Add));
    }

    @Test
    public void removePermissionFromItem_oneRemains_stillInGaragebay() {
        GameUser target = createUser();
        GameItemContainer garageBay = createGarageBay(target);
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Add);
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Remove);
        permissionRepository.removePermissionFromItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Add);
        assertEquals(1, garageBay.getItems().size());
    }

    @Test
    public void removePermissionFromItem_nonOwner_returnsFalse() {
        GameUser target = createUser();
        GameUser dummy = createUser();
        GameItemContainer garageBay = createGarageBay(target);
        GameItemContainer dummyGB = createGarageBay(dummy);
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Add);
        boolean removed = permissionRepository.removePermissionFromItem(frame.getItemID(),
                dummy.getUserID(), target.getUsername(), Permission.Add);
        assertFalse(removed);
    }

    @Test
    public void removePermissionFromItem_allPerms_emptyGaragebay() {
        GameUser target = createUser();
        GameItemContainer garageBay = createGarageBay(target);
        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Add);
        permissionRepository.removePermissionFromItem(frame.getItemID(), user.getUserID(),
                target.getUsername(), Permission.Add);
        assertEquals(0, garageBay.getItems().size());
    }

    @Test
    public void transferOwnership_noOwner_returnsTrue() {
        GameItemContainer tempFrame = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        System.out.println("Frame's owner is " + tempFrame.getOwner());
        GameUser destUser = createUser();

        boolean transferred = permissionRepository.transferOwnership(tempFrame.getItemID(),
                user.getUserID(), destUser.getUsername());
        System.out.println("Frame's owner is " + tempFrame.getOwner());
        assertTrue(transferred);
    }

    @Test
    public void transferOwnership_wrongOwner_returnsFalse() {
        System.out.println("Frame's owner is " + frame.getOwner());
        GameUser destUser = createUser();

        boolean transferred = permissionRepository.transferOwnership(frame.getItemID(),
                destUser.getUserID(), destUser.getUsername());
        System.out.println("Frame's owner is " + frame.getOwner());
        assertFalse(transferred);
    }

    @Test
    public void transferOwnership_onePerson_permissionReadded() {
        GameUser targetUser = createUser();
        GameItemContainer targetGB = createGarageBay(targetUser);

        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                targetUser.getUsername());
        HashMap<Integer, HashSet<Permission>> perms = permissionRepository
                .getPermissionOnItemID(frame.getItemID());
        HashSet<Permission> permissions = perms.get(user.getUserID());

        assertEquals(1, targetGB.getItems().size());
        assertTrue(permissions.contains(Permission.Use));
        assertFalse(permissions.contains(Permission.Owner));
    }

    @Test
    public void transferOwnership_twoPeople_permissionReadded() {
        GameUser targetUser = createUser();
        GameUser targetUser2 = createUser();
        GameItemContainer targetGB = createGarageBay(targetUser);
        GameItemContainer targetGB2 = createGarageBay(targetUser2);

        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                targetUser.getUsername());
        HashMap<Integer, HashSet<Permission>> allPerms = permissionRepository
                .getPermissionOnItemID(frame.getItemID());
        HashSet<Permission> target1Perms = allPerms.get(user.getUserID());

        assertTrue(target1Perms.contains(Permission.Use));
        assertFalse(target1Perms.contains(Permission.Owner));

        permissionRepository.transferOwnership(frame.getItemID(), targetUser.getUserID(),
                targetUser2.getUsername());

        HashSet<Permission> targetPerms = allPerms.get(targetUser.getUserID());

        assertTrue(targetPerms.contains(Permission.Use));
        assertFalse(targetPerms.contains(Permission.Owner));
        assertSame(frame.getOwner(), targetUser2);
    }

    @Test
    public void transferOwnership_onePerson_ownerPermission() {
        GameUser targetUser = createUser();
        GameItemContainer targetGB = createGarageBay(targetUser);

        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                targetUser.getUsername());
        HashMap<Integer, HashSet<Permission>> allPerms = permissionRepository
                .getPermissionOnItemID(frame.getItemID());
        HashSet<Permission> userPerms = allPerms.get(targetUser.getUserID());

        assertTrue(userPerms.contains(Permission.Owner));
    }

    @Test
    public void transferOwnership_realOwner_returnsTrue() {
        System.out.println("Frame's owner is " + frame.getOwner());
        GameUser destUser = createUser();

        boolean transferred = permissionRepository.transferOwnership(frame.getItemID(),
                user.getUserID(), destUser.getUsername());
        System.out.println("Frame's owner is " + frame.getOwner());
        assertTrue(transferred);
    }

    @Test
    public void transferOwnership_realOwner_transfersGaragebay() {
        // Set up user and garage bay
        GameUser dstUser = createUser();
        GameItemContainer gb1 = createGarageBay(user);
        GameItemContainer gb2 = createGarageBay(dstUser);

        // Set up item to transfer
        GameItemContainer frame = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        bulletZoneData.permissions.setOwner(frame, user);
        bulletZoneData.items.addItemToContainer(frame, gb1);

        // Log
        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of dest. garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        // Transfer
        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                dstUser.getUsername());

        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of dest. garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        assertEquals(1, gb2.getItems().size());
    }

    /**
     * Simply a test with existing containers in mind.
     * They do not have owners.
     */
    @Test
    public void transferOwnership_noOwner_transfersGaragebay() {
        // Set up user and garage bay
        GameUser dstUser = createUser();
        GameItemContainer gb1 = createGarageBay(user);
        GameItemContainer gb2 = createGarageBay(dstUser);

        // Set up item to transfer
        GameItemContainer frame = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        bulletZoneData.items.addItemToContainer(frame, gb1);

        // Log
        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of dest. garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        // Transfer
        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                dstUser.getUsername());

        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of dest. garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        assertEquals(1, gb2.getItems().size());
    }

    @Test
    public void transferOwnership_threeOwners_transfersGaragebay() {
        // Set up user and garage bay
        GameUser dstUser = createUser();
        GameUser finalUser = createUser();
        GameItemContainer gb1 = createGarageBay(user);
        GameItemContainer gb2 = createGarageBay(dstUser);
        GameItemContainer gb3 = createGarageBay(finalUser);

        // Set up item to transfer
        GameItemContainer frame = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        bulletZoneData.items.addItemToContainer(frame, gb1);

        // Log
        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of 2nd garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Size of 3rd garage bay: " + bulletZoneData.items
                .getContainer(gb3.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        assertEquals(1, gb1.getItems().size());
        assertEquals(0, gb2.getItems().size());
        assertEquals(0, gb3.getItems().size());

        // Transfer first time
        permissionRepository.transferOwnership(frame.getItemID(), user.getUserID(),
                dstUser.getUsername());

        // Log
        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of 2nd garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Size of 3rd garage bay: " + bulletZoneData.items
                .getContainer(gb3.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        assertEquals(1, gb1.getItems().size());
        assertEquals(1, gb2.getItems().size());
        assertEquals(0, gb3.getItems().size());

        // Transfer second time
        permissionRepository.transferOwnership(frame.getItemID(), dstUser.getUserID(),
                finalUser.getUsername());

        // Log
        System.out.println("Size of orig. garage bay: " + bulletZoneData.items
                .getContainer(gb1.getItemID()).getItems().size());
        System.out.println("Size of 2nd garage bay: " + bulletZoneData.items
                .getContainer(gb2.getItemID()).getItems().size());
        System.out.println("Size of 3rd garage bay: " + bulletZoneData.items
                .getContainer(gb3.getItemID()).getItems().size());
        System.out.println("Owner: "+ bulletZoneData.items.getContainer(frame.getItemID())
                .getOwner());

        assertEquals(1, gb1.getItems().size());
        assertEquals(1, gb2.getItems().size());
        assertEquals(1, gb3.getItems().size());
    }

    @Test
    public void transferOwnership_transferPermission_transfersGaragebay() {
        // Set up user and garage bay
        GameUser dstUser = createUser();
        GameUser finalUser = createUser();
        GameItemContainer gb1 = createGarageBay(user);
        GameItemContainer gb2 = createGarageBay(dstUser);
        GameItemContainer gb3 = createGarageBay(finalUser);

        // Set up item to transfer
        GameItemContainer frame = bulletZoneData.items
                .createContainer(bulletZoneData.types.TruckFrame);
        bulletZoneData.items.addItemToContainer(frame, gb1);

        permissionRepository.addPermissionToItem(frame.getItemID(), user.getUserID(),
                dstUser.getUsername(), Permission.Transfer);
        permissionRepository.transferOwnership(frame.getItemID(), dstUser.getUserID(),
                finalUser.getUsername());

        assertEquals(1, gb3.getItems().size());
        assertEquals(1, gb2.getItems().size());
        assertEquals(1, gb1.getItems().size());
        assertSame(finalUser, frame.getOwner());
    }
}