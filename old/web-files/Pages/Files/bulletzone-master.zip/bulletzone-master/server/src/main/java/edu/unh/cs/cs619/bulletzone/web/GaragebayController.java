package edu.unh.cs.cs619.bulletzone.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.repository.GaragebayRepository;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.GaragebayWrapper;

@RestController
@RequestMapping(value = "/garagebay")
public class GaragebayController {
    private static final Logger log = LoggerFactory.getLogger(GaragebayController.class);
    private GaragebayRepository garagebayRepository;

    /**
     * Default constructor for RestController.
     */
    public GaragebayController() {
        this.garagebayRepository = GaragebayRepository.getInstance();
    }

    /**
     * Development constructor.
     * Used for testing purposes.
     * @param garagebayRepository Garage bay repository object.
     */
    public GaragebayController(GaragebayRepository garagebayRepository) {
        this.garagebayRepository = garagebayRepository;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<GaragebayWrapper> getGaragebay(@PathVariable int userId) {
        // Log the request
        log.debug("getGarageBay -- USER " + userId);

        // Get garage bay
        GameItemContainer garageBay = garagebayRepository.getGarageBay(userId);
        if (garageBay == null) return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);

        // Return the result of grabbing garage bay repository
        return new ResponseEntity<>(new GaragebayWrapper(garageBay), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/{userId}/{itemType}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> addContainerToUserGaragebay(
            @PathVariable int userId, @PathVariable String itemType) {
        // Log the request
        log.debug("addContainerToUserGaragebay -- USER " + userId + " -- ITEM: " + itemType);

        // Add container
        int itemId = garagebayRepository.addContainerToGarageBay(userId, itemType);

        // Return the result
        return new ResponseEntity<>(new BooleanWrapper(itemId != -1), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/{userId}/{itemId}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> removeContainerFromUserGaragebay(
            @PathVariable int userId, @PathVariable int itemId) {
        // Log the request
        log.debug("removeContainerFromUserGaragebay -- USER " + userId + " -- ITEM " + itemId);

        // Remove item
        boolean pass = garagebayRepository.removeContainerFromGarageBay(userId, itemId);

        // Return the result
        return new ResponseEntity<>(new BooleanWrapper(pass), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/container/{container}/{itemType}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> addItemToContainer(
            @PathVariable int container, @PathVariable String itemType) {
        // Log the request
        log.debug("addItemToContainer -- CONTAINER " + container + " -- ITEM " + itemType);

        // Add new item to container
        int itemId = garagebayRepository.addItemToContainer(container, itemType);

        // Return the result
        return new ResponseEntity<>(new BooleanWrapper(itemId != -1), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/container/{container}/{itemId}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> removeItemFromContainer(
            @PathVariable int container, @PathVariable int itemId) {
        // Log the request
        log.debug("removeItemToContainer -- CONTAINER " + container + " -- ITEM " + itemId);

        // Remove item from container
        boolean pass = garagebayRepository.removeItemFromContainer(itemId, container);

        // Return the result
        return new ResponseEntity<>(new BooleanWrapper(pass), HttpStatus.ACCEPTED);
    }
}
