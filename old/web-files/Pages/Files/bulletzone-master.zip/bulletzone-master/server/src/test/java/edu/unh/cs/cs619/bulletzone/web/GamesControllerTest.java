package edu.unh.cs.cs619.bulletzone.web;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.TankDoesNotExistException;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.repository.InMemoryGameRepository;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.LongWrapper;
import edu.unh.cs.cs619.bulletzone.util.StringArrayWrapper;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class GamesControllerTest {
    @Spy
    @InjectMocks
    private InMemoryGameRepository repository;

    private GamesController controller;

    @BeforeClass
    public static void init() {
        BulletZoneData.enableTestMode();
    }

    /**
     * Simple method to create requests easily
     * @param ip IP address of the request
     * @return Mocked HttpServletRequest
     */
    private HttpServletRequest createRequest(String ip) {
        HttpServletRequest mock = Mockito.mock(HttpServletRequest.class);
        Mockito.when(mock.getRemoteAddr()).thenReturn(ip);
        return mock;
    }

    @Before
    public void setUp() throws Exception {
        // Set up repository and stuff
        repository = new InMemoryGameRepository();
        controller = new GamesController(repository);
    }

    /**
     * Tests to make sure that creating a new game controller/repository and joining it will
     * accurately return a tank.
     */
    @Test
    public void join_newGameController_givesID() {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        assertTrue("Joining a game should return a tank id",
                join.getBody().getResult() > -1);
    }

    /**
     * Ensures that joining a game with more players returns different tank IDs
     */
    @Test
    public void join_multiplePlayers_differentTankIDs() {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("1.1.1.1"), -1);
        ResponseEntity<LongWrapper> join2 = controller.join(createRequest("1.1.1.2"), -1);
        assertTrue("Joining a game multiple times should return different tank IDs",
                join.getBody().getResult() != join2.getBody().getResult());
    }

    @Test
    public void grid() {
    }

    @Test
    public void terrainGrid() {
        int [][] terrainGrid = Game.getInstance().getTerrainGrid();
        assertTrue("Terrain is populated and not null", terrainGrid != null);
    }

    @Test
    public void getUserScore_NonexistentUserID_ReturnScore() {
        long score = controller.getUserScore(2).getBody().getResult();
        assertTrue("Get user score from not existed user should return -1 as no score",
                score == -1);
    }

    @Test
    public void getUserScore_ExistedUserID_ReturnScore() {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("1.1.1.1"), -1);
        long score = controller.getUserScore(1).getBody().getResult();
        assertTrue("Get user score from existed user should return its default score",
                score == 0);
    }

    @Test
    public void validateTerrainType_RequestWaterTerrain_ReturnTrue() {
        String[] terrainType = controller.terrainType(50).getBody().getGrid();
        for (String terrain_statu : terrainType) {
            System.out.println(terrain_statu);
        }

        assertTrue("Terrain status should be greater than 0",
                terrainType.length > 0);
    }

    /**
     * Tests to make sure tank can not turn from up to down
     */
    @Test
    public void validateTurn_UpToDown_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> turn = controller.turn(tankID, Direction.toByte(Direction.Down));

        assertFalse("Vehicle turning from Up to Down should return false",
                turn.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not turn from left to right
     */
    @Test
    public void validateTurn_LeftToRight_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.turn(tankID, Direction.toByte(Direction.Left));
        Thread.sleep(600);
        ResponseEntity<BooleanWrapper> turnRight = controller.turn(tankID, Direction.toByte(Direction.Right));

        assertFalse("Vehicle turning from Left to Right should return false",
                turnRight.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not turn from right to left
     */
    @Test
    public void validateTurn_RightToLeft_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.turn(tankID, Direction.toByte(Direction.Right));
        Thread.sleep(600);
        ResponseEntity<BooleanWrapper> turnLeft = controller.turn(tankID, Direction.toByte(Direction.Left));

        assertFalse("Vehicle turning from Right to Left should return false",
                turnLeft.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not turn from down to up
     */
    @Test
    public void validateTurn_DownToUp_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.turn(tankID, Direction.toByte(Direction.Left));
        Thread.sleep(600);
        controller.turn(tankID, Direction.toByte(Direction.Down));
        Thread.sleep(600);
        ResponseEntity<BooleanWrapper> turnUp = controller.turn(tankID, Direction.toByte(Direction.Up));

        assertFalse("Vehicle turning from Down to Up should return false",
                turnUp.getBody().isResult());
    }

    /**
     * Tests to make sure tank can make turn
     */
    @Test
    public void validateTurn_LeftToDown_ReturnsTrue() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.turn(tankID, Direction.toByte(Direction.Left));
        Thread.sleep(600);
        ResponseEntity<BooleanWrapper> turnDown = controller.turn(tankID, Direction.toByte(Direction.Down));

        assertTrue("Vehicle turning from Left to Down should return true",
                turnDown.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not make two turns at once
     */
    @Ignore
    public void validateTurn_TooFast_ReturnsTrue() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> first = controller.turn(tankID, Direction.toByte(Direction.Left));
        assertTrue("Vehicle turning first time should return true",
                first.getBody().isResult());
        ResponseEntity<BooleanWrapper> second = controller.turn(tankID, Direction.toByte(Direction.Down));
        assertFalse("Vehicle turning second time without wait should return false",
                second.getBody().isResult());
    }

    /**
     * Tests to make sure tank can turn two times with at less 0.5 second wait
     */
    @Test
    public void validateTurn_TwoTmeWithGap_ReturnsTrue() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> first = controller.turn(tankID, Direction.toByte(Direction.Left));
        assertTrue("Vehicle turning first time should return true",
                first.getBody().isResult());
        Thread.sleep(600);
        ResponseEntity<BooleanWrapper> second = controller.turn(tankID, Direction.toByte(Direction.Down));
        assertTrue("Vehicle turning second time with wait should return true",
                second.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not make two moves at once
     */
    @Ignore
    public void validateMove_TooFast_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.move(tankID, Direction.toByte(Direction.Up));
        ResponseEntity<BooleanWrapper> secondMove = controller.move(tankID, Direction.toByte(Direction.Up));
        assertFalse("Vehicle move second time without wait should return false", secondMove.getBody().isResult());
    }

    /**
     * Tests to make sure tank can move two times with at less 0.5 second wait
     */
    @Ignore
    public void validateMove_MoveTwoTimeWithGap_ReturnsTrue() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.move(tankID, Direction.toByte(Direction.Up));
        Thread.sleep(1100);
        ResponseEntity<BooleanWrapper> secondMove = controller.move(tankID, Direction.toByte(Direction.Up));
        assertTrue("Vehicle move second time with wait should return true", secondMove.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not move sideways to the direction is facing
     */
    @Test
    public void validateMove_MoveSidewaysWhileFacingLeftOrRight_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        controller.turn(tankID, Direction.toByte(Direction.Left));
        Thread.sleep(1100);
        ResponseEntity<BooleanWrapper> moveSideways = controller.move(tankID, Direction.toByte(Direction.Up));
        assertFalse("Move the sideways while the tank facing left should return false", moveSideways.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not move sideways to the direction is facing
     */
    @Test
    public void validateMove_MoveSidewaysWhileFacingUpOrDown_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> moveSideways = controller.move(tankID, Direction.toByte(Direction.Left));
        assertFalse("Move the sideways while the tank facing up should return false", moveSideways.getBody().isResult());
    }

    /**
     * Tests to make sure tank can not fire two times at once
     */
    @Test
    public void validateFire_TooFast_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> firstMove = controller.fire(tankID, 1);
        assertTrue("Vehicle fire first time should return true", firstMove.getBody().isResult());
        ResponseEntity<BooleanWrapper> secondMove = controller.fire(tankID, 1);
        assertFalse("Vehicle fire second time without gap should return false", secondMove.getBody().isResult());
    }

    /**
     * Tests to make sure tank can fire two times with at less 0.5 second wait
     */
    @Test
    public void validateFire_TwoTimeWithGap_ReturnsFalse() throws Exception {
        ResponseEntity<LongWrapper> join = controller.join(createRequest("0.0.0.0"), -1);
        long tankID = join.getBody().getResult();

        ResponseEntity<BooleanWrapper> firstMove = controller.fire(tankID, 1);
        assertTrue("Vehicle fire first time should return true", firstMove.getBody().isResult());
        Thread.sleep(1100);
        ResponseEntity<BooleanWrapper> secondMove = controller.fire(tankID, 1);
        assertTrue("Vehicle fire second time with gap should return true", secondMove.getBody().isResult());
    }

    /**
     * Tests leaving a game after joining.
     */
    @Test
    public void leave_existingUser_leavesGame() {
        HttpServletRequest req = createRequest("1.2.3.4");
        long tankID = controller.join(req, -1).getBody().getResult();
        HttpStatus leave = null;
        try {
            leave = controller.leave(tankID);
        } catch (TankDoesNotExistException e) {
            fail("Vehicle should exist in game before leaving");
        }
        assertTrue("Leaving should be successful", leave.is2xxSuccessful());
    }

    /**
     * Tests leaving a game before joining.
     */
    @Test
    public void leave_noUser_throwsError() {
        HttpServletRequest req = createRequest("2.1.3.4");
        controller.join(req, -1);  // Join the game to ensure that a game is created
        boolean success = false;
        try {
            controller.leave(-1);
        } catch (TankDoesNotExistException e) {
            success = true;
        }
        assertTrue("Leaving a game with nonexistent ID should not work", success);
    }

    @Test
    public void stats_tank_getsStats() {
        HttpServletRequest request = createRequest("31.31.31.31");
        ResponseEntity<LongWrapper> join = controller.join(request, -1);
        long tankId = join.getBody().getResult();
        Vehicle vehicle = Game.getInstance().getVehicle(tankId);
        int position = vehicle.getParent().getPosition();

        ResponseEntity<StringArrayWrapper> stats = null;
        try {
            stats = controller.stats(position);
        } catch (TankDoesNotExistException e) {
            fail("Tank was not found");
        }

        for (String s : stats.getBody().getGrid()) System.out.println(s);


        assertTrue("More than 1 stats should be returned",
                stats != null && stats.getBody().getGrid().length > 0);
    }

    @Test
    public void stats_nonExistent_emptyStats() {
        ResponseEntity<StringArrayWrapper> stats = null;
        try {
            stats = controller.stats(-1);
        } catch (TankDoesNotExistException e) {
            System.out.println("Tank not found");
        }

        assertTrue("Stats should be empty",
                stats != null && stats.getBody().getGrid().length == 0);
    }
}