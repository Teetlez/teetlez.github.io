package edu.unh.cs.cs619.bulletzone.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;
import edu.unh.cs.cs619.bulletzone.datalayer.ItemCategory;
import edu.unh.cs.cs619.bulletzone.datalayer.ItemProperty;
import edu.unh.cs.cs619.bulletzone.datalayer.ItemType;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.LongWrapper;
import edu.unh.cs.cs619.bulletzone.util.StringArrayWrapper;

@RestController
@RequestMapping(value = "/games/account")
public class AccountController {
    private static final Logger log = LoggerFactory.getLogger(GamesController.class);
    private BulletZoneData bulletZoneData;

    @Autowired
    public AccountController() {
        this.bulletZoneData = BulletZoneData.getInstance();
    }

    /**
     * Constructor for test purposes.
     * @param bzd BulletZoneData.
     */
    public AccountController(BulletZoneData bzd) {
        this.bulletZoneData = bzd;
    }

    /**
     * Handles a PUT request to register a new user account
     *
     * @param name The username
     * @param password The password
     * @return a response w/ success boolean
     */
    @RequestMapping(method = RequestMethod.PUT, value = "register/{name}/{password}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> reqRegisterNew(@PathVariable String name, @PathVariable String password)
    {
        // Log the request
        log.debug("Register '" + name + "' with password '" + password + "'");

        // Create user
        boolean success = false;
        try {
            GameUser user = this.bulletZoneData.users.createUser(name, name, password);
            if (user != null) success = true;
        } catch (Exception e) {
            log.warn("Registering " + name + " failed with message: " + e.getMessage());
        }

        // Return the response (true if account created)
        return new ResponseEntity<BooleanWrapper>(new BooleanWrapper(success),
                HttpStatus.ACCEPTED);
    }

    /**
     * Handles a PUT request to login a user
     *
     * @param name The username
     * @param password The password
     * @return a response w/ the user ID (or -1 if invalid)
     */
    @RequestMapping(method = RequestMethod.PUT, value = "login/{name}/{password}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<LongWrapper> reqLogin(@PathVariable String name, @PathVariable String password)
    {
        // Log the request
        log.debug("Login '" + name + "' with password '" + password + "'");
        GameUser gameUser = this.bulletZoneData.users.validateLogin(name, password);

        // Return the response (return user ID if valid login)
        return new ResponseEntity<LongWrapper>(new LongWrapper(
                    gameUser == null ? -1 : gameUser.getUserID()
                ),
                HttpStatus.ACCEPTED);
    }

    /**
     * Handles a GET request to return all category
     * @return a response includes String array
     */
    @RequestMapping(method = RequestMethod.GET, value = "getCategories", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<StringArrayWrapper> getCategory(){
        // Log the request
        log.debug("getCategories");

        // Collect information
        Collection<ItemCategory> categories = this.bulletZoneData.categories.getCategories();
        ArrayList<String> names = new ArrayList<>();
        for (ItemCategory category : categories) names.add(category.getName());

        // Return the response (list of strings)
        return new ResponseEntity<>(
                new StringArrayWrapper(names.toArray(new String[names.size()])),
                HttpStatus.ACCEPTED);
    }

    /**
     * Handles a GET request to return different component types in a given category
     * @param category The category
     * @return a response includes String array
     */
    @RequestMapping(method = RequestMethod.GET, value = "getTypes/{category}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<StringArrayWrapper> getItem(@PathVariable String category){
        // Log the request
        log.debug("getTypes '" + category + "'");

        Collection<ItemType> itemTypes = this.bulletZoneData.types
                .getItemTypesFromCategory(category);
        Collection<String> itemTypeNames = new ArrayList<>();
        if (itemTypes != null)
            for (ItemType itemType : itemTypes) itemTypeNames.add(itemType.getName());

        // Return the response (list of strings)
        String[] strings = itemTypeNames.toArray(new String[itemTypeNames.size()]);
        return new ResponseEntity<>(new StringArrayWrapper(strings), HttpStatus.ACCEPTED);
    }

    /**
     * Handles a GET request to return item info in a given category
     * @param itemTypeName The item name
     * @return a response includes String array
     */
    @RequestMapping(method = RequestMethod.GET, value = "getItem/{itemTypeName}", produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<StringArrayWrapper> getItemWithName(@PathVariable String itemTypeName){
        // Log the request
        log.debug("getItem '" + itemTypeName + "'");
        // get the item with name
        ItemType item = this.bulletZoneData.types.get(itemTypeName);
        // get the list of category properties
        HashMap<ItemProperty, Integer> categoryProperties = item.getCategory().propertyMap;
        // get a full list of properties to loop for
        Collection<ItemProperty> itemProperties = this.bulletZoneData.properties.getAll();
        // string contain the property name and value
        Collection<String> string = new ArrayList<>();
        if (itemProperties != null) {
            for (ItemProperty itemProperty : itemProperties) {
                // if the property ID is -1 will mean there is no meaning assigned to
                // a PropertyVal column for the ItemCategory that uses it.
                if (categoryProperties.containsKey(itemProperty) && itemProperty.getID() != -1)
                    string.add(itemProperty.getName() + ": " + item.getProperty(itemProperty));
            }
        }

        // Return the response (list of strings)
        String[] output = string.toArray(new String[string.size()]);
        return new ResponseEntity<>(new StringArrayWrapper(output), HttpStatus.ACCEPTED);
    }
}
