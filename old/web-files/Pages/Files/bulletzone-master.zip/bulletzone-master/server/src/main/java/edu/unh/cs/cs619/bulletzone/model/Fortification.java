package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;

public class Fortification extends FieldEntity {
    int terrainValue, pos;
    Double strength, hardness, difficulty, maxSize;

    public Fortification(int pos){
        this.pos = pos;
        terrainValue = 1001;
        difficulty = 0.5;
        maxSize = 10.0;
        strength = 100.0;
        hardness = 1.0;
    }

    @Override
    public FieldEntity copy() {
        return new Fortification(getPos());
    }

    @Override
    public int getIntValue() {
        return terrainValue;
    }

    @Override
    public String toString() {
        return "Fortification";
    }

    public int getPos(){
        return pos;
    }

    @Override
    public void hit(Bullet bullet) {
        super.hit(bullet);
        if (bullet.getDamage() > hardness) {
            strength -= bullet.getDamage();
            System.out.println("Fortification life: " + strength + "/" + BulletZoneData.getInstance().terrains.Wall.getStrength());
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), bullet.getDamage());
        }
        if (strength <= 0) {
            Game.getInstance().getHolderGrid().get(getPos()).clearField();
            Game.getInstance().getHolderGrid().get(getPos()).setTerrainID(10);
            Game.getInstance().getHolderGrid().get(getPos()).updateHistory();
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), 100 * -1);
        }
    }
}
