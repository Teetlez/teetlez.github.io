package edu.unh.cs.cs619.bulletzone.repository;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.TerrainType;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.Terrain;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.Wall;

public class CollisionHandler {
    /**
     * Check if unit is able to enter selected location
     * @param unit Player unit
     * @param destination Location to be placed at
     * @return True if player can be placed
     */
    public static boolean handleTerrainInteraction (Vehicle unit, FieldHolder destination) {
        if (destination.getTerrainID() == 1000 || destination.getTerrainID() == 2000)            // Check if neighbor contains entity is wall
            return false;
        if (destination.isPresent() && destination.getEntity() instanceof Vehicle) return false; // check if it is a vehicle

        Terrain terrain = destination.getTerrain();

        // Check if the terrain is solid OR liquid.
        // If the terrain is both, then it should be fine
        if (terrain.getSolid() && !terrain.getLiquid() &&
                unit.getTerrainObstacleSensitivity() < 0) return false; // is only land and is negative
        else if (terrain.getLiquid() && !terrain.getSolid() &&
                unit.getTerrainObstacleSensitivity() > 0) return false; //  is only water and is positive

        // Check if the vehicle frame is too big to fit inside of a terrain
        // Check if the terrain max size is 0 because roads have 0 max size but allow all vehicles
        if (terrain.getMaxSize() > 0 && unit.getEquipment().getType().getSize() > terrain.getMaxSize()) {
            return false;
        }
        // Check if the current time allows for the extra terrain difficulty of movement.
        long currentTime = System.currentTimeMillis();

        // Multiply the vehicle's terrain sensitivity with terrain's difficulty.
        // This will be the extra time needed to enter the terrain.
        long expectedAllowedTime = (long) (unit.getNextAllowMoveTime()
                + Math.abs(unit.getTerrainObstacleSensitivity())
                * terrain.getDifficulty());

        // Since the expected time will be changed depending on the terrain,
        // check the current time with the new expected time.
        if (currentTime <= expectedAllowedTime) return false;

        System.out.println("Player " + unit.getId() + " Placed At " + terrain.getName());
        return true;
    }

    /**
     * Check if player can enter the tank when they move into one.
     * @param soldier player
     * @param destination where to go
     * @return True if vehicle can be tale over
     */
    public static boolean handleCommandeeringVehicle(Vehicle soldier, FieldHolder destination) {
        if (soldier.toString().equals("SOLDIER") &&         // if player is a soldier and destination is an empty vehicle
                ((Vehicle) destination.getEntity()).getId() == 0) {

            Vehicle emptyVehicle = (Vehicle) destination.getEntity();

            if (!emptyVehicle.getPreviousOwner().contains(soldier.getId())) {
                Game.getInstance().gainOrLostScore(soldier.getId(), (long) (5 * emptyVehicle.getEquipment().getSize()));
                emptyVehicle.getPreviousOwner().add(soldier.getId());
            }

            // set tank id as soldier take over
            emptyVehicle.setId(soldier.getId());
            emptyVehicle.setNextAllowEjectTime(System.currentTimeMillis() + 5000);
            emptyVehicle.getParent().updateHistory();

            // add takeover tank into hash map with soldier's score by overwrite the old entry
            Game.getInstance().addVehicle(soldier.getIp(), emptyVehicle, Game.getInstance().getScore(soldier.getId()));
            return true;
        }
        return false;
    }
}
