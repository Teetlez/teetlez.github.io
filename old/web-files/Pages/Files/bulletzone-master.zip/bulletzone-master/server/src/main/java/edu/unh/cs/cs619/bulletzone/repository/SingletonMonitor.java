package edu.unh.cs.cs619.bulletzone.repository;

/**
 * Singleton monitor object used for synchronization purposes.
 *
 * I think that there are going to be multiple classes that use a monitor for synchronizing
 * object movements and actions throughout the board.
 *
 * We can use this class to give one single monitor that can persist throughout different
 * classes and ensure that things are synchronized throughout the entire backend.
 */
public class SingletonMonitor {
    private static final Object monitor = new Object();

    private SingletonMonitor() {
        // Empty constructor to prevent instantiation of this singleton.
    }

    /**
     * Retrieve the monitor.
     * @return Monitor Object.
     */
    public static Object getMonitor() {
        return monitor;
    }
}
