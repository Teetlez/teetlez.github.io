package edu.unh.cs.cs619.bulletzone.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.repository.BulletTask;

import static edu.unh.cs.cs619.bulletzone.model.Direction.Down;
import static edu.unh.cs.cs619.bulletzone.model.Direction.Left;
import static edu.unh.cs.cs619.bulletzone.model.Direction.Right;
import static edu.unh.cs.cs619.bulletzone.model.Direction.Up;

public class Vehicle extends FieldEntity {

    private GameItemContainer equipment;
    private final VehicleType type;
    private long id;
    private final String ip;
    private long nextAllowMoveTime;
    private long lastFireTime;
    private int allowedMoveInterval;
    private int allowedFireInterval;
    private int numberOfBullets;
    private int life;
    private Direction direction;
    private ArrayList<Integer> activeBullets = new ArrayList<>();
    private double totalElectricPower;
    private double availablePower;
    private long lastTimePowerUsed;
    private int fireCount;
    private long nextAllowEjectTime;
    private ArrayList<Long> previousOwner = new ArrayList<>();

    public Vehicle(VehicleType type, long id, Direction direction, String ip) {
        this.type = type;
        this.id = id;
        this.direction = direction;
        this.ip = ip;
        numberOfBullets = 0;
        lastFireTime = 0;
        allowedFireInterval = 500;
        nextAllowMoveTime = 0;
        allowedMoveInterval = 500;
        totalElectricPower = 0;
        lastTimePowerUsed = System.currentTimeMillis();
        availablePower = 0;
        fireCount = 0;
        setNextAllowEjectTime(System.currentTimeMillis() + 5000);
    }

    @Override
    public FieldEntity copy() {
        return new Vehicle(type, id, direction, ip);
    }

    @Override
    public void hit(Bullet bullet) {
        life = life - bullet.getDamage();
        Game.getInstance().gainOrLostScore(bullet.getVehicleId(), bullet.getDamage());
        System.out.println("Vehicle life: " + id + " : " + life);
//		Log.d(TAG, "TankId: " + id + " hit -> life: " + life);

        if (getLife() <= 0) {
            getParent().clearField();
            setParent(null);
            Game.getInstance().removeVehicle(getId());
            int price = (int) equipment.getProperty(BulletZoneData.getInstance().properties.Price);
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), price);

        } else {
            parent.updateHistory();
        }
    }

    public ArrayList<Integer> getActiveBullets() {
        return activeBullets;
    }

    public ArrayList<Long> getPreviousOwner() {
        return previousOwner;
    }

    public long getNextAllowMoveTime() {
        return nextAllowMoveTime;
    }

    public void setNextAllowMoveTime(long nextAllowMoveTime) {
        this.nextAllowMoveTime = nextAllowMoveTime;
    }

    public long getAllowedMoveInterval() {
        return allowedMoveInterval;
    }

    public void setAllowedMoveInterval(int allowedMoveInterval) {
        this.allowedMoveInterval = allowedMoveInterval;
    }

    public long getLastFireTime() {
        return lastFireTime;
    }

    public void setLastFireTime(long lastFireTime) {
        this.lastFireTime = lastFireTime;
    }

    public long getAllowedFireInterval() {
        return allowedFireInterval;
    }

    public void setAllowedFireInterval(int allowedFireInterval) {
        this.allowedFireInterval = allowedFireInterval;
    }

    public long getNextAllowEjectTime() {
        return nextAllowEjectTime;
    }

    public void setNextAllowEjectTime(long nextAllowEjectTime) {
        this.nextAllowEjectTime = nextAllowEjectTime;
    }

    public int getNumberOfBullets() {
        return numberOfBullets;
    }

    public void setNumberOfBullets(int numberOfBullets) {
        this.numberOfBullets = numberOfBullets;
    }

    public int getAllowedNumberOfBullets() {
        return (int)equipment.getProperty(BulletZoneData.getInstance().properties.InstanceLimit);
    }

    public void setAllowedNumberOfBullets(int allowedNumberOfBullets) {
        // Empty the array list that is used to track the active bullets
        activeBullets.clear();
        for (int i = 0; i < allowedNumberOfBullets; i++) activeBullets.add(0);
    }

    public double getBulletDamage() {
        return equipment.getProperty(BulletZoneData.getInstance().properties.Damage);
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public void setId(long id) {
        this.id = id;
    }

    @JsonIgnore
    public long getId() {
        return id;
    }

    @Override
    public int getIntValue() {
        return (int) (type.getNumber() * 10000000 + 10000 * id + 10 * life + Direction
                .toByte(direction));
    }

    @Override
    public String toString() {
        if (type.getNumber() == 3) return "SHIP";
        else if (type.getNumber() == 2) return "TRUCK";
        else if (type.getNumber() == 1) return "TANK";
        else return "SOLDIER";
    }

    public void setEquipment(GameItemContainer equipment) {
        this.equipment = equipment;
        updateTankStats(equipment);
    }

    public double getAvailablePower() {
        return availablePower;
    }

    public double getTotalElectricPower() {
        return totalElectricPower;
    }

    public long getLastTimePowerUsed() {
        return lastTimePowerUsed;
    }

    public double getTerrainObstacleSensitivity() {
        return equipment.getProperty(BulletZoneData.getInstance().properties.TerrainObstacleSensitivity);
    }

    public void updateTankStats(GameItemContainer equipment) {
        double movementWeightRatio = equipment.getProperty(BulletZoneData.getInstance().properties.MovementToWeightRatio);
        if (movementWeightRatio*getDrivePower() != 0)
            setAllowedMoveInterval((int) (getWeight()/(movementWeightRatio*getDrivePower())*1000)); // to convert into millisecond

        totalElectricPower = equipment.getProperty(BulletZoneData.getInstance().properties.ElectricPower);
        availablePower = equipment.getProperty(BulletZoneData.getInstance().properties.ElectricPowerUsed);;
        setLife((int) equipment.getProperty(BulletZoneData.getInstance().properties.Armor));
        setAllowedNumberOfBullets((int)equipment.getProperty(BulletZoneData.getInstance().properties.InstanceLimit));

        if (getTotalElectricPower() != 0 && getWeaponPowerUsage() != 0)
            setAllowedFireInterval((int) (1000/(getTotalElectricPower()/getWeaponPowerUsage())));
    }
    public double getWeight() {
        return equipment.getProperty(BulletZoneData.getInstance().properties.Weight);
    }

    public double getDrivePower() {
        return equipment.getProperty(BulletZoneData.getInstance().properties.DrivePower);
    }

    public GameItemContainer getEquipment() {
        return equipment;
    }

    public int getLife() {
        return life;
    }

    public void setLife(int life) {
        this.life = life;
    }

    public String getIp(){
        return ip;
    }

    public void updateAvailablePower(long millis, double powerUsed) {
        // update the power - millisecond time 1000 to get second
        availablePower += (millis - lastTimePowerUsed) / 1000 * getTotalElectricPower();
        // maximum amount of power available is the maximum amount that can be used
        if (availablePower >= getTotalElectricPower())
            availablePower = getTotalElectricPower();
        // lost power on fire
        availablePower -= powerUsed;
        lastTimePowerUsed = millis;
    }

    public double getWeaponPowerUsage() {
        double weaponPowerUsage = 0;
        for (GameItem item : equipment.getItems()) {
            if (item.getType().getCategory().toString().equals("Weapon"))
                weaponPowerUsage += item.getProperty(BulletZoneData.getInstance().properties.ElectricPowerUsed);
        }
        return weaponPowerUsage;
    }

    public double getEnginePowerUsage() {
        double enginePowerUsage = 0;

        for (GameItem item : equipment.getItems()) {
            if (item.getType().getCategory().toString().equals("Engine"))
                enginePowerUsage += Math.abs(item.getProperty(BulletZoneData.getInstance().properties.ElectricPowerUsed));
        }
        return enginePowerUsage;
    }

    /**
     * Handles a vehicle turn to a given direction.
     * This method assumes that the turn is allowed to happen.
     * @param direction Direction for the vehicle to turn.
     */
    public void turn(Direction direction) {
        long time = System.currentTimeMillis();
        this.setNextAllowMoveTime(time + this.getAllowedMoveInterval());
        this.setDirection(direction);
        parent.updateHistory();
    }

    /**
     * Move a vehicle in a given direction.
     * This assumes that the vehicle is facing a valid direction
     * for it to move in the given direction.
     * @param direction Direction to move the vehicle in.
     */
    public void move(Direction direction) {
        // Set new last move time
        long millis = System.currentTimeMillis();

        updateAvailablePower(millis, getEnginePowerUsage());

        this.setNextAllowMoveTime(millis + this.getAllowedMoveInterval());

        // Move this entity to the next field in given direction
        FieldHolder parent = this.getParent();
        FieldHolder nextField = parent.getNeighbor(direction);
        parent.clearField();

        // do not clear field if it is a vehicle
        if ((type.getNumber() == 4 && nextField.isPresent() && nextField.getEntity() instanceof Vehicle)) {
        } else {
            nextField.setFieldEntity(this);
            this.setParent(nextField);
        }
    }

    public void setTotalElectricPower(double totalElectricPower) {
        this.totalElectricPower = totalElectricPower;
    }

    public void setFireCount(int fireCount) {
        this.fireCount = fireCount;
    }

    /**
     * Eject the soldier to the one of the eight square around the vehicle
     * Assume that vehicle can eject soldier
     * @param fieldHolder Position of where soldier will be ejected
     */
    public void eject(FieldHolder fieldHolder, Vehicle soldier) {
        // create the soldier and set the equipment
        fieldHolder.clearField();
        fieldHolder.setFieldEntity(soldier);
        soldier.setParent(fieldHolder);

        // mark vehicle as empty
        setId(0);
        this.getParent().updateHistory();
        // add soldier into hashmap by overwrite the vehicle entry
        Game.getInstance().addVehicle(ip, soldier, Game.getInstance().getScore(soldier.getId()));
    }

    /**
     * Fire a bullet in the current direction that the vehicle is facing.
     * Assumes that the vehicle is allowed to fire the bullet.
     * @param bulletType Type of bullet to fire.
     */
    public void fire(int bulletType) {
        long millis = System.currentTimeMillis();

        updateAvailablePower(millis, getWeaponPowerUsage());

        setNumberOfBullets(getNumberOfBullets() + 1);

        if (!(bulletType >= 1 && bulletType <= 3)) {
            System.out.println("Bullet type must be 1, 2 or 3, set to 1 by default.");
            bulletType = 1;
        }

        setLastFireTime(millis + getAllowedFireInterval());

        int bulletId = 0;
        for (int i = 0; i < activeBullets.size(); i++) {
            if (activeBullets.get(i) == 1) continue;
            bulletId = i;
            activeBullets.set(i, 1);
            break;
        }

        // Create a new bullet to fire and bullet damage depend on what weapon is equip
        final Bullet bullet = new Bullet(this, direction, (int) getBulletDamage());
        // Set the same parent for the bullet.
        // This should be only a one way reference.
        bullet.setParent(parent);
        bullet.setBulletId(bulletId);

        Game.getInstance().getTimer().schedule(new BulletTask(bullet), 0, Game.BULLET_PERIOD);
        fireCount++;
        if (fireCount%10 == 0)
            Game.getInstance().gainOrLostScore(id, bulletType * -1);
    }
}
