package edu.unh.cs.cs619.bulletzone.web;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;
import edu.unh.cs.cs619.bulletzone.repository.GaragebayRepository;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.GaragebayWrapper;

import static org.junit.Assert.*;

public class GaragebayControllerTest {
    private static int counter = 0;

    private BulletZoneData bulletZoneData;
    private GaragebayRepository garagebayRepository;
    private GaragebayController garagebayController;

    @Before
    public void setUp() {
        bulletZoneData = new BulletZoneData();
        garagebayRepository = new GaragebayRepository(bulletZoneData);
        garagebayController = new GaragebayController(garagebayRepository);
    }

    @Test
    public void getGaragebay_NoUser_Fails() {
        ResponseEntity<GaragebayWrapper> garagebay = garagebayController
                .getGaragebay(-1);
        assertNull("Garage bay should be null", garagebay.getBody());
    }

    @Test
    public void getGaragebay_NewUser_ReturnsGarageBay() {
        GameUser p = bulletZoneData.users.createUser("",
                "user" + counter++, "p");
        ResponseEntity<GaragebayWrapper> garagebay = garagebayController
                .getGaragebay(p.getUserID());
        assertNotNull("Garage bay should not be null", garagebay.getBody());
    }

    @Test
    public void addContainerToUserGaragebay_OneItem_CreatesItem() {
        GameUser p = bulletZoneData.users.createUser("",
                "user" + counter++, "p");
        int initial = garagebayController.getGaragebay(p.getUserID()).getBody().getItems().length;

        garagebayController.addContainerToUserGaragebay(p.getUserID(),
                bulletZoneData.types.TruckFrame.getName());
        int after = garagebayController.getGaragebay(p.getUserID()).getBody().getItems().length;

        assertEquals("Adding an item should make garage bay increase in size",
                1, after - initial);
    }

    @Test
    public void addContainerToUserGaragebay_FakeUser_Fails() {
        ResponseEntity<BooleanWrapper> response = garagebayController
                .addContainerToUserGaragebay(-1, bulletZoneData.types.TruckFrame.getName());
        assertFalse("Adding a frame to a non-existent user's garage bay should fail",
                response.getBody().isResult());
    }

    @Test
    public void removeContainerFromUserGaragebay_NonItem_Fails() {
        GameUser p = bulletZoneData.users
                .createUser("", "user" + counter++, "p");
        ResponseEntity<BooleanWrapper> response = garagebayController
                .removeContainerFromUserGaragebay(p.getUserID(), -1);
        assertFalse("Removing an item that doesn't exist should return false",
                response.getBody().isResult());
    }

    @Test
    public void removeContainerFromUserGaragebay_NotOwned_Fails() {
        GameUser p = bulletZoneData.users
                .createUser("", "user" + counter++, "p");
        GameUser p2 = bulletZoneData.users
                .createUser("", "user" + counter++, "p");

        // Add item to the user's garage bay
        garagebayController.addContainerToUserGaragebay(p.getUserID(),
                bulletZoneData.types.TruckFrame.getName());

        // get added item's id
        ResponseEntity<GaragebayWrapper> bay = garagebayController.getGaragebay(p.getUserID());
        GameItem[] items = bay.getBody().getItems();
        int itemId = items[0].getItemID();

        ResponseEntity<BooleanWrapper> response = garagebayController
                .removeContainerFromUserGaragebay(p2.getUserID(), itemId);
        assertFalse("Removing an item that isn't owned by the user should return false",
                response.getBody().isResult());
    }

    @Test
    public void addItemToContainer_RealContainer_AddsItem() {
        GameUser user = bulletZoneData.users.createUser("",
                "user" + counter++, "p");

        // add truck frame to the garage bay
        garagebayController.addContainerToUserGaragebay(user.getUserID(),
                bulletZoneData.types.TruckFrame.getName());

        ResponseEntity<GaragebayWrapper> bay = garagebayController.getGaragebay(user.getUserID());
        GameItemContainer[] containers = bay.getBody().getItems();

        garagebayController.addItemToContainer(containers[0].getItemID(),
                bulletZoneData.types.TruckEngine.getName());

        assertEquals("Adding an item should make the size 1",
                1, containers[0].getItems().size());
    }

    @Test
    public void addItemToContainer_FakeContainer_Fails() {
        ResponseEntity<BooleanWrapper> res = garagebayController.addItemToContainer(-1,
                bulletZoneData.types.TruckEngine.getName());

        assertFalse("Adding an item to a fake container should not work",
                res.getBody().isResult());
    }

    @Test
    public void removeItemFromContainer_FakeContainer_Fail() {
        ResponseEntity<BooleanWrapper> res = garagebayController
                .removeItemFromContainer(-1, 0);
        assertFalse("Removing an item from a nonexistent container should fail",
                res.getBody().isResult());
    }

    @Test
    public void removeItemFromContainer_RealItem_Passes() {
        GameUser user = bulletZoneData.users.createUser("",
                "user" + counter++, "p");
        garagebayController.addContainerToUserGaragebay(user.getUserID(),
                bulletZoneData.types.TruckFrame.getName());
        GameItemContainer frame = garagebayController.getGaragebay(user.getUserID())
                .getBody().getItems()[0];
        garagebayController.addItemToContainer(frame.getItemID(),
                bulletZoneData.types.TruckEngine.getName());

        for (GameItem item : frame.getItems()) {
            garagebayController.removeItemFromContainer(frame.getItemID(), item.getItemID());
        }

        assertEquals("Frame should be empty after removing item",
                0, frame.getItems().size());
    }
}