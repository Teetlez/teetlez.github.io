package edu.unh.cs.cs619.bulletzone.repository;

import junit.extensions.TestSetup;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.model.Bullet;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.Terrain;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.VehicleType;

import static org.junit.Assert.*;

public class ValidatorTest {
    GameItemContainer ship;

    @Before
    public void setup() {
        ship = BulletZoneData.getInstance().items.createContainer(BulletZoneData.getInstance().types.ShipFrame);
        BulletZoneData.getInstance().items.addItemToContainer(BulletZoneData.getInstance().items.create(BulletZoneData.getInstance().types.ShipGenerator), ship);
        BulletZoneData.getInstance().items.addItemToContainer(BulletZoneData.getInstance().items.create(BulletZoneData.getInstance().types.ShipDriveImpellers), ship);
        BulletZoneData.getInstance().items.addItemToContainer(BulletZoneData.getInstance().items.create(BulletZoneData.getInstance().types.ShipEngine), ship);
    }
    @Test
    public void validateMove_EmptyNeighbor_ReturnsTrue() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        FieldHolder neighbor = new FieldHolder(0);
        neighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        vehicle.setParent(parent);

        // One-way association just for testing purposes
        parent.addNeighbor(Direction.Up, neighbor);

        // Test validate moving up
        assertTrue("Moving up into empty fieldholder should return true",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_NullNeighbor_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        vehicle.setParent(parent);

        // Test validate moving up
        assertFalse("Moving into null neighbor should return false",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_NeighborWithEntity_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        Vehicle vehicleNeighbor = new Vehicle(VehicleType.TANK, 1, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());

        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        FieldHolder neighbor = new FieldHolder(0);
        vehicle.setParent(parent);
        vehicleNeighbor.setParent(neighbor);
        neighbor.setFieldEntity(vehicleNeighbor);

        // Associate fieldholder
        parent.addNeighbor(Direction.Up, neighbor);

        // Test validate moving up
        assertFalse("Moving into occupied field should return false",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateEject_NoOpenLocation_ReturnsFalse() throws Exception {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0,0,0,0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        Assert.assertTrue("Eject soldier when surrounded by wall should return -1 as no available space",
                Validator.validateEject(vehicle) == null);
    }

    @Test
    public void validateEject_OpenUpLocation_ReturnsTrue() throws Exception {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0,0,0,0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        FieldHolder parent = Game.getInstance().getHolderGrid().get(50);
        parent.setFieldEntity(vehicle);
        vehicle.setParent(parent);
        parent.getNeighbor(Direction.Up).clearField();
        parent.getNeighbor(Direction.Up).setTerrainID(-1);
        vehicle.setNextAllowEjectTime(System.currentTimeMillis() - 7000);
        Assert.assertTrue("Eject soldier with one open location should return the space that is open",
                Validator.validateEject(vehicle) != null);
    }

    @Test
    public void validateUpdateStats_EquipOneItem_ReturnTrue() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        GameItemContainer container = vehicle.getEquipment();
        for (GameItem item : container.getItems()) {
            System.out.println(item.toString());
        }
    }
    @Test
    public void validateMove_MoveWaterUnitIntoLandTerrain_ReutrnFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.SHIP, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(ship);
        FieldHolder parent = new FieldHolder(206);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.OpenWater, 0));
        parent.setTerrainID(50);
        FieldHolder neighbor = new FieldHolder(191);
        neighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        neighbor.setTerrainID(900);
        vehicle.setParent(parent);
        parent.addNeighbor(Direction.Up, neighbor);

        assertFalse("Moving water unit into land terrain should return false",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_MoveWaterUnitIntoWaterTerrain_ReutrnTrue() {
        Vehicle vehicle = new Vehicle(VehicleType.SHIP, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(ship);
        FieldHolder parent = new FieldHolder(223);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.OpenWater, 0));
        parent.setTerrainID(50);
        FieldHolder neighbor = new FieldHolder(207);
        neighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.OpenWater, 0));
        neighbor.setTerrainID(50);
        vehicle.setParent(parent);
        parent.addNeighbor(Direction.Up, neighbor);

        assertTrue("Moving water unit into water terrain should return true",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_MoveLandUnitIntoWater_ReutrnFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Down, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        FieldHolder parent = new FieldHolder(187);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        parent.setTerrainID(40);
        FieldHolder neighbor = new FieldHolder(203);
        neighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.OpenWater, 0));
        neighbor.setTerrainID(50);
        vehicle.setParent(parent);
        parent.addNeighbor(Direction.Down, neighbor);


        assertFalse("Moving land unit into water terrain should return false",
                Validator.validateMove(vehicle, Direction.Down));
    }

    @Test
    public void validateMove_MoveLandUnitIntoLandTerrain_ReutrnTrue() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        FieldHolder parent = new FieldHolder(32);
        FieldHolder neighbor = new FieldHolder(16);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        neighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        vehicle.setParent(parent);
        parent.addNeighbor(Direction.Up, neighbor);

        assertTrue("Moving land unit into land terrain should return true",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_TooFast_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());

        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        FieldHolder neighbor = new FieldHolder(0);
        vehicle.setParent(parent);

        // Associate fieldholder
        parent.addNeighbor(Direction.Up, neighbor);

        // Simulate already done move
        vehicle.setNextAllowMoveTime(System.currentTimeMillis() * 2 + vehicle.getAllowedMoveInterval());

        // Test validate moving up
        assertFalse("Vehicle moving too fast should return false",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_MoveSidewaysWhileFacingUpOrDown_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Down, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());

        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        FieldHolder upNeighbor = new FieldHolder(0);
        FieldHolder leftNeighbor = new FieldHolder(0);
        vehicle.setParent(parent);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        upNeighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        leftNeighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));

        // One-way association just for testing purposes
        parent.addNeighbor(Direction.Up, upNeighbor);
        parent.addNeighbor(Direction.Left, leftNeighbor);

        // Test validate moving sideways while facing up
        assertFalse("Vehicle moving sideways should return false",
                Validator.validateMove(vehicle, Direction.Left));

        // Test validate moving backward
        assertTrue("Vehicle moving backward should return true",
                Validator.validateMove(vehicle, Direction.Up));
    }

    @Test
    public void validateMove_MoveSidewaysWhileFacingLeftOrRight_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Right, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());

        // Create field holders and assign
        FieldHolder parent = new FieldHolder(0);
        parent.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        FieldHolder upNeighbor = new FieldHolder(0);
        upNeighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        FieldHolder leftNeighbor = new FieldHolder(0);
        leftNeighbor.setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Road, 0));
        vehicle.setParent(parent);

        // One-way association just for testing purposes
        parent.addNeighbor(Direction.Up, upNeighbor);
        parent.addNeighbor(Direction.Left, leftNeighbor);

        // Test validate moving sideways while facing left
        assertFalse("Vehicle moving sideways should return false",
                Validator.validateMove(vehicle, Direction.Up));

        // Test validate moving backward
        assertTrue("Vehicle moving backward should return true",
                Validator.validateMove(vehicle, Direction.Left));
    }

    @Test
    public void validateTurn_UpToDown_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");

        assertFalse("Vehicle turning from Up to Down should return false",
                Validator.validateTurn(vehicle, Direction.Down));
    }

    @Test
    public void validateTurn_LeftToRight_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Left, "0.0.0.0");

        assertFalse("Vehicle turning from Left to Right should return false",
                Validator.validateTurn(vehicle, Direction.Right));
    }

    @Test
    public void validateTurn_RightToLeft_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Right, "0.0.0.0");

        assertFalse("Vehicle turning from Right to Left should return false",
                Validator.validateTurn(vehicle, Direction.Left));
    }

    @Test
    public void validateTurn_DownToUp_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Down, "0.0.0.0");

        assertFalse("Vehicle turning from Down to Up should return false",
                Validator.validateTurn(vehicle, Direction.Up));
    }

    @Test
    public void validateTurn_UpToRight_ReturnsTrue() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");

        assertTrue("Vehicle turning from Up to Right should return true",
                Validator.validateTurn(vehicle, Direction.Right));
    }

    @Test
    public void validateTurn_TooFast_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");

        // Simulate already done move
        vehicle.setNextAllowMoveTime(System.currentTimeMillis() * 2 + vehicle.getAllowedMoveInterval());

        // Test validate moving up
        assertFalse("Vehicle turning too fast should return false",
                Validator.validateTurn(vehicle, Direction.Left));
    }

    @Test
    public void validateFire_TooManyBullets_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setEquipment(BulletZoneData.getInstance().getDefaultTank());
        vehicle.setNumberOfBullets(vehicle.getAllowedNumberOfBullets());
        assertFalse("Vehicle shooting too many bullets should return false",
                Validator.validateFire(vehicle, 1));
    }

    @Test
    public void validateFire_TooFast_ReturnsFalse() {
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setLastFireTime(System.currentTimeMillis() * 2 + vehicle.getLastFireTime());
        assertFalse("Vehicle shooting bullets too fast should return false",
                Validator.validateFire(vehicle, 1));
    }
}