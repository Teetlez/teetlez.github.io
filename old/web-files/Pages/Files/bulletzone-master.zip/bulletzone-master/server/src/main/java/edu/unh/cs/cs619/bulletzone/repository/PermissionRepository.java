package edu.unh.cs.cs619.bulletzone.repository;

import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;
import edu.unh.cs.cs619.bulletzone.datalayer.Permission;

@Component
public class PermissionRepository {
    private BulletZoneData bulletZoneData;
    private GaragebayRepository garagebayRepository;

    /**
     * Permission repository constructor.
     * Used by string component autowiring.
     */
    public PermissionRepository() {
        bulletZoneData = BulletZoneData.getInstance();
        garagebayRepository = GaragebayRepository.getInstance();
    }

    /**
     * Test related constructor.
     * @param bulletZoneData Bullet zone data instance.
     * @param garagebayRepository Instance of garagebay repository.
     */
    public PermissionRepository(BulletZoneData bulletZoneData,
                                GaragebayRepository garagebayRepository) {
        this.bulletZoneData = bulletZoneData;
        this.garagebayRepository = garagebayRepository;
    }

    public HashMap<Integer, HashSet<Permission>> getPermissionOnItemID(int itemID) {
        return bulletZoneData.permissions.getItemPermissions(itemID).getUserPermissions();
    }

    public boolean addPermissionToItem(int itemID, int sourceUserID,
                                       String username,Permission permission) {
        if (permission == Permission.Owner) return false;
        if (!hasPermission(sourceUserID, itemID, Permission.Owner)) return false;
        GameUser user = bulletZoneData.users.getUser(username);
        if (user == null) return false;

        boolean granted = bulletZoneData.permissions.grant(itemID, user.getUserID(), permission);
        if (granted) addItemToUserGaragebay(user, itemID);
        return granted;
    }

    public boolean removePermissionFromItem(int itemID, int sourceUserID,
                                            String username, Permission permission) {
        if (permission == Permission.Owner) return false;
        GameItemContainer container = bulletZoneData.items.getContainer(itemID);
        if (container == null) return false;
        if (container.getOwner() != null && !hasPermission(sourceUserID, itemID, Permission.Owner))
            return false;

        GameUser user = bulletZoneData.users.getUser(username);
        if (user == null) return false;
        if (!hasPermission(user.getUserID(), itemID, permission)) return false;

        boolean revoke = bulletZoneData.permissions.revoke(itemID, user.getUserID(), permission);
        boolean stillHasPerms = getPermissionOnItemID(itemID).containsKey(user.getUserID());
        if (revoke && !stillHasPerms) removeItemFromUserGaragebay(user, itemID);
        return revoke;
    }

    public boolean transferOwnership(int itemID, int sourceUserID, String username) {
        GameUser targetUser = bulletZoneData.users.getUser(username);
        if (targetUser == null || targetUser.getUserID() == sourceUserID) return false;

        GameItemContainer container = bulletZoneData.items.getContainer(itemID);
        GameUser originalOwner = container.getOwner();
        if (originalOwner != null
                && !hasPermission(sourceUserID, container.getItemID(), Permission.Owner)
                && !hasPermission(sourceUserID, container.getItemID(), Permission.Transfer))
            return false;

        // Set new owner
        if (originalOwner != null) {
            bulletZoneData.permissions.removeOwner(container);
        }
        bulletZoneData.permissions.setOwner(container, targetUser);
        addItemToUserGaragebay(targetUser, container.getItemID());

        // Update old permissions
        GameUser sourceUser = bulletZoneData.users.getUser(sourceUserID);
        if (sourceUser != null) {
            addPermissionToItem(itemID, targetUser.getUserID(), sourceUser.getUsername(),
                    Permission.Add);
            addPermissionToItem(itemID, targetUser.getUserID(), sourceUser.getUsername(),
                    Permission.Remove);
            addPermissionToItem(itemID, targetUser.getUserID(), sourceUser.getUsername(),
                    Permission.Use);
        }
        if (originalOwner != null && sourceUser.getUserID() != originalOwner.getUserID()) {
            addPermissionToItem(itemID, originalOwner.getUserID(), sourceUser.getUsername(),
                    Permission.Add);
            addPermissionToItem(itemID, originalOwner.getUserID(), sourceUser.getUsername(),
                    Permission.Remove);
            addPermissionToItem(itemID, originalOwner.getUserID(), sourceUser.getUsername(),
                    Permission.Use);
        }
        return true;
    }

    // END OF PUBLIC METHODS
    // END OF PUBLIC METHODS
    // END OF PUBLIC METHODS
    // END OF PUBLIC METHODS
    // END OF PUBLIC METHODS

    /**
     * Check if a given user has a permission on the given item id.
     * @param userID User ID that you want to check.
     * @param itemID Item ID that you want to compare user against.
     * @param permission Permission that you want to check if user has on the item.
     * @return True if the permission exists.
     */
    private boolean hasPermission(int userID, int itemID, Permission permission) {
        HashMap<Integer, HashSet<Permission>> itemPermissions = bulletZoneData.permissions
                .getItemPermissions(itemID).getUserPermissions();

        HashSet<Permission> userPermissions = itemPermissions.get(userID);
        return userPermissions != null && userPermissions.contains(permission);
    }

    /**
     * Remove an item ID from a user's garage bay.
     * @param user User with garage bay.
     * @param itemID ID of the item.
     */
    private void removeItemFromUserGaragebay(GameUser user, int itemID) {
        GameItemContainer garagebay = garagebayRepository.getGarageBay(user.getUserID());
        if (garagebay == null) return;
        bulletZoneData.items.removeItemFromContainer(itemID, garagebay.getItemID());
    }

    /**
     * Add an item ID to the user's garage bay.
     * Only adds it if the item does not exist in the garagebay.
     * @param user User who owns the garage bay.
     * @param itemID Item ID to add to the garage bay.
     */
    private void addItemToUserGaragebay(GameUser user, int itemID) {
        GameItemContainer garagebay = garagebayRepository.getGarageBay(user.getUserID());
        if (garagebay == null) return;
        GameItem found = null;
        for (GameItem item : garagebay.getItems()) {
            if (item.getItemID() == itemID) {
                found = item;
                break;
            }
        }
        if (found != null) return;

        bulletZoneData.items.addItemToContainer(itemID, garagebay.getItemID());
    }

}
