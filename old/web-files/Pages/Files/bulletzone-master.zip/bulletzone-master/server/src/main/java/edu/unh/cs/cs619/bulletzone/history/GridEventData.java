package edu.unh.cs.cs619.bulletzone.history;

/**
 * Class that represents data before it is serialized into a GridEvent to return to the user.
 * It will contain all normal GridEvent data such as timestamp, position, value, but it also
 * includes player id and the value that only shows up for that player.
 */
public class GridEventData {
    private long timestamp;
    private int position;
    private int terrain;
    private int playerId;
    private int playerValue;

    /**
     * Represents the data that can be converted to a grid event.
     * @param position Position of the change in the board. 0 indexed.
     * @param terrain Terrain ID of the cell in the board.
     * @param playerId ID of the player that is hiding. Should only be used if the player is
     *                 hiding in the terrain. If the player is not hiding in the terrain, give -1.
     * @param playerValue Value of the player entity.
     * @param timestamp Timestamp of the grid event.
     */
    public GridEventData(int position, int terrain, int playerId,
                         int playerValue, long timestamp) {
        this.position = position;
        this.terrain = terrain;
        this.playerId = playerId;
        this.playerValue = playerValue;
        this.timestamp = timestamp;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public int getPosition() {
        return position;
    }

    /**
     * Convert data to grid event object.
     *
     * It will take into account the given player id, and create a grid event
     * that represents the data in a user-processable format.
     * @param playerId Player ID of the request being received.
     * @return GridEvent that should be given to that player.
     */
    public GridEvent toGridEvent(int playerId) {
        // Only return the player value if they're not hiding or if the player id matches
        int cleanValue = (this.playerId == -1 || playerId == this.playerId) ? playerValue : -1;
        return new GridEvent(position, cleanValue, terrain, timestamp);
    }

    @Override
    public String toString() {
        return "GridEventData{" +
                "timestamp=" + timestamp +
                ", position=" + position +
                ", terrain=" + terrain +
                ", playerId=" + playerId +
                ", playerValue=" + playerValue +
                '}';
    }
}
