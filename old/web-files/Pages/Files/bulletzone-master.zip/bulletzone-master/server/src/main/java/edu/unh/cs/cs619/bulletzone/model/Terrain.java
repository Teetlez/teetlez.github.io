package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.TerrainType;

public class Terrain extends FieldEntity {

    int pos;
    Double strength;
    TerrainType type;

    public Terrain(TerrainType type, int pos) {
        this.type = type;
        this.pos = pos;
        strength = this.type.getStrength(); // this is hp
    }

    @Override
    public String toString() {
        return this.type.toString();
    }

    @Override
    public int getIntValue() {
        return this.type.getID();
    }

    @Override
    public FieldEntity copy() {
        return new Terrain(type, pos);
    }

    @Override
    public void hit(Bullet bullet) {
        super.hit(bullet);
        if (getIntValue() == 1000) return;

        if (bullet.getDamage() > getHardness()) {
            strength -= bullet.getDamage();
            System.out.println(toString() + " life: " + strength + "/" + this.type.getStrength());
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), bullet.getDamage());
        }
        if (strength <= 0) {
            Game.getInstance().getHolderGrid().get(getPos()).clearField();
            Game.getInstance().getHolderGrid().get(getPos()).setTerrainID(10);
            Game.getInstance().getHolderGrid().get(getPos()).setTerrain(new Terrain(BulletZoneData.getInstance().terrains.Debris, getPos()));
            Game.getInstance().getHolderGrid().get(getPos()).updateHistory();
            Game.getInstance().gainOrLostScore(bullet.getVehicleId(), 100 * -1);
        }
    }

    public Double getStrength() {
        return strength;
    }

    public String getName() {
        return this.type.getName();
    }

    public Double getHardness() {
        return this.type.getHardness();
    }

    public Double getDifficulty() {
        return this.type.getDifficulty();
    }

    public Double getMaxSize() {
        return this.type.getMaxSize();
    }

    public Boolean getSolid() {
        return this.type.isSolid();
    }

    public Boolean getLiquid() {
        return this.type.isLiquid();
    }

    public int getID() { return this.type.getID();}

    public int getPos() {
        return pos;
    }
}
