package edu.unh.cs.cs619.bulletzone.repository;

import java.util.ArrayList;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.datalayer.GameItemContainer;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;

public class GaragebayRepository {
    private static GaragebayRepository instance;
    private BulletZoneData bulletZoneData;

    private GaragebayRepository() {
        bulletZoneData = BulletZoneData.getInstance();
    }

    /**
     * Constructor for testing purposes.
     * @param bulletZoneData Pre existing bullet zone data instance.
     */
    public GaragebayRepository(BulletZoneData bulletZoneData) {
        this.bulletZoneData = bulletZoneData;
    }

    /**
     * Get the current singleton instance of the GarageBayRepository.
     * @return Garagebay Repository.
     */
    public static GaragebayRepository getInstance() {
        if (instance == null) {
            instance = new GaragebayRepository();
        }
        return instance;
    }

    /**
     * Add a given item container to a user's garage bay.
     * This is used to add frames like tanks/ships/trucks.
     * @param userId ID of the user.
     * @param item Item type to add.
     * @return Item ID of the new container.
     */
    public int addContainerToGarageBay(int userId, String item) {
        if (item.equals(bulletZoneData.types.GarageBay.getName())) return -1;
        GameItemContainer garageBay = getGarageBay(userId);
        if (garageBay == null) return -1;

        GameItemContainer container = bulletZoneData.items.createContainer(item);
        bulletZoneData.permissions.setOwner(container.getItemID(), userId);
        bulletZoneData.items.addItemToContainer(container.getItemID(), garageBay.getItemID());
        return container.getItemID();
    }

    /**
     * Remove a container from a user's garage bay.
     * Use this to remove a preset or frame from a garage bay.
     * @param userId User ID of the garage bay owner.
     * @param itemId Item ID that exists within the garage bay.
     * @return True if successful.
     */
    public boolean removeContainerFromGarageBay(int userId, int itemId) {
        GameItemContainer garageBay = getGarageBay(userId);
        if (garageBay == null) return false;
        if (!removeItemsInContainer(itemId)) return false;
        return bulletZoneData.items.removeItemFromContainer(itemId, garageBay.getItemID());
    }

    /**
     * Remove an item ID from a container.
     * Used to remove an item from a garage bay frame/preset.
     * @param itemId Item ID to remove.
     * @param containerId Container ID that contains the item.
     * @return True if successful.
     */
    public boolean removeItemFromContainer(int itemId, int containerId) {
        if (!bulletZoneData.items.removeItemFromContainer(itemId, containerId)) return false;
        if (!bulletZoneData.items.delete(itemId)) return false;
        return true;
    }

    /**
     * Add an item to a container.
     * Used to add an item to a given container which represents a garage bay frame/preset.
     * @param containerId Frame/preset ID.
     * @param itemType Name of the item to add.
     * @return Item ID of new item.
     */
    public int addItemToContainer(int containerId, String itemType) {
        if (itemType.equals(bulletZoneData.types.GarageBay.getName())) return -1;
        GameItem gameItem = bulletZoneData.items.create(itemType);

        // Check if container is none
        GameItemContainer container = bulletZoneData.items.getContainer(containerId);
        if (container == null) return -1;

        // Calculate weight left for container
        double weightLeft = container.getProperty(bulletZoneData.properties.Capacity);
        for (GameItem item : container.getItems()) {
            weightLeft -= item.getSize();
        }

        if (weightLeft < gameItem.getWeight() ||
                !bulletZoneData.items.addItemToContainer(gameItem.getItemID(), containerId)) {
            // new game item is too heavy for the frame
            bulletZoneData.items.delete(gameItem.getItemID());
            return -1;
        }

        return gameItem.getItemID();
    }

    /**
     * Clear all items inside of a container.
     * Should be used before deleting a container.
     * Useful if the user wants to delete a whole container / preset.
     * Cleans up items that are going to be deleted, otherwise the items will be leaked.
     * @param containerId ID of the container.
     * @return True if successful.
     */
    private boolean removeItemsInContainer(int containerId) {
        GameItemContainer container = bulletZoneData.items.getContainer(containerId);
        if (container == null) return false;
        if (container.getType().getName().equals(bulletZoneData.types.GarageBay)) return false;
        ArrayList<Integer> itemIDs = new ArrayList<>();
        // Need 2 for loops because you can't modify the items list while you're reading it
        for (GameItem item : container.getItems()) itemIDs.add(item.getItemID());
        for (Integer itemID : itemIDs) {
            bulletZoneData.items.removeItemFromContainer(itemID, container.getItemID());
            bulletZoneData.items.delete(itemID);
        }
        return true;
    }

    /**
     * Get a garage bay from a user id.
     * Should only be used for testing purposes or if you know the implications of this method.
     * If there is no garage bay, then create one.
     * @param userId User ID.
     * @return Garage bay game item container.
     */
    public GameItemContainer getGarageBay(int userId) {
        GameUser user = bulletZoneData.users.getUser(userId);
        if (user == null) return null;

        GameItemContainer garageBay = null;
        for (GameItemContainer ownedItem : user.getOwnedItems()) {
            if (ownedItem.getType().getName().equals(bulletZoneData.types.GarageBay.getName())) {
                garageBay = ownedItem;
                break;
            }
        }

        if (garageBay == null) garageBay = createGarageBay(userId);

        return garageBay;
    }

    /**
     * Creates a garage bay for a given user.
     * Assumes that the user exists.
     * @param userId User ID that owns the garage bay.
     * @return Game item container representing the garage bay.
     */
    private GameItemContainer createGarageBay(int userId) {
        GameItemContainer gb = bulletZoneData.items
                .createContainer(bulletZoneData.types.GarageBay);
        bulletZoneData.permissions.setOwner(gb.getItemID(), userId);
        return gb;
    }
}
