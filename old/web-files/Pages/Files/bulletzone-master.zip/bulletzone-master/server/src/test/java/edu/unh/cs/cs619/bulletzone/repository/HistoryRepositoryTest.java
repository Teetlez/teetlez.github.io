package edu.unh.cs.cs619.bulletzone.repository;

import org.junit.Before;
import org.junit.Test;

import edu.unh.cs.cs619.bulletzone.history.GridEventData;
import edu.unh.cs.cs619.bulletzone.model.Bullet;
import edu.unh.cs.cs619.bulletzone.model.Direction;
import edu.unh.cs.cs619.bulletzone.model.FieldHolder;
import edu.unh.cs.cs619.bulletzone.model.Game;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.model.VehicleType;

import static org.junit.Assert.*;

public class HistoryRepositoryTest {
    private Game game = Game.getInstance();

    @Before
    public void setUp() throws Exception {
        HistoryRepository.getInstance().getEventData().clear();
        game = Game.newGame();
    }

    @Test
    public void addEvent_GameCreation_AddsEvents() {
        for (GridEventData gridEvent : HistoryRepository.getInstance().getEventData()) {
            System.out.println(gridEvent);
        }
        assertTrue("History repository should hold grid events from game creation",
                HistoryRepository.getInstance().getEventData().size() > 0);
    }

    @Test
    public void addEvent_TankJoin_AddsOneEvent() {
        int initial = HistoryRepository.getInstance().getEventData().size();
        System.out.println("Initial history repo has " + initial + " events");

        // Create the vehicle
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setLife(100);
        game.addVehicle("0.0.0.0", vehicle, 0);

        // Place the vehicle somewhere
        // Basically I copied whatever the InMemoryGameRepository does to put a vehicle
        FieldHolder fieldHolder = game.getHolderGrid().get(0);
        fieldHolder.setFieldEntity(vehicle);

        int newAmount = HistoryRepository.getInstance().getEventData().size();
        System.out.println("New history repo has " + newAmount + " events");

        assertTrue("Vehicle joining game should create one grid event",
                newAmount - initial == 1);
    }

    @Test
    public void addEvent_TankTurn_AddsOneEvent() {
        // Create the vehicle and place it somewhere
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setLife(100);
        game.addVehicle("0.0.0.0", vehicle, 0);
        FieldHolder fieldHolder = game.getHolderGrid().get(0);
        fieldHolder.setFieldEntity(vehicle);  // Set two-way association first
        vehicle.setParent(fieldHolder);

        // Check if turning adds 1
        int initial = HistoryRepository.getInstance().getEventData().size();
        System.out.println("History repo has " + initial + " events");

        vehicle.turn(Direction.Right);

        int newAmount = HistoryRepository.getInstance().getEventData().size();
        System.out.println("New history repo has " + newAmount + " events");

        assertTrue("Vehicle turning should create one grid event",
                newAmount - initial == 1);
    }

    @Test
    public void addEvent_TankHit_AddsOneEvent() {
        // Create the vehicle and place it somewhere
        Vehicle vehicle = new Vehicle(VehicleType.TANK, 0, Direction.Up, "0.0.0.0");
        vehicle.setLife(100);
        game.addVehicle("0.0.0.0", vehicle, 0);
        FieldHolder fieldHolder = game.getHolderGrid().get(0);
        fieldHolder.setFieldEntity(vehicle);  // Set two-way association first
        vehicle.setParent(fieldHolder);

        // Check if turning adds 1
        int initial = HistoryRepository.getInstance().getEventData().size();
        System.out.println("History repo has " + initial + " events");

        Bullet bullet = new Bullet(vehicle, vehicle.getDirection(), (int) 10);

        vehicle.hit(bullet);

        int newAmount = HistoryRepository.getInstance().getEventData().size();
        System.out.println("New history repo has " + newAmount + " events");

        assertTrue("Vehicle taking damage should create one grid event",
                newAmount - initial == 1);
    }

    @Test
    public void getGridEvents_OlderThan3Minutes_DoesNotReturn() {
        // Clear because we do not want game data
        HistoryRepository.getInstance().getEventData().clear();

        // Add an event that is 4 minutes in the past
        long timestamp = System.currentTimeMillis() - 1000 * 60 * 4;
        HistoryRepository.getInstance().addEvent(0, 0, -1, -1, timestamp);
        HistoryRepository.getInstance().addEvent(0, 1, -1, -1, System.currentTimeMillis());

        // Get events
        long receiveTimestamp = System.currentTimeMillis() - 1000 * 60 * 2;
        assertEquals("History should only return one event", 1,
                HistoryRepository.getInstance().getEventData(receiveTimestamp, -1).length);
    }
}