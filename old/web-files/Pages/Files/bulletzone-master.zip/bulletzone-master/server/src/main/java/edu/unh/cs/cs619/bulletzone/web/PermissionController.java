package edu.unh.cs.cs619.bulletzone.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import edu.unh.cs.cs619.bulletzone.datalayer.BulletZoneData;
import edu.unh.cs.cs619.bulletzone.datalayer.GameUser;
import edu.unh.cs.cs619.bulletzone.datalayer.Permission;
import edu.unh.cs.cs619.bulletzone.repository.PermissionRepository;
import edu.unh.cs.cs619.bulletzone.util.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.util.PermissionWrapper;

@RestController
@RequestMapping(value = "/permission")
public class PermissionController {
    private static final Logger log = LoggerFactory.getLogger(GamesController.class);
    private BulletZoneData bulletZoneData;
    private PermissionRepository permissionRepository;

    @Autowired
    public PermissionController(PermissionRepository permissionRepository) {
        this.permissionRepository = permissionRepository;
        bulletZoneData = BulletZoneData.getInstance();
    }

    @RequestMapping(method = RequestMethod.GET, value = "{itemID}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<PermissionWrapper> getItemPermissions(@PathVariable int itemID) {
        HashMap<Integer, HashSet<Permission>> perm = permissionRepository
                .getPermissionOnItemID(itemID);
        Map<String, Set<String>> resultSet = new HashMap<>();
        for (Map.Entry<Integer, HashSet<Permission>> entry : perm.entrySet()) {
            GameUser user = bulletZoneData.users.getUser(entry.getKey());
            if (user == null) continue;

            Set<String> permissionNames = new HashSet<>();
            for (Permission permission : entry.getValue()) {
                permissionNames.add(permission.toString());
            }
            resultSet.put(user.getUsername(), permissionNames);
        }

        return new ResponseEntity<>(new PermissionWrapper(resultSet), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{srcUserID}/{itemID}/{username}/{perm}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> putItemPermission(@PathVariable int srcUserID,
                                                            @PathVariable int itemID,
                                                            @PathVariable String username,
                                                            @PathVariable String perm) {
        boolean added = permissionRepository.addPermissionToItem(itemID, srcUserID, username,
                Permission.fromString(perm));
        return new ResponseEntity<>(new BooleanWrapper(added), HttpStatus.ACCEPTED);
    }


    @RequestMapping(method = RequestMethod.DELETE, value = "{srcUserID}/{itemID}/{username}/{perm}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> deleteItemPermission(@PathVariable int srcUserID,
                                                               @PathVariable int itemID,
                                                               @PathVariable String username,
                                                               @PathVariable String perm) {
        boolean deleted = permissionRepository.removePermissionFromItem(itemID, srcUserID,
                username, Permission.fromString(perm));
        return new ResponseEntity<>(new BooleanWrapper(deleted), HttpStatus.ACCEPTED);
    }

    @RequestMapping(method = RequestMethod.PUT, value = "{srcUserID}/{itemID}/{username}",
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.ACCEPTED)
    @ResponseBody
    public ResponseEntity<BooleanWrapper> transferOwnership(@PathVariable int srcUserID,
                                                               @PathVariable int itemID,
                                                               @PathVariable String username) {
        boolean b = permissionRepository.transferOwnership(itemID, srcUserID, username);
        return new ResponseEntity<>(new BooleanWrapper(b), HttpStatus.ACCEPTED);
    }
}
