package edu.unh.cs.cs619.bulletzone.history;

/**
 * Represents a change in the grid.
 */
public class GridEvent {
    private long timestamp;
    private int position;
    private int entity;
    private int terrain;

    /**
     * Class to represent changes made by actions on the board.
     * @param position Position in the grid to change.
     * @param entity Value of the entity in the grid event.
     * @param terrain Value of the terrain in the grid event.
     */
    public GridEvent(int position, int entity, int terrain, long timestamp) {
        this.timestamp = timestamp;
        this.position = position;
        this.entity = entity;
        this.terrain = terrain;
    }

    /**
     * Get the vehicle value of the cell.
     * Should be representable by the client without extra processing.
     * Usually derived from an entity's getIntValue method.
     * @return Value of the cell that can be represented and converted by the client.
     */
    public int getEntity() {
        return entity;
    }

    /**
     * Same as get entity, but returns terrain.
     * @return Terrain value representable by client.
     */
    public int getTerrain() {
        return terrain;
    }

    /**
     * Get the position of the cell that is being changed.
     * @return Index of a cell in the grid.
     */
    public int getPosition() {
        return position;
    }

    /**
     * Get when the event occurred in milliseconds.
     * @return Milliseconds representing the timestamp held by the event class.
     */
    public long getTimestamp() {
        return timestamp;
    }
}
