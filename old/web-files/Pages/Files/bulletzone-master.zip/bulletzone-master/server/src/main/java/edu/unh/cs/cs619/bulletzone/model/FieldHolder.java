package edu.unh.cs.cs619.bulletzone.model;

import java.util.Optional;

import java.util.HashMap;
import java.util.Map;

import edu.unh.cs.cs619.bulletzone.repository.HistoryRepository;

import static com.google.common.base.Preconditions.checkNotNull;

public class FieldHolder {

    private final Map<Direction, FieldHolder> neighbors = new HashMap<Direction, FieldHolder>();
    private final int position;
    private int terrainID;
    private Optional<FieldEntity> entityHolder = Optional.empty();
    private Terrain terrain;

    public FieldHolder(int position) {
        this.position = position;
        this.terrainID = -1;
    }

    public void addNeighbor(Direction direction, FieldHolder fieldHolder) {
        neighbors.put(checkNotNull(direction), checkNotNull(fieldHolder));
    }

    public FieldHolder getNeighbor(Direction direction) {
        return neighbors.get(checkNotNull(direction,
                "Direction cannot be null."));
    }

    public boolean isPresent() {
        return entityHolder.isPresent();
    }

    public FieldEntity getEntity() {
        return entityHolder.get();
    }

    public void setFieldEntity(FieldEntity entity) {
        entityHolder = Optional.of(checkNotNull(entity,
                "FieldEntity cannot be null."));
        updateHistory();
    }

    public void clearField() {
        if (entityHolder.isPresent()) {
            entityHolder = Optional.empty();
            updateHistory();
        }
    }

    /**
     * Updates the current position history with current entity's int value.
     * Derived from entity's getIntValue()
     * Will update to 0 if there is no entity
     *
     * Should be called by any class that this field holder contains.
     * Call this method after calculations that may result in a change of the entity's value
     * such as turning or taking damage.
     */
    public void updateHistory() {
        HistoryRepository history = HistoryRepository.getInstance();
        // Check if a unit is hiding in the terrain
        boolean terrainHideable = (terrainID == 902 || terrainID == 1001 || terrainID == 2);
        FieldEntity entity = entityHolder.orElse(null);
        if (terrainHideable && entity instanceof Vehicle) {
            // Something is hiding in a building, fortification, or forest
            Vehicle vehicle = (Vehicle) entity;
            history.addEvent(position, terrainID, (int) vehicle.getId(), vehicle.getIntValue());
        } else if (entity != null) {
            // Nothing hiding, but there is something
            history.addEvent(position, terrainID, entity.getIntValue());
        } else {
            // Nothing hiding, nothing present
            history.addEvent(position, terrainID, 0);
        }
    }

    public int getPosition() {
        return position;
    }

    public int getTerrainID() {
        return terrainID;
    }

    public void setTerrainID(int terrainID) {
        this.terrainID = terrainID;
    }


    public Terrain getTerrain() {
        return terrain;
    }

    public void setTerrain(Terrain terrain) {
        this.terrain = terrain;
    }
}
