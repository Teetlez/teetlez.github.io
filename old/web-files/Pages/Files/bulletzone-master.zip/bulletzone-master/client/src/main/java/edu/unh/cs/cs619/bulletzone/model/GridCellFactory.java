package edu.unh.cs.cs619.bulletzone.model;

import java.util.HashMap;

/**
 * This class is used to generate the correct cell given the value
 */
public class GridCellFactory {
    public HashMap<Integer, Vehicle> vehicleHashMap = new HashMap<>();
    private static GridCellFactory currentInstance = new GridCellFactory();

    /**
     * Singleton
     *
     * @return GridCellFactory
     */
    public static GridCellFactory getInstance() {
        return currentInstance;
    }

    /**
     * Makes the proper cell with a given 1D value
     *
     * @param val value of ID
     * @return int
     */
    public GridCell makeCell(int loc, int val) {

        // Empty
        if (val == 0) {
            return new GridCell(0);
        }

        // Terrain
        if (val == -1 || val == 1001 || (val >= 2 && val <= 902)) {
            return new Terrain(val);
        }

        // Wall
        if (val == 1000 || (val > 1000 && val <= 2000))
        {
            return new Wall(val);
        }

        // Bullet
        if (val >= 2000000 && val <= 3000000) {
            return new Bullet(val);
        }

        // Vehicles: Tank, Ship, Truck, and Soldier
        if (val >= 10000000 && val < 50000000) {
            int vehicleId = getVehicleId(val);
            Vehicle vehicle;

            // check if vehicle id is not 0 (0 means it is a neutral/empty vehicle)
            if (vehicleId != 0) {
                // Check if the vehicle hashmap contains the vehicle id
                vehicle = vehicleHashMap.get(vehicleId);

                // Also check if the vehicle in the hashmap changed type (leading number will be different, e.g. 1 --> 4)
                if (vehicle != null && vehicle.id / 10000000 != val / 10000000) {
                    // remove the old saved vehicle in hashmap
                    vehicleHashMap.remove(vehicleId);

                    // call a new vehicle which should be a soldier and put it in the hashmap
                    vehicle = new Vehicle(val);
                    vehicleHashMap.put(vehicleId, vehicle);
                }

                // at this point, the vehicle has to be null so it creates a new vehicle
                if (vehicle == null) {
                    vehicle = new Vehicle(val);
                    vehicleHashMap.put(vehicleId, vehicle);
                }
            }
            else { // else, vehicle id is 0 so we set a new vehicle but this time a neutral vehicle
                vehicle = new Vehicle(val);
            }

            vehicle.setDirection(getDirection(val));
            vehicle.setHP(getLife(val));

            return vehicle;
        }

        return new GridCell(val);
    }

    /**
     * Overloaded makeCell. Takes 2D coordinates as location
     *
     * @param x x coordinate
     * @param y y coordinate
     * @param value value
     * @return GridCell
     */
    public GridCell makeCell(int x, int y, int value) {
        return makeCell(x + y * 16, value);
    }

    /**
     * Get vehicle id from its given value.
     * @param val Value.
     * @return Integer representing the vehicle id.
     */
    private int getVehicleId(int val) {
        return (val / 10000) % 1000;
    }

    /**
     * Grabs the direction value
     *
     * @param val value of direction
     * @return int
     */
    private int getDirection(int val) {
        return val % 10;
    }

    /**
     * Grabs the life value
     *
     * @param val value of life
     * @return int
     */
    private int getLife(int val) {
        return (val / 10) % 1000;
    }

    /**
     * Used for testing
     */
    public static void reset() {
        currentInstance = new GridCellFactory();
    }
}
