package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Child of GridCell. Class is used to initialize the correct terrain
 */
public class Terrain extends GridCell {

    /**
     * An enum to list a bunch of terrain types
     *
     */
    public enum TerrainType {
        DEBRIS,
        COAST,
        WATER,
        ROAD,
        LAND,
        FOREST,
        BUILDING,
        FORTIFICATION
    }

    public TerrainType terrainType;

    /**
     * Constructor
     *
     * @param val value
     */
    public Terrain(int val) {
        super(val);

        if (val == -1) {
            setResourceID(R.drawable.ground);
            setTerrainType(TerrainType.LAND);
        }
        else if (val == 2) {
            setResourceID(R.drawable.tree);
            setTerrainType(TerrainType.FOREST);
        }
        else if (val == 10) {
            setResourceID(R.drawable.rock);
            setTerrainType(TerrainType.DEBRIS);
        }
        else if (val == 40) {
            setResourceID(R.drawable.sand);
            setTerrainType(TerrainType.COAST);
        }
        else if (val == 50) {
            setResourceID(R.drawable.water);
            setTerrainType(TerrainType.WATER);
        }
        else if (val == 900) {
            setResourceID(R.drawable.road);
            setTerrainType(TerrainType.ROAD);
        }
        else if (val == 902) {
            setResourceID(R.drawable.building);
            setTerrainType(TerrainType.BUILDING);
        }
        else if (val == 1001) {
            setResourceID(R.drawable.barricade);
            setTerrainType(TerrainType.FORTIFICATION);
        }
    }

    /**
     * Grabs the terrain type
     *
     * @return terrain type
     */
    public TerrainType getTerrainType() {
        return terrainType;
    }

    /**
     * Sets the terrain type
     *
     * @param terrainType terrain type
     */
    public void setTerrainType(TerrainType terrainType) {
        this.terrainType = terrainType;
    }
}
