package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.event.GridEvent;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;

/**
 * This class is used to generate the grid
 */
public class SimulationGrid {
    private int rowCount;
    private int colCount;
    private int userId;
    private int lastKnown;
    private TankStatus status;

    private GridCell[][] fieldEntities;
    private GridCell[][] fieldTerrain;
    private int[][] mEntities = new int[16][16];
    private int[][] mTerrain = new int[16][16];

    private GridCellFactory cellFactory = GridCellFactory.getInstance();
    private static SimulationGrid currentInstance = new SimulationGrid();

    /**
     * Singleton
     *
     * @return SimulationGrid
     */
    public static SimulationGrid getInstance() {
        return currentInstance;
    }


    /**
     * Private constructor
     */
    private SimulationGrid() {
        this.rowCount = 16;
        this.colCount = 16;
        lastKnown = 0;
        status = new TankStatus(this, userId);
        this.fieldEntities = new GridCell[colCount][rowCount];
        this.fieldTerrain = new GridCell[colCount][rowCount];
        initializeField();
    }

    /**
     * Initializes the SimulationGrid
     */
    private void initializeField() {
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                mEntities[i][j] = 0;
                mTerrain[i][j] = 0;
                fieldEntities[i][j] = cellFactory.makeCell(i, j, 0);
                fieldTerrain[i][j] = cellFactory.makeCell(i, j, 0);
            }
        }
    }

    /**
     * Populate the internal simulation grid every time an event occurs
     *
     * @param gridWrapper Wrapper containing grid for entities and terrain.
     */
    public void populateSimGrid(GridWrapper gridWrapper) {
        mEntities = gridWrapper.getGrid();
        mTerrain = gridWrapper.getTerrainGrid();

        for (int i = 0; i < colCount; i++) {
            for (int j = 0; j < rowCount; j++) {
                fieldEntities[i][j] = cellFactory.makeCell(i, j, mEntities[i][j]);
                fieldTerrain[i][j] = cellFactory.makeCell(i, j, mTerrain[i][j]);
                if (fieldEntities[i][j] instanceof Vehicle && isPlayer(fieldEntities[i][j].id)) {
                    lastKnown = (i * rowCount) + j;
                }
            }
        }
    }

    /**
     * Update existing sim grid with new events.
     * @param gridEvents Grid events.
     */
    public void updateSimGrid(GridEvent[] gridEvents) {
        // Sorted by timestamp in ascending order, don't worry about sorting it beforehand
        for (GridEvent gridEvent : gridEvents) {
            // Calculate position from the 0-255 value
            int x = gridEvent.getPosition() % 16;
            int y = gridEvent.getPosition() / 16;

            // Update field entities and mEntities
            GridCell entity = cellFactory.makeCell(x, y, gridEvent.getEntity());
            GridCell terrain = cellFactory.makeCell(x, y, gridEvent.getTerrain());
            fieldEntities[y][x] = entity;
            fieldTerrain[y][x] = terrain;
            mEntities[y][x] = gridEvent.getEntity();
            mTerrain[y][x] = gridEvent.getTerrain();

            // Update last known vehicle health
            if (entity instanceof Vehicle && isPlayer(entity.id)) lastKnown = gridEvent.getPosition();
        }
    }

    /**
     * Grabs row count
     *
     * @return int
     */
    public int getRowCount() {
        return rowCount;
    }

    /**
     * Grabs column count
     *
     * @return int
     */
    public int getColCount() {
        return colCount;
    }

    /**
     * Returns the grid size
     *
     * @return int
     */
    public int size() {
        return rowCount * colCount;
    }

    /**
     * Grabs the ClientFieldEntity at the specified (x, y) location
     *
     * @param x location in the grid
     * @param y location in the grid
     * @return GridCell
     */
    public GridCell getEntity(int x, int y) {
        if (x < 0 || x > 15 || y < 0 || y > 15) {
            return null;
        }

        return fieldEntities[x][y];
    }

    /**
     * Overloaded of getEntity. Takes a single location parameter representative of the
     * ClientFieldEntity's location in a 1D array
     *
     * @param location 1D location in the grid
     * @return GridCell
     */
    public GridCell getEntity(int location) {
        return fieldEntities[location / colCount][location % rowCount];
    }

    /**
     * Get terrain in the given position.
     * @param location Location of the cell.
     * @return GridCell representing the terrain object.
     */
    public GridCell getTerrain(int location) {
        return fieldTerrain[location / colCount][location % rowCount];
    }

    /**
     * Grab the user's ID
     *
     * @return int
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Set the user's ID
     *
     * @param userId int
     */
    public void setUserId(int userId) {
        this.userId = userId;
        status.setTankId(userId);
    }

    /**
     * Grabs the player's vehicle ID
     *
     * @return Vehicle
     */
    public Vehicle getPlayerVehicle() {
        return GridCellFactory.getInstance().vehicleHashMap.get(userId);
    }

    /**
     * Grabs the player's health points
     *
     * @return int
     */
    public int getPlayerHP(){
        Vehicle player = getPlayerVehicle();
        if (player != null) {
            return (int) ((status.getLife() / (double) player.getMaxHP()) * 100);
        } else {
            return 0;
        }
    }

    /**
     * Used for testing
     */
    public static void reset() {
        currentInstance = new SimulationGrid();
    }

    /**
     * Checks the location where the player tank is
     *
     * @param row row
     * @param col column
     * @return Boolean
     */
    public boolean isPlayer(int row, int col) {
        // Returns if the given location is where the player tank is located
        return isPlayer(mEntities[row % 16][col % 16]);
    }

    /**
     * Checks if it is a player
     *
     * @param value value
     * @return Boolean
     */
    public boolean isPlayer(int value){
        return (value / 10000) % 1000 == userId;
    }

    /**
     * Updates the last known location of the player tank (used for testing)
     */
    public void updateLastKnown(){
        for(int i = 0; i < rowCount; i++){
            for(int j = 0; j < colCount; j++){
                if(isPlayer(i, j)){
                    lastKnown = (i * 16) + j;
                }
            }
        }
    }

    /**
     * Grabs the last known location
     *
     * @return int
     */
    protected int getLastKnown(){return lastKnown;}

}
