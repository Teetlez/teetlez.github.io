package edu.unh.cs.cs619.bulletzone.event;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.util.Log;

/**
 * Implementation from https://jasonmcreynolds.com/
 * The gForce that is necessary to register as shake
 * must be greater than 1G (one earth gravity unit).
 */
public class ShakeListener implements SensorEventListener {
    private double x;
    private double y;
    private double z;

    private double last_x;
    private double last_y;
    private double last_z;

    private static final float SHAKE_THRESHOLD_GRAVITY = 1;
    private static final int SHAKE_SLOP_TIME_MS = 800;

    private OnShakeListener mListener;
    private long mShakeTimestamp;

    public ShakeListener() {
    }

    public void setOnShakeListener(OnShakeListener listener) {
        this.mListener = listener;
    }

    public interface OnShakeListener {
        void onShake();
    }

    // ignore
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    /** Detects if the device's acceleration is greater than 1G, and calls onShake() if detected
     * @param event the event sent by the system on sensor changes (i.e. changes in acceleration)
     */
    @Override
    public void onSensorChanged(SensorEvent event) {

        if (mListener != null) {

//            if (gForce > SHAKE_THRESHOLD_GRAVITY) {
                final long now = System.currentTimeMillis();
                // ignore shake events too close to each other
                if (mShakeTimestamp + SHAKE_SLOP_TIME_MS < now) {
                    double diff = now - mShakeTimestamp;
                    mShakeTimestamp = now;
                    x = event.values[0];
                    y = event.values[1];
                    z = event.values[2];

                    double gForce = Math.abs(x+y+z - last_x - last_y - last_z) / diff * 10000;

                    if (gForce > SHAKE_THRESHOLD_GRAVITY) {
                        mListener.onShake();
                        Log.d("G FORCE", Double.toString(gForce));
                    }

                    last_x = x;
                    last_y = y;
                    last_z = z;
                }
//            }

        }
    }
}