package edu.unh.cs.cs619.bulletzone.wrapper;

import java.util.Map;
import java.util.Set;

public class PermissionWrapper {
    private Map<String, Set<String>> permission;

    public Map<String, Set<String>> getPermission() {
        return permission;
    }

    public void setPermission(Map<String, Set<String>> permission) {
        this.permission = permission;
    }
}
