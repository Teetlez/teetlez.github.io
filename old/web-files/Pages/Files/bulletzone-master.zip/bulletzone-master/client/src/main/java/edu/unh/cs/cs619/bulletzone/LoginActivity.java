package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;

@EActivity(R.layout.login)
public class LoginActivity extends Activity {

    @RestService
    BulletZoneRestClient restClient;

    public String serverUrl = "BLANK";
    private long valid = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Check for previous instance
        if (savedInstanceState != null) {
        } else {
        }

    }

    @AfterViews
    protected void afterViewInjection() {
        TextView registerView = (TextView)findViewById(R.id.registerTextView);
        TextView loginView = (TextView)findViewById(R.id.loginTextView);

        registerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent userRegister = new Intent(LoginActivity.this, RegisterActivity_.class);
                startActivity(userRegister);
            }
        });

        //This is responsible for getting the username and password
        loginView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText username = (EditText) findViewById(R.id.editTextUsername);
                EditText password = (EditText) findViewById(R.id.editTextPassword);

                String user =  username.getText().toString();
                String pass =  password.getText().toString();

                //This means that a slot was left empty
                if (user.equals("")) {
                   toastMsg("Please enter a username");
                } else if (pass.equals("")) {
                   toastMsg("Please enter a password");
                } else {
                    attemptLogin(user, pass);
                }

            }
        });
    }

    /**
     * method to login using an existing username and password
     *
     * @param username string
     * @param password string
     */
    @Background
    void attemptLogin(String username, String password) {

        //Valid is the player id.
        valid = restClient.login(username, password).getResult();

        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                if (valid > -1) {
                    SharedPreferences.Editor edit = getSharedPreferences("currentlySelected", MODE_PRIVATE).edit();
                    edit.putString("userName", username);
                    edit.apply();
                    toastMsg("Login successful");
                    Intent start = new Intent(LoginActivity.this, MainMenuActivity_.class);
                    start.putExtra("playerId", valid);
                    startActivity(start);
                } else {
                    toastMsg("Incorrect username or password");
                    Log.d("Returned PlayerId", Integer.toString((int) valid));
                }
            }
        });

    }

    /**
     * Displays a toast message
     *
     * @param message string
     */
    private void toastMsg(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        toast.show();
    }


}
