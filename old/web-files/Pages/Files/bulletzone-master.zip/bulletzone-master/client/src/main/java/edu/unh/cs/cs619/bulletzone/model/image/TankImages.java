package edu.unh.cs.cs619.bulletzone.model.image;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Represents state for vehicle type.
 */
public class TankImages implements VehicleImages {
    @Override
    public Integer up() {
        return R.drawable.tank_forward;
    }

    @Override
    public Integer down() {
        return R.drawable.tank_downward;
    }

    @Override
    public Integer left() {
        return R.drawable.tank_left;
    }

    @Override
    public Integer right() {
        return R.drawable.tank_right;
    }

    @Override
    public Integer enemyUp() {
        return R.drawable.enemy_tank_forward;
    }

    @Override
    public Integer enemyDown() {
        return R.drawable.enemy_tank_downward;
    }

    @Override
    public Integer enemyLeft() {
        return R.drawable.enemy_tank_left;
    }

    @Override
    public Integer enemyRight() {
        return R.drawable.enemy_tank_right;
    }

    @Override
    public Integer NeutralUp() {
        return R.drawable.neutral_tank_forward;
    }

    @Override
    public Integer NeutralDown() {
        return R.drawable.neutral_tank_downward;
    }

    @Override
    public Integer NeutralLeft() {
        return R.drawable.neutral_tank_left;
    }

    @Override
    public Integer NeutralRight() {
        return R.drawable.neutral_tank_right;
    }
}
