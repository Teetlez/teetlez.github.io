package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * A child class of GridCell. This class represents a Bullet object
 *
 */
public class Bullet extends GridCell {

    private int damage;

    /**
     * Constructor
     *
     * @param val value of Vehicle
     */
    public Bullet(int val) {
        super(val);

        resource_ID = R.drawable.bullet;
        id = (val % 1000000) / 1000;
        damage = (val % 1000) / 10;
        cell_type = "Bullet";
    }

    /**
     * Grabs the damage of the bullet
     *
     * @return int
     */
    public int getDamage() {
        return damage;
    }

}
