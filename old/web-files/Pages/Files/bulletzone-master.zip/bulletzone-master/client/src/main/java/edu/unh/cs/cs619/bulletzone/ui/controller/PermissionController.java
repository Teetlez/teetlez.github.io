package edu.unh.cs.cs619.bulletzone.ui.controller;

import android.os.SystemClock;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EBean;
import org.androidannotations.rest.spring.annotations.RestService;

import java.util.Set;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.wrapper.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.PermissionWrapper;

@EBean
public class PermissionController {
    @RestService
    BulletZoneRestClient restClient;

    PermissionWrapper permissions;

    BooleanWrapper result;

    boolean done;

    public PermissionController() {}

    /**
     * This is only used for testing to make the mock rest client the client that is used.
     * @param test Mock rest client.
     */
    public void permissionControllerTestSet(BulletZoneRestClient test) {
        this.restClient = test;
    }

    /**
     * Checks if a permission or alternatively owner works with a user
     * @param user Name of the user so that the key can be searched
     * @param vehicleId ID of the vehicle that's being checked
     * @param perm Permission that's being checked
     * @return True if the user is an owner or if the permission is assigned to them
     */
    public boolean checkPermission(String user, int vehicleId, String perm) {
        Set<String> set;
        try {
            set = getPermissions(vehicleId).getPermission().get(user);
        } catch (Exception e) {
            return false;
        }


        if (set == null) {
            return false;
        }

        //Check if the user is the owner
        if (set.contains("Owner")) {
            return true;
        }

        //Check if the user has the permission designated with them
        return set.contains(perm);

        //Return false because nothing else came up
    }

    /**
     * Transfers ownership
     * @param srcUserID ID of the user who is trying to make the transfer
     * @param itemID ID of the vehicle
     * @param username username of the person who will be getting permissions
     * @return true if able to transfer ownership
     */
    public boolean transferOwnership(int srcUserID, int itemID, String username) {
        done = false;
        asyncTransfer(srcUserID, itemID, username);
        while (!done) {
            SystemClock.sleep(100);
        }

        return result.isResult();
    }

    /**
     * sends the actual async request
     * @param srcUserID
     * @param itemID
     * @param username
     */
    @Background
    protected void asyncTransfer(int srcUserID, int itemID, String username) {
        result = restClient.transferOwnership(srcUserID, itemID, username);
        done = true;
    }

    /**
     * Gets permissions from the server and then returns it
     * @param itemID ID of the vehicle
     * @return returns the permission wrapper
     */
    public PermissionWrapper getPermissions(int itemID) {
        done = false;
        getItemPermissions(itemID);
        //Stall for return from server
        while (!done) {
            SystemClock.sleep(100);
        }
        return permissions;
    }

    /**
     * Sends a request to the server for permissions
     * @param itemID vehicle ID of the vehicle in question
     */
    @Background
    protected void getItemPermissions(int itemID) {
        try {
            permissions = restClient.getItemPermissions(itemID);
        } catch (Exception e) {
            permissions = null;
        }

        done = true;
    }

    /**
     * Attempts to put an item permission. Returns false if permission is not allowed
     * @param srcUserID id of user that is issuing the request
     * @param itemID id of the vehicle that the request is being put upon
     * @param username Username of the person that's getting added for the item
     * @param perm Type of permission
     * @return true if the permission addition was a success
     */
    public boolean putItemPermission(int srcUserID, int itemID, String username, String perm) {
        done = false;
        asyncPut(srcUserID, itemID, username, perm);
        while (!done) {
            SystemClock.sleep(100);
        }

        return result.isResult();
    }

    /**
     * Sends the async request to the server
     * @param srcUserID id of user that is issuing the request
     * @param itemID id of the vehicle that the request is being put upon
     * @param username Username of the person that's getting added for the item
     * @param perm Type of permission
     */
    @Background
    protected void asyncPut(int srcUserID, int itemID, String username, String perm) {
        result = restClient.putItemPermission(srcUserID, itemID, username, perm);
        done = true;
    }

    /**
     * Makes a request to the server trying to delete a permission.
     * @param srcUserID id of user that is issuing the request
     * @param itemID id of the vehicle that the request is being put upon
     * @param username Username of the person that's getting added for the item
     * @param perm Type of Permission
     * @return true if the permission addition was a success
     */
    public boolean deleteItemPermission(int srcUserID, int itemID, String username, String perm) {
        done = false;
        asyncDelete(srcUserID, itemID, username, perm);
        while (!done) {
            SystemClock.sleep(100);
        }

        return result.isResult();
    }

    /**
     * Sends the async request to the server
     * @param srcUserID
     * @param itemID
     * @param username
     * @param perm
     */
    @Background
    protected void asyncDelete(int srcUserID, int itemID, String username, String perm) {
        result = restClient.deleteItemPermission(srcUserID, itemID, username, perm);
        done = true;
    }
}
