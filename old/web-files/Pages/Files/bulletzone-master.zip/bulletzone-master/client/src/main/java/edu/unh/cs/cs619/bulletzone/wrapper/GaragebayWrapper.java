package edu.unh.cs.cs619.bulletzone.wrapper;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;

/**
 * Garage bay wrapper for client side. Only fetches needed things.
 */
public class GaragebayWrapper {
    private long timestamp;
    private GameItem[] items;

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public GameItem[] getItems() {
        return items;
    }

    public void setItems(GameItem[] items) {
        this.items = items;
    }
}
