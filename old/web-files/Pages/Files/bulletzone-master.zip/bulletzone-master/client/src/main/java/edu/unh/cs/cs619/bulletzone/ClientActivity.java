package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.ItemClick;
import org.androidannotations.annotations.NonConfigurationInstance;

import edu.unh.cs.cs619.bulletzone.facade.ClientFacade;

@EActivity(R.layout.activity_client)
public class ClientActivity extends Activity {

    private static final String TAG = "ClientActivity";

    @NonConfigurationInstance
    @Bean
    protected ClientFacade clientFacade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        clientFacade.onCreate(getSharedPreferences("currentlySelected", MODE_PRIVATE));
    }

    @Override
    public void onResume() {
        super.onResume();
        clientFacade.onResume();
    }

    @Override
    public void onPause() {
        clientFacade.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clientFacade.onDestroy();
    }

    /**
     * Handler that calls the gameController to process the given input.
     * It will send the correct request to the server such as moving, turning, and shooting.
     *
     * @param view The button that was pressed.
     */
    @Click({R.id.buttonUp, R.id.buttonDown, R.id.buttonLeft, R.id.buttonRight, R.id.buttonFire})
    protected void onButtonPress(View view) {
        clientFacade.buttonPress(view);
    }

    /**
     * Initiates bringing up stats when clicking on a vehicle in the grid.
     * @param index Index of the item that was clicked
     */
    @ItemClick(R.id.gridView)
    protected void onItemClick(int index) {
        clientFacade.vehicleStatsDialog(index);
    }

    /**
     * Button for leaving the game and returning back to main menu.
     */
    @Click(R.id.buttonLeave)
    @Background
    void leaveGame() {
        clientFacade.leave();
    }

    /**
     * Button for ejecting out of the vehicle.
     */
    @Click(R.id.buttonEject)
    @Background
    protected void ejectVehicle() {
        clientFacade.playerEject();
    }

    /**
     * Sending the actual leave request to the server
     * @param vehicleID ID of the player
     */
    @Background
    void leaveAsync(long vehicleID) {
        clientFacade.leave();
    }
}
