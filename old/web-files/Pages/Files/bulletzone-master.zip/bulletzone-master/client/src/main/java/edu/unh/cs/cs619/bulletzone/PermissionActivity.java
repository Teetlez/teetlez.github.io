package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EActivity;

import java.util.Map;
import java.util.Set;

import edu.unh.cs.cs619.bulletzone.ui.controller.PermissionController;
import edu.unh.cs.cs619.bulletzone.wrapper.PermissionWrapper;

@EActivity(R.layout.permission_activity)
public class PermissionActivity extends Activity {
    Context mContext;
    int vehicleId;
    int playerId;
    String userToBeEdited;

    Button owner;
    Switch add;
    Switch remove;
    Switch use;
    Switch permissions;

    @Bean
    PermissionController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Set the context for onitemclicklisteners
        mContext = this;
    }

    /**
     * Resets all the switches so that the permissions that only true permissions are set
     */
    private void resetAllSwitches() {
        add.setChecked(false);
        remove.setChecked(false);
        use.setChecked(false);
        permissions.setChecked(false);
    }

    /**
     * Updates the user that the permissions are going to be edited
     * @param user User that is going to be edited
     */
    protected void updateUser(String user) {
        userToBeEdited = user;

        PermissionWrapper permissionWrapper = controller.getPermissions(vehicleId);
        Map<String, Set<String>> permission = permissionWrapper.getPermission();
        Set<String> listOfPermissions = permission.get(userToBeEdited);

        resetAllSwitches();

        //This means that the user has not been added for any permissions yet
        if (listOfPermissions == null) {
            return;
        }

        if (listOfPermissions.contains("Add")) {
            add.setChecked(true);
        }
        if (listOfPermissions.contains("Remove")) {
            remove.setChecked(true);
        }
        if (listOfPermissions.contains("Use")) {
            use.setChecked(true);
        }
        if(listOfPermissions.contains("Transfer")) {
            permissions.setChecked(true);
        }

    }

    /**
     * Checks if the user is null, if true prevents any switches from activating
     */
    private boolean checkIfUserNull() {
        if (userToBeEdited == null) {
            Toast.makeText(mContext, "Please Select a User", Toast.LENGTH_SHORT).show();
            return true;
        }

        return false;
    }

    /**
     * Sends a request to the server using the controller. Returns true if the request was
     * successful
     * @param b True if put request, false if delete request
     * @param request name of the permission that's going to be changed
     * @return True if it was successful, false if permissions aren't allowed.
     */
    private boolean sendRequest(boolean b, String request) {
        if (b) {
            return controller.putItemPermission(playerId, vehicleId, userToBeEdited, request);
        } else {
            return controller.deleteItemPermission(playerId, vehicleId, userToBeEdited, request);
        }

    }

    @AfterViews
    protected void afterView() {
        Intent retrieve = getIntent();
        vehicleId = retrieve.getIntExtra("vehicleId", -1);
        playerId = retrieve.getIntExtra("playerId", -1);


        if (vehicleId == -1) {
            Log.d("ERROR", "Was unable to retrieve vehicle being worked on");
            finish();
        }
        if (playerId == -1) {
            Log.d("ERROR", "Was unable to retrieve playerId");
            finish();
        }

        EditText userInBox = findViewById(R.id.userPermissionBox);
        Button setUser = findViewById(R.id.updateUser);


        setUser.setOnClickListener(view -> updateUser(userInBox.getText().toString()));

        owner = findViewById(R.id.owner);
        add = findViewById(R.id.switchAdd);
        remove = findViewById(R.id.switchRemove);
        use = findViewById(R.id.switchUse);
        permissions = findViewById(R.id.switchPermissions);

        owner.setOnClickListener(view -> {

            if (checkIfUserNull()) {
                return;
            }

            if (!controller.transferOwnership(playerId, vehicleId, userToBeEdited)) {
                Toast.makeText(mContext, "You do not have permission to change access levels", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(mContext, "Successfully Changed Permission", Toast.LENGTH_SHORT).show();
        });

        add.setOnClickListener(view -> {
            boolean isChecked = add.isChecked();

            if (checkIfUserNull()) {
                add.setChecked(!isChecked);
                return;
            }

            if (!sendRequest(isChecked, "Add")) {
                add.setChecked(!isChecked);
                Toast.makeText(mContext, "You do not have permission to change access levels", Toast.LENGTH_SHORT).show();
                return;
            }


            Toast.makeText(mContext, "Successfully Changed Permission", Toast.LENGTH_SHORT).show();
        });

        remove.setOnClickListener(view -> {
            boolean isChecked = remove.isChecked();

            if (checkIfUserNull()) {
                remove.setChecked(!isChecked);
                return;
            }

            if (!sendRequest(isChecked, "Remove")) {
                remove.setChecked(!isChecked);
                Toast.makeText(mContext, "You do not have permission to change access levels", Toast.LENGTH_SHORT).show();
                return;
            }


            Toast.makeText(mContext, "Successfully Changed Permission", Toast.LENGTH_SHORT).show();
        });

        use.setOnClickListener(view -> {
            boolean isChecked = use.isChecked();

            if (checkIfUserNull()) {
                use.setChecked(!isChecked);
                return;
            }

            if (!sendRequest(isChecked, "Use")) {
                use.setChecked(!isChecked);
                Toast.makeText(mContext, "You do not have permission to change access levels", Toast.LENGTH_SHORT).show();
                return;
            }


            Toast.makeText(mContext, "Successfully Changed Permission", Toast.LENGTH_SHORT).show();
        });

        permissions.setOnClickListener(view -> {
            boolean isChecked = permissions.isChecked();

            if (checkIfUserNull()) {
                permissions.setChecked(!isChecked);
                return;
            }

            if (!sendRequest(isChecked, "Transfer")) {
                permissions.setChecked(!isChecked);
                Toast.makeText(mContext, "You do not have permission to change access levels", Toast.LENGTH_SHORT).show();
                return;
            }


            Toast.makeText(mContext, "Successfully Changed Permission", Toast.LENGTH_SHORT).show();
        });

    }
}
