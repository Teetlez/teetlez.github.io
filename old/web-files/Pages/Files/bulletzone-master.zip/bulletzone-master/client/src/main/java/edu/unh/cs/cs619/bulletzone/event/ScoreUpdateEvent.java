package edu.unh.cs.cs619.bulletzone.event;

import edu.unh.cs.cs619.bulletzone.wrapper.LongWrapper;

public class ScoreUpdateEvent {
    LongWrapper playerScore;
    public ScoreUpdateEvent(LongWrapper score) {
        playerScore = score;
    }

    public long getScore(){return playerScore.getResult();}
}
