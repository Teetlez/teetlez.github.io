package edu.unh.cs.cs619.bulletzone.vehicleCustomize;

import android.app.Activity;
import android.util.Log;

public class StatRead extends Activity {
    String[] statNames;
    double[] numbers;
    int weapons;

    /**
     * In the constructor set all of the stat names for both referencing and display
     * purposes.
     */
    public StatRead(){
        statNames = new String[15];
        numbers = new double[15];

        statNames[0] = "Size";
        statNames[1] = "Weight";
        statNames[2] = "Price";
        statNames[3] = "Capacity";
        statNames[4] = "Armor";
        statNames[5] = "Damage";
        statNames[6] = "Instance Limit";
        statNames[7] = "Electric Power";
        statNames[8] = "Electric Power Used";
        statNames[9] = "Drive Power";
        statNames[10] = "Drive Power Used";
        statNames[11] = "Movement-to-weight ratio";
        statNames[12] = "Weight modifier";
        statNames[13] = "Armor modifier";
        statNames[14] = "Terrain-obstacle sensitivity";

        weapons = 0;

        for (int i = 0; i < 15; i++) {
            numbers[i] = 0;
        }

    }

    /**
     * This method is called after all calculations have been completed
     * to determine what the instance limit is.
     */
    public void finalCalculation() {
        if (weapons != 0) {
            numbers[6] = numbers[6]/weapons;
        }
        weapons = 0;
    }

    /**
     * Iterates through all items and then iterates
     * through the items stat categories adding things.
     * If it's a weapon then increase weapon counter by 1
     * and then at the very end dividing is done by setVehicle
     */
    public void calculateStats(String[] itemStats) {
        for (String itemStat : itemStats) {
            //Split the string at the colon.
            String[] split = itemStat.split(":", 2);
            String stat = split[0]; //Stat that is to be changed
            double number = Double.parseDouble(split[1]); //Number that is being added

            switch (stat) {
                case "Size":
                    numbers[0] += number;
                    break;
                case "Weight":
                    numbers[1] += number;
                    break;
                case "Price":
                    numbers[2] += number;
                    break;
                case "Capacity":
                    numbers[3] += number;
                    break;
                case "Armor":
                    numbers[4] += number;
                    break;
                case "Damage":
                    numbers[5] += number;
                    break;
                case "Instance Limit":
                    numbers[6] += number;
                    weapons++;
                    break;
                case "Electric Power":
                    numbers[7] += number;
                    break;
                case "Electric Power Used":
                    numbers[8] += number;
                    break;
                case "Drive Power":
                    numbers[9] += number;
                    break;
                case "Drive Power Used":
                    numbers[10] += number;
                    break;
                case "Movement-to-weight ratio":
                    numbers[11] += number;
                    break;
                case "Weight modifier":
                    numbers[12] += number;
                    break;
                case "Armor modifier":
                    numbers[13] += number;
                    break;
                case "Terrain-obstacle sensitivity":
                    numbers[14] += number;
                    break;
                default:
                    Log.d("ERROR", "Missed Every case. Ending program by dividing by 0.");
                    int quit = 0 / 0;
            }

        }
    }

    /**
     * Returns a string array that will be handed into a string grid adapter.
     * @return String array with all stats and their values.
     */
    public String[] stringArrayGrab() {
        String[] result = new String[15];

        for (int i = 0; i < 15; i++) {
            result[i] = statNames[i] + ": " + numbers[i];
        }

        //Flush the results since we only care about recalculating fresh every time.
        for (int i = 0; i < 15; i++) {
            numbers[i] = 0;
        }

        return result;
    }
}
