package edu.unh.cs.cs619.bulletzone.event;

import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;

/**
 * Created by simon on 10/3/14.
 */
public class GridUpdateEvent {
    public GridWrapper gw;

    public GridUpdateEvent(GridWrapper gw) {
        this.gw = gw;
    }
}
