package edu.unh.cs.cs619.bulletzone.facade;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.otto.Subscribe;

import org.androidannotations.annotations.AfterInject;
import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.UiThread;
import org.androidannotations.annotations.ViewById;
import org.androidannotations.rest.spring.annotations.RestService;

import java.util.Locale;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.GridHistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.GridUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.ScoreUpdateEvent;
import edu.unh.cs.cs619.bulletzone.history.HistoryRecorder;
import edu.unh.cs.cs619.bulletzone.model.GridCell;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.rest.BZRestErrorhandler;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.rest.GridPollerTask;
import edu.unh.cs.cs619.bulletzone.ui.adapter.GridAdapter;
import edu.unh.cs.cs619.bulletzone.ui.adapter.HPViewAdapter;
import edu.unh.cs.cs619.bulletzone.ui.controller.GameController;
import edu.unh.cs.cs619.bulletzone.ui.controller.ShakeController;
import edu.unh.cs.cs619.bulletzone.wrapper.StringArrayWrapper;

/**
 * Displays game grid from ClientActivity.
 */
@EBean
public class ClientFacade {
    private static final String TAG = "ClientFacade";

    @Bean
    protected GridAdapter mGridAdapter;

    @ViewById(R.id.gridView)
    protected GridView gridView;

    @RestService
    protected BulletZoneRestClient restClient;

    //entered the customize activity at all i.e. fresh install it will default -1.
    @Bean
    protected BusProvider busProvider;

    @Bean
    GridPollerTask gridPollTask;

    @Bean
    HistoryRecorder recorder;

    @Bean
    BZRestErrorhandler bzRestErrorhandler;

    ShakeController shake;

    @Bean
    GameController gameController;

    @Bean
    HPViewAdapter hpAdapter;

    /**
     * Remote tank identifier
     */
    private long vehicleId = -1;
    private int vehicleIDFromCustomize; //This is imported from the customize activity. If you never
    private int battleSuitIDFromCustomize;
    private Context context;

    /**
     * Constructor
     *
     * @param mContext context of ClientActivity
     */
    public ClientFacade(Context mContext) {
        context = mContext;
    }

    /**
     * Otto has a limitation (as per design) that it will only find
     * methods on the immediate class type. As a result, if at runtime this instance
     * actually points to a subclass implementation, the methods registered in this class will
     * not be found. This immediately becomes a problem when using the AndroidAnnotations
     * framework as it always produces a subclass of annotated classes.
     * <p>
     * To get around the class hierarchy limitation, one can use a separate anonymous class to
     * handle the events.
     */

    @Subscribe
    @Background
    public void onUpdateGrid(GridUpdateEvent event) {
        mGridAdapter.updateList(event.gw);
        hpAdapter.updateHP();
    }

    @Subscribe
    @Background
    public void onUpdateHistory(GridHistoryUpdateEvent event) {
        mGridAdapter.updateList(event.gw.getGrid());
        hpAdapter.updateHP();
    }


    @Subscribe
    @Background
    public void onUpdateScore(ScoreUpdateEvent event) {
        setScoreText(String.format(Locale.US, "Score: %d", event.getScore()));
    }

    @AfterInject
    protected void afterInject() {
        restClient.setRestErrorHandler(bzRestErrorhandler);
        busProvider.getEventBus().register(this);
        Log.d(TAG, "injected ClientFacade");
    }

    @AfterViews
    protected void afterViewInjection() {
        joinAsync();
        SystemClock.sleep(500);
        gridView.setAdapter(mGridAdapter);
    }

    public void onCreate(SharedPreferences pref) {
        vehicleIDFromCustomize = pref.getInt("currentId", -1);
        battleSuitIDFromCustomize = pref.getInt("currentBattleSuitId ", -2);
        Log.d("vehicleIDFromCustomize", Integer.toString(vehicleIDFromCustomize));
        Log.d("battleSuitID", Integer.toString(battleSuitIDFromCustomize));
    }

    public void onDestroy() {
        gridPollTask.clearTimer();
        busProvider.getEventBus().unregister(this);
        recorder.save(context);
        shake.unregisterShake();
    }

    public void onPause() {
        // unregister the Sensor Event Listener onPause
    }

    public void onResume() {
        // register the Sensor Event Listener onResume
    }

    @Background
    public void joinAsync() {
        try {
            vehicleId = restClient.join(vehicleIDFromCustomize).getResult();
            Log.d("ID FROM CUSTOMIZE", Integer.toString(vehicleIDFromCustomize));
            SimulationGrid.getInstance().setUserId((int) vehicleId);
            shake = new ShakeController(context, gameController, mGridAdapter, vehicleId);
            gridPollTask.setPlayerId(vehicleId);
            gridPollTask.doPoll();
            shake.registerShake();
        } catch (Exception e) {
            Log.e("ERROR", e.getMessage());
        }
    }

    public void leave() {
        System.out.println("leaveGame() called, vehicle ID: " + vehicleId);
        restClient.leave(vehicleId);
//        BackgroundExecutor.cancelAll("grid_poller_task", true);
        ((Activity) context).finish();
    }

    public void buttonPress(View view) {
        Vehicle playerVehicle = SimulationGrid.getInstance().getPlayerVehicle();
        gameController.processInput(view.getId(), (byte) playerVehicle.getDirection(),
                SimulationGrid.getInstance().getUserId());
    }

    public void playerEject() {
        Vehicle playerVehicle = SimulationGrid.getInstance().getPlayerVehicle();

        gameController.eject(vehicleId, battleSuitIDFromCustomize);

        Log.d(TAG, "Soldier has ejected from " + playerVehicle.getCellType());
        Log.d(TAG, "Vehicle ID " + vehicleId);
        Log.d(TAG, "Soldier ID (Preset) " + battleSuitIDFromCustomize);
    }

    /**
     * Displays a dialog showing the stats of the selected unit
     *
     * @param pos The position of the grid cell that was clicked
     */
    @Background
    public void vehicleStatsDialog(int pos) {
        // get the selected GridCell and continue if is vehicle or soldier
        GridCell selected = SimulationGrid.getInstance().getEntity(pos);
        if (selected.id >= 10000000) {

            // Query the server for info about the unit
            StringArrayWrapper stats = restClient.getStats(pos);

            // Create dialog builder. Set the title and stat list
            AlertDialog.Builder dialog = new AlertDialog.Builder(context);
            dialog.setTitle(String.format(Locale.US,
                    "%s at (%d, %d)", selected.cell_type, pos % 16, pos / 16));
            dialog.setItems(stats.getGrid(), (dialog1, which) -> {
            });

            // Set the close button and message to display when closed
            dialog.setPositiveButton("close",
                    (dialog12, which) -> Toast.makeText(context, "info closed", Toast.LENGTH_SHORT).show());

            // Create and show dialog on UI
            ((Activity) context).runOnUiThread(() -> {
                Toast.makeText(context, String.format(Locale.US, "info for %d", selected.id), Toast.LENGTH_SHORT).show();
                AlertDialog alertDialog = dialog.create();
                alertDialog.show();
            });
        } else {
            // The selected Grid Cell wasn't a vehicle/soldier thus no info could be displayed
            ((Activity) context).runOnUiThread(() ->
                    Toast.makeText(context, "no info for selected cell", Toast.LENGTH_SHORT).show());
        }
    }

    /**
     * Sets the score text for the health bar
     *
     * @param string what the text should display
     */
    @UiThread
    public void setScoreText(String string) {
        ((TextView) ((Activity) context).findViewById(R.id.scoreText)).setText(string);
    }

}
