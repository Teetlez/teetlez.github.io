package edu.unh.cs.cs619.bulletzone.ui.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;

import java.util.ArrayList;

public class LayerDrawableBuilder {
    private final Context context;
    ArrayList<Drawable> drawables = new ArrayList<>();

    public LayerDrawableBuilder(Context context) {
        this.context = context;
    }

    public void append(Drawable drawable) {
        drawables.add(drawable);
    }

    public void append(Integer id) {
        Drawable drawable = context.getDrawable(id);
        append(drawable);
    }

    public LayerDrawable build() {
        Drawable[] drawables = this.drawables.toArray(new Drawable[0]);
        return new LayerDrawable(drawables);
    }
}
