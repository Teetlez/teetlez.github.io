package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.app.Application;

import org.androidannotations.annotations.EBean;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import edu.unh.cs.cs619.bulletzone.model.GridCellFactory;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.model.Vehicle;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.adapter.GridAdapter;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
@EBean
@RunWith(MockitoJUnitRunner.class)
public class GridPollerTest {
    // Frames to test against, some noise is included
    int[][][] frames = {{
            {10041002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10021004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10011000, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 10000100, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 2000, 2000, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 3000, 0, 0, 1, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {10000, 10040902, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10021004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010902, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 10000010, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 3000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 11111, 0, 0, 0, 0, 0, 0, 0},
            {10031006, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 10040802, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020504, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010904, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 11111, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 10000001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 0, 10040702, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020104, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010804, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 5000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 10002, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 10003210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 0, 0, 10040602, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020014, 0, 0, 0, 0, 0, 0, 0, 10010706, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 21212, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031000, 10000123, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }};

    int[][] healthArray = {
            {100, 90, 90, 80, 70},
            {100, 100, 50, 10, 0},
            {100, 100, 100, 100, 100},
            {100, 90, 80, 70, 60}
    };

    int[][] dirArray = {
            {0, 2, 4, 4, 6},
            {4, 4, 4, 4, 4},
            {0, 6, 4, 2, 0},
            {2, 2, 2, 2, 2}
    };

    private GridAdapter gridAdapter;

    @Before
    public void setup() {
        GridCellFactory.reset();
        SimulationGrid.reset();
    }

    @Spy
    @InjectMocks
    private ClientActivity activity;

    @Mock
    private BulletZoneRestClient restClient;

    @Mock
    private Activity context;
    @Mock
    Application mockApplication;


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        // initialize adapter
        gridAdapter = new GridAdapter(context);

    }

    private void updateViews(int[][] array) {
        GridWrapper gridWrapper = new GridWrapper(array);
        gridWrapper.setTerrainGrid(new int[16][16]);
        gridAdapter.updateList(gridWrapper);
    }


    @Test
    public void getLife_newFrame_updatesLife() {
        SimulationGrid.getInstance().setUserId(1);
        int[][] board = new int[16][16];
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                board[i][j] = 0;
            }
        }
        // 1st cell has a tank id 1, 100 hp
        board[0][0] = 10011000;
        updateViews(board);
        int life = SimulationGrid.getInstance().getPlayerVehicle().getHP();
        board[0][0] = 0;
        board[1][1] = 10010992; // 99 hp
        updateViews(board);
        int newlife = SimulationGrid.getInstance().getPlayerVehicle().getHP();
        assertThat("HP should update", newlife != life);
        assertThat("HP should not be zero", newlife != 0);
    }

    @Test
    public void getFacing_newFrame_updatesFacing() {
        SimulationGrid.getInstance().setUserId(1);
        int[][] board = new int[16][16];
        for (int i = 0; i < 16; i++) {
            for (int j = 0; j < 16; j++) {
                board[i][j] = 0;
            }
        }
        // 1st cell has a tank id 1, 100 hp
        board[0][0] = 10011000;
        updateViews(board);
        int dir = SimulationGrid.getInstance().getPlayerVehicle().getDirection();
        board[0][0] = 0;
        board[1][1] = 10011002; // 99 hp
        updateViews(board);
        int newDir = SimulationGrid.getInstance().getPlayerVehicle().getDirection();
        assertThat("Direction should update", newDir != dir);
    }

    @Test
    // Check that when given frame1 it holds the correct positions for each tank/item
    public void updateList_takesInitialFrame_returnsCorrectPos() {
        updateViews(frames[0]);
        //check tankId = 1
        assert (((SimulationGrid.getInstance().getEntity(4 * 16 + 8).getValue() % 10000000) / 10000) == 1);
        //check tankId = 2
        assert (((SimulationGrid.getInstance().getEntity(16).getValue() % 10000000) / 10000) == 2);
        //check tankId = 3
        assert (((SimulationGrid.getInstance().getEntity(15 * 16).getValue() % 10000000) / 10000) == 3);
        //check tankId = 4
        assert (((SimulationGrid.getInstance().getEntity(0).getValue() % 10000000) / 10000) == 4);
    }

    @Test
    //Check that the same functionality from the above test holds for all frames
    public void updateList_takesSeveralFrames_returnsCorrectPos() {
        updateViews(frames[0]);
        //check tankId = 1
        assert (SimulationGrid.getInstance()
                .getEntity((4 * 16) + 8).getValue() % 10000000) / 10000 == 1;
        //check tankId = 2
        assert (SimulationGrid.getInstance()
                .getEntity(16).getValue() % 10000000) / 10000 == 2;
        //check tankId = 3
        assert (((SimulationGrid.getInstance().getEntity(15 * 16).getValue() % 10000000) / 10000) == 3);
        //check tankId = 4
        assert (((SimulationGrid.getInstance().getEntity(0).getValue() % 10000000) / 10000) == 4);

        updateViews(frames[1]);
        //check tankId = 1
        assert ((((SimulationGrid.getInstance().getEntity((4 * 16) + 8).getValue()) % 10000000) / 10000) == 1);
        //check tankId = 2
        assert ((((SimulationGrid.getInstance().getEntity(2 * 16)).getValue() % 10000000) / 10000) == 2);
        //check tankId = 3
        assert ((((SimulationGrid.getInstance().getEntity(15 * 16).getValue()) % 10000000) / 10000) == 3);
        //check tankId = 4
        assert ((((SimulationGrid.getInstance().getEntity(1).getValue()) % 10000000) / 10000) == 4);
    }

    @Test
    //Check that when given frame1 it holds the correct direction for each tank
    public void updateList_takesInitialFrame_returnsCorrectDir() {
        updateViews(frames[0]);
        for (int i = 0; i < 4; i++) {
            SimulationGrid.getInstance().setUserId(i + 1);
            Vehicle playerVehicle = SimulationGrid.getInstance().getPlayerVehicle();
            assertThat((byte) playerVehicle.getDirection(), is((byte) dirArray[i][0]));
        }
    }

    @Test
    //Check that when given frame1 it holds the correct health for each tank
    public void updateList_takesInitialFrame_returnsCorrectHealth() {
        updateViews(frames[0]);
        for (int i = 0; i < 4; i++) {
            SimulationGrid.getInstance().setUserId(i + 1);
            assertThat(SimulationGrid.getInstance().getPlayerVehicle().getHP(),
                    is(healthArray[i][0]));
        }
    }
}