package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.model.image.ShipImages;
import edu.unh.cs.cs619.bulletzone.model.image.SoldierImages;
import edu.unh.cs.cs619.bulletzone.model.image.TankImages;
import edu.unh.cs.cs619.bulletzone.model.image.TruckImages;
import edu.unh.cs.cs619.bulletzone.model.image.VehicleImages;

/**
 * A child class of GridCell. This class represents a Vehicle object
 *
 */
public class Vehicle extends GridCell {
    public int direction;
    private VehicleImages vehicleImages;

    /**
     * Public constructor
     *
     * @param value value
     */
    public Vehicle(int value) {
        super(value);
        this.direction = value % 10;
        updateVehicleDirection(value / 10000000);
    }

    /**
     * Sets the vehicle images of the class to the appropriate image state.
     * @param vehicleTypeId Type of vehicle. Left most digit of value.
     */
    private void updateVehicleDirection(int vehicleTypeId) {
        switch (vehicleTypeId) {
            case 2:
                cell_type = "Truck";
                vehicleImages = new TruckImages();
                break;
            case 3:
                cell_type = "Ship";
                vehicleImages = new ShipImages();
                break;
            case 4:
                cell_type = "Soldier";
                vehicleImages = new SoldierImages();
                break;
            default: // Also 1
                cell_type = "Tank";
                vehicleImages = new TankImages();
        }
    }

    /**
     * Grabs the direction of vehicle
     *
     * @return int
     */
    public int getDirection() {
        return direction;
    }

    /**
     * Used to set the vehicle's direction
     *
     * @param direction int value
     */
    public void setDirection(int direction) {
        this.direction = direction;
    }

    /**
     * Returns the corresponding vehicle's direction and enemy image
     *
     * @param vehicleState int value based on what type of vehicle image should be applied
     * @return int
     */
    @Override
    public int getResourceID(int vehicleState) {

        // State 1 = neutral
        if(vehicleState == 1) {
            switch (direction) {
                case 2:
                    return vehicleImages.NeutralRight();
                case 4:
                    return vehicleImages.NeutralDown();
                case 6:
                    return vehicleImages.NeutralLeft();
                default: // Also 0
                    return vehicleImages.NeutralUp();
            }
        }

        // State 2 = enemy
        if (vehicleState == 2) {
            switch (direction) {
                case 2:
                    return vehicleImages.enemyRight();
                case 4:
                    return vehicleImages.enemyDown();
                case 6:
                    return vehicleImages.enemyLeft();
                default: // Also 0
                    return vehicleImages.enemyUp();
            }
        }

        // State: yourself
        switch (direction) {
            case 2:
                return vehicleImages.right();
            case 4:
                return vehicleImages.down();
            case 6:
                return vehicleImages.left();
            default: // Also 0
                return vehicleImages.up();
        }
    }
}
