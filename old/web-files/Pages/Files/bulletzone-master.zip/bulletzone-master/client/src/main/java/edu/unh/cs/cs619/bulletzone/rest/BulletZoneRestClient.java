package edu.unh.cs.cs619.bulletzone.rest;

import org.androidannotations.rest.spring.annotations.Delete;
import org.androidannotations.rest.spring.annotations.Get;
import org.androidannotations.rest.spring.annotations.Path;
import org.androidannotations.rest.spring.annotations.Post;
import org.androidannotations.rest.spring.annotations.Put;
import org.androidannotations.rest.spring.annotations.Rest;
import org.androidannotations.rest.spring.api.RestClientErrorHandling;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestClientException;

import edu.unh.cs.cs619.bulletzone.wrapper.BooleanWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GaragebayWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.LongWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.PermissionWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.StringArrayWrapper;

/** "http://stman1.cs.unh.edu:6191/games"
 * "http://10.0.0.145:6191/games"
 * http://10.0.2.2:8080/
 * Created by simon on 10/1/14.
 */

// Local server
//@Rest(rootUrl = "http://10.21.133.146:61922",
// cs619 dev server
@Rest(rootUrl = "http://stman1.cs.unh.edu:61902",
// cs619 production server
//@Rest(rootUrl = "http://stman1.cs.unh.edu:61922",

        converters = {StringHttpMessageConverter.class, MappingJackson2HttpMessageConverter.class}
        // TODO: disable intercepting and logging
        // , interceptors = { HttpLoggerInterceptor.class }
)

//    @Rest (converters = {StringHttpMessageConverter.class, MappingJackson2HttpMessageConverter.class})
public interface BulletZoneRestClient extends RestClientErrorHandling {
    void setRootUrl(String rootUrl);

    @Get("/games/account/getCategories")
    StringArrayWrapper getCategory();

    @Get("/games/account/getTypes/{category}")
    StringArrayWrapper getTypes(@Path String category);

    @Get("/games/{vehicleId}/score")
    LongWrapper getScore(@Path long vehicleId);

    @Get("/games/{pos}/stats")
    StringArrayWrapper getStats(@Path long pos);

    @Post("/games/join/{preset}")
    LongWrapper join(@Path int preset) throws RestClientException;

    @Get("/games/{playerId}")
    GridWrapper grid(@Path long playerId);

    @Put("/games/account/login/{name}/{password}")
    LongWrapper login(@Path String name, @Path String password);

    @Put("/games/account/register/{name}/{password}")
    BooleanWrapper register(@Path String name, @Path String password);

    @Put("/games/{vehicleId}/eject/{preset}")
    BooleanWrapper eject(@Path long vehicleId, @Path int preset);

    @Put("/games/{tankId}/move/{direction}")
    BooleanWrapper move(@Path long tankId, @Path byte direction);

    @Put("/games/{tankId}/turn/{direction}")
    BooleanWrapper turn(@Path long tankId, @Path byte direction);

    @Put("/games/{tankId}/fire/1")
    BooleanWrapper fire(@Path long tankId);

    @Delete("/games/{tankId}/leave")
    BooleanWrapper leave(@Path long tankId);

    @Get("/games/history/{playerId}/{timeStamp}")
    GridEventWrapper getHistory(@Path long playerId, @Path long timeStamp);

    //These are the API for the garagebay

    //This gets the garagebay from the server
    @Get("/garagebay/{userId}")
    GaragebayWrapper getGaragebay(@Path int userId);

    //Adds a frame to the garagebay
    @Put("/garagebay/{userId}/{nameOfFrame}")
    BooleanWrapper addContainertoUserGaragebay(@Path int userId, @Path String nameOfFrame);

    //Delete the frame from the garagebay
    @Delete("/garagebay/{userId}/{itemId}")
    BooleanWrapper removeContainerFromUserGaragebay(@Path int userId, @Path int itemId);

    //Puts an item to the container/frame
    @Put("/garagebay/container/{container}/{itemType}")
    BooleanWrapper addItemToContainer(@Path int container, @Path String itemType);

    //Deletes an item
    @Delete("/garagebay/container/{container}/{itemId}")
    BooleanWrapper removeItemFromContainer(@Path int container, @Path int itemId);

    //Item stat request
    @Get("/games/account/getItem/{itemTypeName}")
    StringArrayWrapper getItemStats(@Path String itemTypeName);

    //Permission commands

    //Gets permissions for a container
    @Get("/permission/{itemID}")
    PermissionWrapper getItemPermissions(@Path int itemID);

    //Sets a permission for the container
    @Put("/permission/{srcUserID}/{itemID}/{username}/{perm}")
    BooleanWrapper putItemPermission(@Path int srcUserID, @Path int itemID, @Path String username, @Path String perm);

    //Removes a permission from the container
    @Delete("/permission/{srcUserID}/{itemID}/{username}/{perm}")
    BooleanWrapper deleteItemPermission(@Path int srcUserID, @Path int itemID, @Path String username, @Path String perm);

    //Attempts a vehicle transfer
    @Put("/permission/{srcUserID}/{itemID}/{username}")
    BooleanWrapper transferOwnership(@Path int srcUserID, @Path int itemID, @Path String username);
}
