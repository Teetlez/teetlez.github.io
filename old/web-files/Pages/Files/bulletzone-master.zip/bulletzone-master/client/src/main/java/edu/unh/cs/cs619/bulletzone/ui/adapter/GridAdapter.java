package edu.unh.cs.cs619.bulletzone.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.SystemService;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.event.GridEvent;
import edu.unh.cs.cs619.bulletzone.model.GridCell;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;


@EBean
public class GridAdapter extends BaseAdapter {
    private final Object monitor = new Object();
    @SystemService
    protected LayoutInflater inflater;
    private SimulationGrid simGrid = SimulationGrid.getInstance();
    private Context context;

    /**
     * Empty constructor so the GridAdapter can be instantiated
     */
    public GridAdapter(Context c) {
        context = c;
    }

    /**
     * Updates the grid
     *
     * @param gridWrapper Wrapper containing the grid data.
     */
    public void updateList(GridWrapper gridWrapper) {
        synchronized (monitor) {
            simGrid.populateSimGrid(gridWrapper);
            ((Activity) context).runOnUiThread(this::notifyDataSetChanged);
        }
    }

    /**
     * Update grid event using changes retrieved from history endpoint.
     *
     * @param gridEvents Grid events
     */
    public void updateList(GridEvent[] gridEvents) {
        synchronized (monitor) {
            simGrid.updateSimGrid(gridEvents);
            ((Activity) context).runOnUiThread(this::notifyDataSetChanged);
        }
    }

    /**
     * Returns the number of grid cells.
     *
     * @return Number of grid cells.
     */
    @Override
    public int getCount() {
        return 16 * 16;
    }

    /**
     * Returns the value of the gridcell at designated location
     *
     * @param position Position of the desired grid cell
     * @return Value
     */
    @Override
    public GridCell getItem(int position) {
        return simGrid.getEntity(position);
    }

    public Object getItem(int row, int col) {
        return simGrid.getEntity((row * 16) + col);
    }

    /**
     * Returns the position.
     *
     * @param position Position the desired grid cell
     * @return Position
     */
    @Override
    public long getItemId(int position) {
        return simGrid.getEntity(position).getValue();
    }

    /**
     * This populates the grid cell with images.
     *
     * @param position    Position of the grid cell
     * @param convertView View to be changed
     * @param parent      Not used
     * @return The view
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.field_item, null);
        }

        if (convertView instanceof ImageView) {
            final GridCell currentEntity = simGrid.getEntity(position);
            final GridCell currentTerrain = simGrid.getTerrain(position);

            synchronized (monitor) {
                int vehicleID = (currentEntity.id / 10000) % 1000;
                boolean isEnemy = vehicleID != simGrid.getUserId();
                LayerDrawableBuilder builder = new LayerDrawableBuilder(context);
                if (isEnemy && currentEntity.id >= 10000000) {
                    builder.append(currentTerrain.getResourceID(0));
                    if (currentEntity.id > 0) {
                        builder.append(currentEntity.getResourceID(vehicleID == 0 ? 1 : 2));
                        builder.append(getHealthResource(currentEntity.hp, currentEntity.getMaxHP()));
                    }
                    ((ImageView) convertView).setImageDrawable(builder.build());
                } else {
                    builder.append(currentTerrain.getResourceID(0));
                    if (currentEntity.id > 0)
                        builder.append(currentEntity.getResourceID(0));
                    ((ImageView) convertView).setImageDrawable(builder.build());
                }
            }
        }

        // set layout params will change the size of the gridview
        convertView.setLayoutParams(new GridView.LayoutParams(75, 75));

        return convertView;
    }

    /**
     * Returns the correct health resource according to the approximate health percentage
     *
     * @param currentHealth What the entities current health is
     * @param maxHealth     The maximum amount of health the entity had
     * @return The resource image file for the entity's healthbar
     */
    private int getHealthResource(int currentHealth, int maxHealth) {
        int ratio = (int) (((double) currentHealth / (double) maxHealth) * 100);
        if (ratio > 50) {
            if (ratio > 88) {
                return R.drawable.healthbar_full;
            } else if (ratio > 75) {
                return R.drawable.healthbar_7_8;
            } else if (ratio > 63) {
                return R.drawable.healthbar_6_8;
            }
            return R.drawable.healthbar_5_8;
        } else {
            if (ratio > 38) {
                return R.drawable.healthbar_4_8;
            } else if (ratio > 25) {
                return R.drawable.healthbar_3_8;
            } else if (ratio > 13) {
                return R.drawable.healthbar_2_8;
            }
            return R.drawable.healthbar_1_8;
        }
    }
}
