package edu.unh.cs.cs619.bulletzone.model;

public class TankStatus {

    SimulationGrid simGrid;
    int tankId;

    public TankStatus(SimulationGrid grid, int playerId) {
        simGrid = grid;
        tankId = playerId;
    }

    public void setTankId(int tankId) {
        this.tankId = tankId;
    }

    /**
     * @return Life of the player tank.
     */
    public int getLife() {
        int lastKnown = simGrid.getLastKnown();
        return getPlayerHealth(lastKnown / 16, lastKnown % 16);

    }

    /**
     * Searches for the players tank given its last known location. If it isn't at that
     * location it searches the four surrounding cells for the tank. If the tank isn't located
     * at one of those 4 locations, the tank isn't found.
     *
     * @param row Row of the last known location of the player tank
     * @param col column of the last known location of the player tank
     * @return The value of the player tank if found, -1 otherwise
     */
    public int getPlayerHealth(int row, int col) {
        int health;
        if (simGrid.isPlayer(row % 16, col % 16)) {
            // Is the player at the last known location
            health = at(row, col).hp;
        } else if (simGrid.isPlayer(((row + 1) + 16) % 16, col)) {
            // Is the player east of last known location
            health = at(((row + 1) + 16) % 16,col).hp;
        } else if (simGrid.isPlayer(((row - 1) + 16) % 16, col)) {
            // Is the player west of last known location
            health = at(((row - 1) + 16) % 16, col).hp;
        } else if (simGrid.isPlayer(row, ((col + 1) + 16) % 16)) {
            // Is the player north of last known location
            health = at(row, ((col + 1) + 16) % 16).hp;
        } else if (simGrid.isPlayer(row, ((col - 1) + 16) % 16)) {
            // Is the player south of last known location
            health = at(row, ((col - 1) + 16) % 16).hp;
        } else {
            //Did not find the player tank
            health = -1;
        }
        return health;
    }

    private GridCell at(int row, int col) {
        return simGrid.getEntity(row, col);
    }

}
