package edu.unh.cs.cs619.bulletzone.model.image;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Represents state for vehicle type.
 *
 */
public class TruckImages implements VehicleImages {
    @Override
    public Integer up() {
        return R.drawable.truck_upward;
    }

    @Override
    public Integer down() {
        return R.drawable.truck_downward;
    }

    @Override
    public Integer left() {
        return R.drawable.truck_left;
    }

    @Override
    public Integer right() {
        return R.drawable.truck_right;
    }

    @Override
    public Integer enemyUp() {
        return R.drawable.enemy_truck_upward;
    }

    @Override
    public Integer enemyDown() {
        return R.drawable.enemy_truck_downward;
    }

    @Override
    public Integer enemyLeft() {
        return R.drawable.enemy_truck_left;
    }

    @Override
    public Integer enemyRight() {
        return R.drawable.enemy_truck_right;
    }

    @Override
    public Integer NeutralUp() {
        return R.drawable.neutral_truck_forward;
    }

    @Override
    public Integer NeutralDown() {
        return R.drawable.neutral_truck_downward;
    }

    @Override
    public Integer NeutralLeft() {
        return R.drawable.neutral_truck_left;
    }

    @Override
    public Integer NeutralRight() {
        return R.drawable.neutral_truck_right;
    }
}
