package edu.unh.cs.cs619.bulletzone.ui.controller;

import android.util.Log;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EBean;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;

/**
 * Game controller class that converts user input into their respective REST calls.
 */
@EBean
public class GameController {
    @RestService
    protected BulletZoneRestClient restClient;

    /**
     * Processes a user input event.
     * It will process the given request and call the correct endpoint.
     * @param button Button ID that is pressed.
     * @param facing Direction of the tank as a byte.
     * @param tankId ID of the player's tank.
     */
    public void processInput(Integer button, byte facing, long tankId) {
        switch (button) {
            case R.id.buttonFire:
                fire(tankId);
                break;
            case R.id.buttonUp:
            case R.id.buttonDown:
                asyncMove(tankId, (byte)((facing + (button == R.id.buttonUp ? 0 : 4)) % 8));
                break;
            case R.id.buttonLeft:
            case R.id.buttonRight:
                asyncTurn(tankId, (byte)((facing + (button == R.id.buttonLeft ? 6 : 2)) % 8));
                break;
            default:
                Log.e("GameController", "Unknown movement button id: " + button);
        }
    }

    /**
     * Send a move request to the server.
     * @param tankId Player's tank ID.
     * @param direction Absolute direction that the tank wants to move in.
     */
    @Background
    protected void asyncMove(long tankId, byte direction) {
        restClient.move(tankId, direction);
    }

    /**
     * Send a turn request to the server.
     * @param tankId Player's tank ID.
     * @param direction Absolute direction that the tank wants to turn to.
     */
    @Background
    protected void asyncTurn(long tankId, byte direction) {
        restClient.turn(tankId, direction);
    }

    /**
     * Send a fire request to the server.
     * @param tankId Player's tank ID.
     */
    @Background
    protected void fire(long tankId) {
        restClient.fire(tankId);
    }

    /**
     * Send a eject request to the server
     * @param vehicleId the vehicle's ID
     */
    @Background
    public void eject(long vehicleId, int preset) {
        restClient.eject(vehicleId, preset);
    }
}
