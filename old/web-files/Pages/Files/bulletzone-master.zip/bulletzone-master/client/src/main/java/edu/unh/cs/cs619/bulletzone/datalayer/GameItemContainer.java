package edu.unh.cs.cs619.bulletzone.datalayer;

import java.util.Collection;
import java.util.HashSet;

public class GameItemContainer extends GameItem {
    protected String name;
    protected GameItem[] containedItems;

    public GameItem[] getItems() { return containedItems;}

    public String getName() { return name; }
}
