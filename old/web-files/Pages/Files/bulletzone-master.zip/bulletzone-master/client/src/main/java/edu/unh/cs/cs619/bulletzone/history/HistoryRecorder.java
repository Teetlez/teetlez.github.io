package edu.unh.cs.cs619.bulletzone.history;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;

import com.squareup.otto.Subscribe;

import org.androidannotations.annotations.AfterInject;
import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.LinkedList;
import java.util.Queue;

import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.GridEvent;
import edu.unh.cs.cs619.bulletzone.event.GridHistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.GridUpdateEvent;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.wrapper.HistoryWrapper;

/**
 * Runs in the background recording changes in gridEvents. Has a max storage
 * time of 3 minutes.
 */
@EBean
public class HistoryRecorder {

    private static final String TAG = "Recorder";
    protected final Object lock = new Object();
    // The queue of commands that will be applied to the snapshot in order
    protected final Queue<HistoryCommand> commands;
    // Starting frame to apply all commands to
    protected final HistorySnapshot snapshot;
    @Bean
    BusProvider busProvider;
    // Whether or not the initial frame has been stored
    boolean initialFrame = false;
    // Current number of frames
    private int frames = 0;

    public HistoryRecorder() {
        commands = new LinkedList<>();
        snapshot = new HistorySnapshot();
    }

    /**
     * Subscribes recorder to event bus
     */
    public void start() {
        busProvider.getEventBus().register(this);
    }

    /**
     * Unsubscribes recorder to event bus
     */
    private void stop() {
        busProvider.getEventBus().unregister(this);
    }

    @AfterInject
    protected void afterInject() {
        start();
        Log.d(TAG, "injected recorder");
    }

    /**
     * Intercepts events from the poller in order to store the history
     *
     * @param event The event sent by the poller
     */
    @Subscribe
    @Background
    public void onUpdateGrid(GridHistoryUpdateEvent event) {
        synchronized (lock){
            addChanges(event.gw.getGrid());
        }
    }

    /**
     * Intercepts initial grid from the poller in order to store as a snapshot
     * the snapshot will only be stored if there isn't already a current snapshot
     * present
     *
     * @param event The grid sent by the poller
     */
    @Subscribe
    @Background
    public void onUpdateGrid(GridUpdateEvent event) {
        synchronized (lock) {
            if (!initialFrame) {
                initialFrame = snapshot.setGrid(event.gw.getGrid());
                snapshot.setTerrain(event.gw.getTerrainGrid());
                Log.d(TAG, "got initial Frame");
            }
        }
    }

    /**
     * Adds the list of new commands to the existing list. Updates the current
     * frame to the frame stored by gw. Limits the queue of commands from exceeding
     * 1800 frames (100 ms per frame, 10 frames per second, 180 seconds * 10 frames).
     *
     * @param gridEvents The list of update events to add
     */
    protected void addChanges(GridEvent[] gridEvents) {
        // Get the list of commands and add to existing list, update sliding frame
        if (initialFrame) {
            Queue<HistoryCommand> newCommands = makeDiff(gridEvents);
            commands.addAll(newCommands);
        }
        if (++frames > 1800) {
            snapshot.apply(commands.poll());
            while (!commands.isEmpty() && commands.peek().isCurrentFrame()) {
                snapshot.apply(commands.poll());
            }
        }
    }

    /**
     * Saves the current history as a Serialized HistoryWrapper object, returns true if
     * successful, otherwise false.
     *
     * @param context The context of the application calling save
     */
    public void save(Context context) {
        ((Activity) context).runOnUiThread(this::stop);
        synchronized (lock) {
            if (initialFrame) {
                HistoryWrapper savedHistory =
                        new HistoryWrapper(snapshot, commands, SimulationGrid.getInstance().getUserId());
                try {
                    // Open file to write object to
                    FileOutputStream fos = context.openFileOutput("savedHistory", Context.MODE_PRIVATE);
                    ObjectOutputStream os = new ObjectOutputStream(fos);
                    // Write HistoryWrapper object
                    os.writeObject(savedHistory);
                    os.close();
                    fos.close();
                    Log.d(TAG, "History saved successfully!");
                    Log.d(TAG, "Stored " + commands.size() + " commands");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                clear();
            } else {
                Log.d(TAG, "no beginning frame found");
            }
        }
    }

    /**
     * Resets recorder to clear state
     */
    public void clear() {
        Log.d(TAG, "cleared history recording");
        // Reset history
        commands.clear();
        snapshot.clear();
        initialFrame = false;
    }

    /**
     * Loops through the list of GridEvents and stores them as GridCommands.
     * If there are no changes, a dummy commands is added with it's newFrameFlag set.
     *
     * @param gridEvents A list of changes since the last request
     * @return The difference between the two frames as a queue of commands
     */
    @NonNull
    private Queue<HistoryCommand> makeDiff(GridEvent[] gridEvents) {
        Queue<HistoryCommand> changes = new LinkedList<>();
        // Loop through arrays
        int tempPos;
        for (GridEvent gridEvent : gridEvents) {
            tempPos = gridEvent.getPosition();
            changes.add(new HistoryCommand(tempPos / 16, tempPos % 16, gridEvent.getEntity(), gridEvent.getTerrain()));
        }
        // Add dummy frame if no changes occurred
        if (changes.isEmpty()) {
            if (commands.isEmpty()) {
                changes.add(new HistoryCommand(0, 0, snapshot.getGrid()[0][0], snapshot.getTerrainGrid()[0][0]));
            } else {
                HistoryCommand temp = commands.peek();
                changes.add(new HistoryCommand(temp.getRow(), temp.getCol(), temp.getEntity(), temp.getTerrain()));
            }
        }
        changes.element().setNewFrame(true);
        return changes;
    }

    // Used for testing
    public HistoryWrapper getSave() {
        synchronized (lock) {
            return new HistoryWrapper(snapshot, commands, SimulationGrid.getInstance().getUserId());
        }
    }
}
