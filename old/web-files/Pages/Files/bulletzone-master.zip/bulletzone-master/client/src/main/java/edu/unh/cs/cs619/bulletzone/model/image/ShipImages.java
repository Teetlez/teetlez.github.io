package edu.unh.cs.cs619.bulletzone.model.image;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Represents state for vehicle type.
 *
 */
public class ShipImages implements VehicleImages {
    @Override
    public Integer up() {
        return R.drawable.boat_upward;
    }

    @Override
    public Integer down() {
        return R.drawable.boat_downward;
    }

    @Override
    public Integer left() {
        return R.drawable.boat_left;
    }

    @Override
    public Integer right() {
        return R.drawable.boat_right;
    }

    @Override
    public Integer enemyUp() {
        return R.drawable.enemy_boat_upward;
    }

    @Override
    public Integer enemyDown() {
        return R.drawable.enemy_boat_downward;
    }

    @Override
    public Integer enemyLeft() {
        return R.drawable.enemy_boat_left;
    }

    @Override
    public Integer enemyRight() {
        return R.drawable.enemy_boat_right;
    }

    @Override
    public Integer NeutralUp() {
        return R.drawable.neutral_boat_forward;
    }

    @Override
    public Integer NeutralDown() {
        return R.drawable.neutral_boat_downward;
    }

    @Override
    public Integer NeutralLeft() {
        return R.drawable.neutral_boat_left;
    }

    @Override
    public Integer NeutralRight() {
        return R.drawable.neutral_boat_right;
    }
}
