package edu.unh.cs.cs619.bulletzone.wrapper;

/**
 * Created by simon on 10/1/14.
 */
public class GridWrapper {
    private int[][] grid;
    private int[][] terrainGrid;

    private long timeStamp;

    public GridWrapper() {
    }

    public GridWrapper(int[][] grid) {
        this.grid = grid;
    }

    public GridWrapper(int[][] grid, int[][] terrainGrid) {
        this.grid = grid;
        this.terrainGrid = terrainGrid;
    }

    public int[][] getGrid() {
        return this.grid;
    }

    public void setGrid(int[][] grid) {
        this.grid = grid;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public int[][] getTerrainGrid() {
        return terrainGrid;
    }

    public void setTerrainGrid(int[][] terrainGrid) {
        this.terrainGrid = terrainGrid;
    }
}
