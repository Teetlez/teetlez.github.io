package edu.unh.cs.cs619.bulletzone.ui.controller;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EBean;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.adapter.StringGridAdapter;

/**
 * Controller that handles
 */
@EBean
public class SelectionController {
    @RestService
    protected BulletZoneRestClient restClient;

    GameItem[] list;

    public int retrieveVehicleID(int index) {
        return list[index].getItemID();
    }

    /**
     * Retrieves the list from the server and then updates the view
     * @param id playerId
     * @param gridAdapter Gridadapter that's going to be updated
     */
    @Background
    public void updateList(long id, StringGridAdapter gridAdapter) {
        list = restClient.getGaragebay((int) id).getItems();
        String[] result = new String[list.length];

        for (int i = 0; i < list.length; i++) {
            result[i] = list[i].getTypeName() + " " + list[i].getItemID();
        }

        gridAdapter.setStringArray(result);
    }

    /**
     * Controller version of adding a tank
     * @param id player id
     * @param gridAdapter Grid adapter to be updated
     */
    @Background
    public void addTank(long id, StringGridAdapter gridAdapter) {
        boolean check = restClient.addContainertoUserGaragebay((int) id, "Standard tank frame").isResult();

        if (check) {
            updateList(id, gridAdapter);
        } else {
            int purposelyFail = 1/0;
        }
    }

    /**
     * Controller version of adding a ship
     * @param id player id
     * @param gridAdapter Grid adapter to be updated
     */
    @Background
    public void addShip(long id, StringGridAdapter gridAdapter) {
        boolean check = restClient.addContainertoUserGaragebay((int) id, "Standard ship frame").isResult();

        if (check) {
            updateList(id, gridAdapter);
        } else {
            int purposelyFail = 1/0;
        }
    }

    /**
     * Controller version of adding a truck
     * @param id PlayerId
     * @param gridAdapter Grid adapter to be updated
     */
    @Background
    public void addTruck(long id, StringGridAdapter gridAdapter) {
        boolean check = restClient.addContainertoUserGaragebay((int) id, "Standard truck frame").isResult();

        if (check) {
            updateList(id, gridAdapter);
        } else {
            int purposelyFail = 1/0;
        }
    }

    /**
     * Controller version of adding a battlesuit
     * @param id playerid
     * @param gridAdapter Grid adapter to be updated
     */
    @Background
    public void addBattleSuit(long id, StringGridAdapter gridAdapter) {
        boolean check = restClient.addContainertoUserGaragebay((int) id, "Standard battle suit").isResult();

        if (check) {
            updateList(id, gridAdapter);
        } else {
            int purposelyFail = 1/0;
        }
    }

    /**
     * Controller version of resetting everything
     * @param id Player id
     * @param gridAdapter Grid adapter to be updated
     */
    @Background
    public void resetAll(long id, StringGridAdapter gridAdapter) {
        GameItem[] allVehicles = restClient.getGaragebay((int) id).getItems();
        for (GameItem allVehicle : allVehicles) {
            Boolean check = restClient.removeContainerFromUserGaragebay((int) id, allVehicle.getItemID()).isResult();
        }
        updateList(id, gridAdapter);
    }
}
