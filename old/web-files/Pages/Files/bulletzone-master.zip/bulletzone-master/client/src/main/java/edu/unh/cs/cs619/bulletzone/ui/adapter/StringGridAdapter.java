package edu.unh.cs.cs619.bulletzone.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class StringGridAdapter extends BaseAdapter {
    private Context mContext;
    private String[] print; //This is the string array that will be printed to text view

    /**
     * Constructor for grid adapter that uses strings
     *
     * @param c context
     */
    public StringGridAdapter(Context c) {
        mContext = c;
        print = new String[1];
    }

    /**
     * This function sets the string array that will be printed. Be sure that this is called
     * after the constructor since the constructor doesn't grab an array.
     */
    public void setStringArray(String[] array) {
        print = array;
        ((Activity) mContext).runOnUiThread(this::notifyDataSetChanged);
    }

    @Override
    public int getCount() {
        return print.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView textView;

        if (convertView == null) {
            textView = new TextView(mContext);
        } else {
            textView = (TextView) convertView;
        }

        textView.setText(print[position]);

        return textView;
    }
}
