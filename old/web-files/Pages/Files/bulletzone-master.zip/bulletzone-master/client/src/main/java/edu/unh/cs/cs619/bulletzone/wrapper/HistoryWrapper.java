package edu.unh.cs.cs619.bulletzone.wrapper;

import android.support.annotation.NonNull;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.Queue;

import edu.unh.cs.cs619.bulletzone.event.GridEvent;
import edu.unh.cs.cs619.bulletzone.history.HistoryCommand;
import edu.unh.cs.cs619.bulletzone.history.HistorySnapshot;

/**
 * A class used to store the history of a game
 */
public class HistoryWrapper implements Serializable {
    private int playerId;
    private double totalCommands;
    final private HistorySnapshot snapshot;
    private Queue<HistoryCommand> commands;

    public HistoryWrapper(HistorySnapshot initial, Queue<HistoryCommand> commands) {
        this.snapshot = initial;
        this.commands = commands;
        totalCommands = commands.size();
        playerId = -1;
    }
    public HistoryWrapper(HistorySnapshot initial, Queue<HistoryCommand> commands, int tankId) {
        this.snapshot = initial;
        this.commands = commands;
        totalCommands = commands.size();
        playerId = tankId;
    }

    /**
     * A basic iterator that applies all commands for a given snapshot
     * and returns the updated frame.
     *
     * @return The next frame of the history
     */
    public GridEvent[] next() {
        Queue<HistoryCommand> commandQueue = new LinkedList<>();
        commandQueue.add(commands.poll());
        while (hasNext() && commands.element().isCurrentFrame()) {
            commandQueue.add(commands.poll());
        }
        GridEvent[] events = new GridEvent[commandQueue.size()];
        int counter = 0;
        HistoryCommand temp;
        while (!commandQueue.isEmpty()){
            temp = commandQueue.poll();
            events[counter++] = new GridEvent((temp.getRow() * 16) + temp.getCol(), temp.getEntity(), temp.getTerrain());
        }
        return events;
    }

    /**
     * @return If the wrapper is able to return another history frame
     */
    public boolean hasNext() {
        return !commands.isEmpty();
    }

    /**
     * Used to determine how close to completion the wrapper is
     *
     * @return The percentage of commands that have been already applied
     */
    public double getProgress() {
        return (100 - ((commands.size() / totalCommands) * 100));
    }

    public HistorySnapshot getSnapshot() {
        return snapshot;
    }

    public int getId(){return playerId;}

    @NonNull
    @Override
    public String toString() {
        return (snapshot.toString() + commands.toString());
    }
}
