package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Stores data for vehicles, walls, bullets, and terrain
 */
public class GridCell {
    public int resource_ID;
    public int id;
    public int hp;
    public String cell_type;

    private int maxHP;

    /**
     * public constructor
     *
     * @param val value
     */
    public GridCell(int val) {
        this.resource_ID = R.drawable.grass;
        this.id = val;
        this.hp = 0;
        this.cell_type = "Empty Cell";
    }

    /**
     * Returns the value of the resource image
     *
     * @return int
     */
    public int getResourceID(int vehicleState) {
        return resource_ID;
    }

    /**
     * Be able to set a resource ID
     *
     * @param id a resource ID
     * @return int
     */
    public int setResourceID(int id) {
        return this.resource_ID = id;
    }

    /**
     * Returns the vehicleID value
     *
     * @return int
     */
    public int getValue() {
        return id;
    }

    /**
     * Returns the value of health points
     *
     * @return int
     */
    public int getHP() {
        return hp;
    }

    /**
     * Set the value of health points
     *
     * @param hp int
     */
    public void setHP(int hp) {
        this.hp = hp;
    }

    public int getMaxHP() {
        switch (id / 10000000) {
            case 2:
                return 15;
            case 3:
                return 120;
            case 4:
                return 6;
            default:
                return 100;
        }
    }

    /**
     * Returns the type (name) of the cell
     *
     * @return string
     */
    public String getCellType() {
        return cell_type;
    }

}
