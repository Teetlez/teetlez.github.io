package edu.unh.cs.cs619.bulletzone.model.image;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * Represents state for vehicle type.
 */
public class SoldierImages implements VehicleImages{
    @Override
    public Integer up() {
        return R.drawable.soldier_forward;
    }

    @Override
    public Integer down() {
        return R.drawable.soldier_downward;
    }

    @Override
    public Integer left() {
        return R.drawable.soldier_left;
    }

    @Override
    public Integer right() {
        return R.drawable.soldier_right;
    }

    @Override
    public Integer enemyUp() {
        return R.drawable.enemy_soldier_forward;
    }

    @Override
    public Integer enemyDown() {
        return R.drawable.enemy_soldier_downward;
    }

    @Override
    public Integer enemyLeft() {
        return R.drawable.enemy_soldier_left;
    }

    @Override
    public Integer enemyRight() {
        return R.drawable.enemy_soldier_right;
    }

    @Override
    public Integer NeutralUp() {
        return null;
    }

    @Override
    public Integer NeutralDown() {
        return null;
    }

    @Override
    public Integer NeutralLeft() {
        return null;
    }

    @Override
    public Integer NeutralRight() {
        return null;
    }
}
