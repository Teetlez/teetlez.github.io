package edu.unh.cs.cs619.bulletzone.rest;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.UiThread;
import org.androidannotations.rest.spring.annotations.RestService;

import java.util.Timer;
import java.util.TimerTask;

import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.GridHistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.GridUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.ScoreUpdateEvent;
import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.LongWrapper;

/**
 * Created by simon on 10/3/14.
 */
@EBean
public class GridPollerTask {
    private static final String TAG = "PollServer";
    private final Timer timer = new Timer();
    // Injected object
    @Bean
    BusProvider busProvider;
    @RestService
    BulletZoneRestClient restClient;
    private long timestamp;
    private long playerId = -1;

    @Background(id = "grid_poller_task")
    // TODO: disable trace
    // @Trace(tag="CustomTag", level=Log.WARN)
    public void doPoll() {
        // Pull the latest grid and set the timestamp
        // Timestamp needs to be synced with server, not by client
        // we don't care about client's time
        GridWrapper grid = restClient.grid(playerId);
        timestamp = grid.getTimeStamp();
        onGridUpdate(grid);

        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Poll the grid for history and give the last time we polled
                GridEventWrapper history = restClient.getHistory(playerId, timestamp);
                timestamp = history.getTimestamp();
                onGridUpdate(history);
                onScoreUpdate(restClient.getScore(playerId));
            }
        }, 100, 100);
    }

    /**
     * Signifies to update the score
     * @param score Score of the player
     */
    @UiThread
    public void onScoreUpdate(LongWrapper score) {
        busProvider.getEventBus().post(new ScoreUpdateEvent(score));
    }

    /**
     * Signifies to update the grid. Used only in initial grabbing of the grid.
     * @param gw grid wrapper that updates the grid
     */
    @UiThread
    public void onGridUpdate(GridWrapper gw) {
        busProvider.getEventBus().post(new GridUpdateEvent(gw));
    }

    /**
     * Signifies to update the grid. This is used in any instance after.
     * @param gw Grid Event Wrapper that updates the grid based on the event.
     */
    @UiThread
    public void onGridUpdate(GridEventWrapper gw) {
        busProvider.getEventBus().post(new GridHistoryUpdateEvent(gw));
    }

    /**
     * Sets the player Id.
     * @param playerId Id of the player
     */
    public void setPlayerId(long playerId) {
        this.playerId = playerId;
    }

    /**
     * Used to stop the poller.
     */
    public void clearTimer() {
        timer.cancel();
    }
}
