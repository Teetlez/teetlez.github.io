package edu.unh.cs.cs619.bulletzone.event;

import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;

public class GridHistoryUpdateEvent {
    public GridEventWrapper gw;

    public GridHistoryUpdateEvent(GridEventWrapper gw) {
        this.gw = gw;
    }
}
