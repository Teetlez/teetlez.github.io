package edu.unh.cs.cs619.bulletzone.ui;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.controller.GameController;

public class GameControllerTest {
    @InjectMocks
    GameController gameController;

    @Mock
    BulletZoneRestClient restClient;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    /**
     * Tests processing a backwards move.
     */
    @Test
    public void processInput_backwards_callsMoveDown() {
        gameController.processInput(R.id.buttonDown, (byte) 0, -1);
        Mockito.verify(restClient).move(-1, (byte) 4);
    }

    /**
     * Tests moving forwards when facing up.
     */
    @Test
    public void processInput_forwards_callsMoveUp() {
        gameController.processInput(R.id.buttonUp, (byte) 0, -1);
        Mockito.verify(restClient).move(-1, (byte) 0);
    }

    /**
     * Tests turning right when facing up.
     */
    @Test
    public void processInput_right_callsTurnRight() {
        gameController.processInput(R.id.buttonRight, (byte) 0, -1);
        Mockito.verify(restClient).turn(-1, (byte) 2);
    }

    /**
     * Tests turning left when facing up.
     */
    @Test
    public void processInput_left_callsTurnLeft() {
        gameController.processInput(R.id.buttonLeft, (byte) 0, -1);
        Mockito.verify(restClient).turn(-1, (byte) 6);
    }

    /**
     * Tests that it calls the correct functions to change direction clockwise.
     */
    @Test
    public void processInput_up_spinningRotates360Clockwise() {
        gameController.processInput(R.id.buttonRight, (byte) 0, -1);
        Mockito.verify(restClient).turn(-1, (byte) 2);
        gameController.processInput(R.id.buttonRight, (byte) 2, -1);
        Mockito.verify(restClient).turn(-1, (byte) 4);
        gameController.processInput(R.id.buttonRight, (byte) 4, -1);
        Mockito.verify(restClient).turn(-1, (byte) 6);
        gameController.processInput(R.id.buttonRight, (byte) 6, -1);
        Mockito.verify(restClient).turn(-1, (byte) 0);
    }

    /**
     * Tests that it calls the correct functions to change direction counter clockwise.
     */
    @Test
    public void processInput_up_spinningRotates360CounterClockwise() {
        gameController.processInput(R.id.buttonLeft, (byte) 0, -1);
        Mockito.verify(restClient).turn(-1, (byte) 6);
        gameController.processInput(R.id.buttonLeft, (byte) 6, -1);
        Mockito.verify(restClient).turn(-1, (byte) 4);
        gameController.processInput(R.id.buttonLeft, (byte) 4, -1);
        Mockito.verify(restClient).turn(-1, (byte) 2);
        gameController.processInput(R.id.buttonLeft, (byte) 2, -1);
        Mockito.verify(restClient).turn(-1, (byte) 0);
    }

    /**
     * Tests firing when pressing the fire button.
     */
    @Test
    public void processInput_fire_callsFire() {
        gameController.processInput(R.id.buttonFire, (byte) 0, -1);
        Mockito.verify(restClient).fire(-1);
    }
}