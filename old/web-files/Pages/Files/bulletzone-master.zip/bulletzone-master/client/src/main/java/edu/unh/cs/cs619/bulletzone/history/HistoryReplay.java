package edu.unh.cs.cs619.bulletzone.history;

import android.content.Context;
import android.os.SystemClock;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.UiThread;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.HistorySnapshotEvent;
import edu.unh.cs.cs619.bulletzone.event.HistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.HistoryWrapper;

/**
 * A class that runs in the background sending GridUpdateEvents in order to replay the
 * history of a previous game.
 */
@EBean
public class HistoryReplay {

    protected final Object lock = new Object();
    // Inject BusProvider
    @Bean
    BusProvider busProvider;
    private HistoryWrapper history;
    // The speed of events sent
    private byte replayMult;
    // The running state of the replay
    private Boolean isPaused = true;

    // The percent complete
    private double progress;

    public HistoryReplay() {
        replayMult = 1;
        history = null;
    }

    /**
     * Manually set the historyWrapper to replay instead of loading it from
     * a file. This is useful for adding imported replays from the server.
     *
     * @param importHistory an imported history wrapper
     */
    public void setReplay(HistoryWrapper importHistory) {
        replayMult = 1;
        history = importHistory;
    }

    /**
     * @param context The context of the application loading the saved history
     */
    public boolean load(Context context) {
        synchronized (lock) {
            try {
                FileInputStream fis = context.openFileInput("savedHistory");
                ObjectInputStream is = new ObjectInputStream(fis);
                history = (HistoryWrapper) is.readObject();
                is.close();
                fis.close();
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
            // Set the players id from the replay
            SimulationGrid.getInstance().setUserId(history.getId());
            // Send initial snapshot frame to listeners
            busProvider.getEventBus().post(
                    new HistorySnapshotEvent(
                            new GridWrapper(history.getSnapshot().getGrid(), history.getSnapshot().getTerrainGrid())));
            return true;
        }
    }

    /**
     * A process that runs in the background, sending updateEvents to listeners.
     * The events will continue to play until an activity has paused it, or has
     * run to completion.
     */
    @Background(id = "History_Replay_Task")
    public void play() {
        while (history.hasNext() && !isPaused) {
            synchronized (lock) {
                // Send new frame to listeners and update percent complete
                onHistoryUpdate(new GridEventWrapper(history.next()));
                progress = history.getProgress();
                // Pause when complete
                if (progress == 100) {
                    isPaused = true;
                }
            }
            // Update history every 100 ms, modified by the replay multiplier
            SystemClock.sleep(100 / replayMult);
        }
    }

    @UiThread
    public void onHistoryUpdate(GridEventWrapper ge) {
        synchronized (lock) {
            busProvider.getEventBus().post(new HistoryUpdateEvent(ge));
        }
    }

    public double getProgress() {
        return progress;
    }

    public void setReplayMult(byte speed) {
        replayMult = speed;
    }

    public void pauseToggle() {
        isPaused = !isPaused;
        play();
    }

    public boolean isPaused() {
        return isPaused;
    }

    public boolean hasHistory() {
        return history != null;
    }
}
