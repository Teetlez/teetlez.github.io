package edu.unh.cs.cs619.bulletzone;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.SeekBar;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.Click;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.NonConfigurationInstance;
import org.androidannotations.annotations.SeekBarProgressChange;

import edu.unh.cs.cs619.bulletzone.facade.HistoryFacade;

/**
 * Replays the last recorded game that the user had played. The user can choose the
 * replay speed from 0-5x, 0 obviously being paused. In addition, the user can also
 * restart the replay at any time.
 */
@EActivity(R.layout.activity_history)
public class HistoryActivity extends AppCompatActivity {

    @NonConfigurationInstance
    @Bean
    protected HistoryFacade historyFacade;

    @Override
    public void onDestroy() {
        super.onDestroy();
        historyFacade.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
    }

    // Updates the playback speed when changed by the user via the seekBar
    @SeekBarProgressChange(R.id.SpeedBar)
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        historyFacade.onProgressChange(progress, fromUser);
    }

    @Click(R.id.play_pause)
    public void onClickPlayPause(View v) {
        historyFacade.playPause();
    }

    @Click(R.id.reset)
    public void onClickReset(View v) {
        historyFacade.reset();
    }

    @Click(R.id.buttonLeave)
    @Background
    void leaveGame() {
        finish();
    }

    @Background
    void leaveAsync() {
        finish();
    }

}