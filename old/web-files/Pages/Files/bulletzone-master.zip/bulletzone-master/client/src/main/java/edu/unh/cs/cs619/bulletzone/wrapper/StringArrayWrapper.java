package edu.unh.cs.cs619.bulletzone.wrapper;

public class StringArrayWrapper {
    private String[] collection;

    public StringArrayWrapper(String[] input) {
        this.collection = input;
    }

    public StringArrayWrapper() {}

    public String[] getGrid() {
        return this.collection;
    }

    public void setGrid(String[] set) {
        this.collection = set;
    }

}