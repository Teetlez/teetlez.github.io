package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.adapter.StringGridAdapter;
import edu.unh.cs.cs619.bulletzone.ui.controller.SelectionController;

@EActivity(R.layout.vehicle_selection_activity)
public class VehicleSelectionActivity extends Activity {
    Context mContext;
    long playerId;
    GridView listOfVehiclesView;

    StringGridAdapter listOfVehiclesAdapter;
    SharedPreferences.Editor editor;

    @Bean
    SelectionController controller;

    @RestService
    BulletZoneRestClient restClient;

    /**
     * This creates the activity
     * @param savedInstanceState This is brought from previous states so that information is held.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Set the context for onitemclicklisteners
        mContext = this;

    }

    /**
     *  Creates the list of vehicles display
     */
    protected void vehicleListCreate(long id) {
        listOfVehiclesView = (GridView) findViewById(R.id.selectVehicleGridView);
        listOfVehiclesAdapter = new StringGridAdapter(this);
        listOfVehiclesView.setAdapter(listOfVehiclesAdapter);

        listOfVehiclesView.setOnItemClickListener((adapterView, view, i, l) -> {
            int editingVehicle = controller.retrieveVehicleID(i);
            Log.d("Vehicle to be Edited", Integer.toString(editingVehicle));
            Intent customize = new Intent(VehicleSelectionActivity.this, VehicleCustomizeActivity_.class);
            //This is the vehicle id that is going to be editing
            customize.putExtra("editNumber", editingVehicle);
            customize.putExtra("playerId", playerId);
            startActivity(customize);
        });
        updateList(id);
    }

    /**
     * Retrieves the list from the server and then processes them. Afterwards updates the display.
     * @param id PlayerId
     */
    protected void updateList(long id) {
        controller.updateList(id, listOfVehiclesAdapter);
    }

    /**
     * Add a tank to the garagebay and then updates the display.
     * @param id Player id
     */
    protected void addTank(long id) {
        try {
            controller.addTank(id, listOfVehiclesAdapter);
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to add a Tank", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Adds a ship to the garagebay and then updates the display
     * @param id playerId
     */
    protected void addShip(long id) {
        try {
            controller.addShip(id, listOfVehiclesAdapter);
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to add a Ship", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Adds a truck to the garagebay and then updates the display
     * @param id playerId
     */
    protected void addTruck(long id) {
        try {
            controller.addTruck(id, listOfVehiclesAdapter);
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to add a Truck", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Adds a battle suit to the garagebay and then updates display
     * @param id playerId
     */
    protected void addBattleSuit(long id) {
        try {
            controller.addBattleSuit(id, listOfVehiclesAdapter);
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to add a Battle Suit", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Deletes all vehicles inside of the garagebay. Good for resetting, mostly testing purposes.
     * @param id PlayerId
     */
    protected void resetAll(long id) {
        try {
            controller.resetAll(id, listOfVehiclesAdapter);
        } catch (Exception e) {
            Toast.makeText(mContext, "Failed to Delete all Vehicles", Toast.LENGTH_SHORT).show();
            updateList(id);
        }
        editor.putInt("currentId", -1);
        editor.putInt("currentBattleSuitId", -2);
        editor.apply();
    }

    @AfterViews
    protected void afterView() {
        Intent retrieve = getIntent();
        playerId = retrieve.getLongExtra("playerId", -1);
        Log.d("Player ID in Selection", Integer.toString((int) playerId));

        editor = getSharedPreferences("currentlySelected", MODE_PRIVATE).edit();

        //Initialize the vehicle list display.
        vehicleListCreate(playerId);

        //Buttons on the bottom part of the activity. Responsible for adding vehicles and resetting
        //all vehicles.
        Button newTank = findViewById(R.id.newTank);
        Button newShip = findViewById(R.id.newShip);
        Button newTruck = findViewById(R.id.newTruck);
        Button newBattleSuit = findViewById(R.id.newBattleSuit);
        Button resetAllVehicles = findViewById(R.id.resetAllVehicles);

        newTank.setOnClickListener(view -> addTank(playerId));

        newShip.setOnClickListener(view -> addShip(playerId));

        newTruck.setOnClickListener(view -> addTruck(playerId));

        newBattleSuit.setOnClickListener(view -> addBattleSuit(playerId));

        resetAllVehicles.setOnClickListener(view -> resetAll(playerId));
    }

    /**
     * On resume for updating the list in case of a delete
     */
    @Override
    public void onResume() {
        super.onResume();
        updateList(playerId);
    }
}
