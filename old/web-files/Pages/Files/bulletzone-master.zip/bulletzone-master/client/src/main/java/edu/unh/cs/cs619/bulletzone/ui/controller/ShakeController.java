package edu.unh.cs.cs619.bulletzone.ui.controller;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.event.ShakeListener;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;
import edu.unh.cs.cs619.bulletzone.ui.adapter.GridAdapter;

import static android.content.Context.SENSOR_SERVICE;

public class ShakeController {
    // The following objects are used for the shake detection
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private ShakeListener mShakeListener;
    private GameController gameController;
    private Context context;
    private GridAdapter mGridAdapter;
    private long tankId;


    public ShakeController(Context c, GameController g, GridAdapter grid, long t) {
        // ShakeListener initialization
        mSensorManager = (SensorManager) c.getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mShakeListener = new ShakeListener();

        context = c;
        gameController = g;
        mGridAdapter = grid;
        tankId = t;

        // Treat the shake event as a fire button press
        mShakeListener.setOnShakeListener(() -> gameController.processInput(R.id.buttonFire,
                (byte) SimulationGrid.getInstance().getPlayerVehicle().getDirection(),
                tankId));
    }

    public void registerShake() {
        mSensorManager.registerListener(mShakeListener, mAccelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    public void unregisterShake () {
        mSensorManager.unregisterListener(mShakeListener);
    }
}
