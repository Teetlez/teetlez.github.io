package edu.unh.cs.cs619.bulletzone.facade;

import android.app.Activity;
import android.content.Context;
import android.os.SystemClock;
import android.util.Log;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.otto.Subscribe;

import org.androidannotations.annotations.AfterInject;
import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.UiThread;
import org.androidannotations.annotations.ViewById;

import java.util.Locale;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.HistorySnapshotEvent;
import edu.unh.cs.cs619.bulletzone.event.HistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.history.HistoryReplay;
import edu.unh.cs.cs619.bulletzone.ui.adapter.GridAdapter;
import edu.unh.cs.cs619.bulletzone.ui.adapter.HPViewAdapter;

/**
 * Displays game grid from ClientActivity.
 */
@EBean
public class HistoryFacade {
    private static final String TAG = "ClientFacade";

    @Bean
    protected GridAdapter mGridAdapter;

    @ViewById(R.id.gridViewHistory)
    protected GridView gridView;

    @Bean
    protected BusProvider busProvider;

    @Bean
    HistoryReplay replay;

    @Bean
    HPViewAdapter hpAdapter;

    private Context context;

    /**
     * Constructor
     *
     * @param mContext context of ClientActivity
     */
    public HistoryFacade(Context mContext) {
        context = mContext;
    }

    /**
     * Otto has a limitation (as per design) that it will only find
     * methods on the immediate class type. As a result, if at runtime this instance
     * actually points to a subclass implementation, the methods registered in this class will
     * not be found. This immediately becomes a problem when using the AndroidAnnotations
     * framework as it always produces a subclass of annotated classes.
     * <p>
     * To get around the class hierarchy limitation, one can use a separate anonymous class to
     * handle the events.
     */

    @Subscribe
    @Background
    public void onUpdateGrid(HistorySnapshotEvent event) {
        mGridAdapter.updateList(event.gw);
        updateProgress();
        hpAdapter.updateHP();
    }

    @Subscribe
    @Background
    public void onUpdateGrid(HistoryUpdateEvent event) {
        mGridAdapter.updateList(event.gw.getGrid());
        updateProgress();
        hpAdapter.updateHP();
    }


    @AfterInject
    protected void afterInject() {
        busProvider.getEventBus().register(this);
        Log.d(TAG, "injected HistoryFacade");
    }

    @AfterViews
    protected void afterViewInjection() {
        load();
        SystemClock.sleep(500);
        gridView.setAdapter(mGridAdapter);
    }

    public void onDestroy() {
        busProvider.getEventBus().unregister(this);
    }

    protected void load() {
        if (!replay.load(context)) {
            Toast.makeText(context,
                    "Could not find history file to replay",
                    Toast.LENGTH_SHORT).show();
            ((Activity) context).finish();
        }
    }

    public void reset() {
        // Reloads the replay from file
        load();
        Toast.makeText(context,
                "Restarted history",
                Toast.LENGTH_SHORT).show();

        // Set the progress back to zero and update the pause state
        ((ProgressBar) ((Activity) context).findViewById(R.id.progressBar)).setProgress(0);
        updatePause();
    }

    @UiThread
    public void onProgressChange(int progress, boolean fromUser) {
        if (fromUser) {
            // sets the multiplier with progress + 1 as the progress count starts from 0
            replay.setReplayMult((byte) (progress + 1));
            ((TextView) ((Activity) context).findViewById(R.id.SpeedMult)).setText(
                    String.format(Locale.US, "%dx", progress + 1)
            );
        }
    }

    @UiThread
    public void playPause() {
        replay.pauseToggle();
        updatePause();
        ((TextView) ((Activity) context).findViewById(R.id.SpeedMult)).setText(String.format(Locale.US,
                "%dx", replay.isPaused() ? 0 :
                        ((SeekBar) ((Activity) context).findViewById(R.id.SpeedBar)).getProgress() + 1
        ));
        Toast.makeText(context,
                replay.isPaused() ? "Replay has been paused" : "Replay has been resumed",
                Toast.LENGTH_SHORT).show();
    }

    @UiThread
    protected void updatePause() {
        ((TextView) ((Activity) context).findViewById(R.id.play_pause)).setText(replay.isPaused() ? "PLAY" : "PAUSE");
    }

    // Updates the displayed progress bar
    @UiThread
    protected void updateProgress() {
        if (android.os.Build.VERSION.SDK_INT < 24) {
            ((ProgressBar)
                    ((Activity) context).findViewById(R.id.progressBar)).setProgress((int) replay.getProgress());
        } else {
            ((ProgressBar)
                    ((Activity) context).findViewById(R.id.progressBar)).setProgress((int) replay.getProgress(), true);
        }
    }

}
