package edu.unh.cs.cs619.bulletzone;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.rest.spring.annotations.RestService;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;

@EActivity(R.layout.register)
public class RegisterActivity extends Activity {

    @RestService
    BulletZoneRestClient restClient;

    private Boolean success = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Check for previous instance
        if (savedInstanceState != null) {
        } else {
        }

    }

    @AfterViews
    protected void afterViewInjection() {
        TextView registerView = (TextView)findViewById(R.id.registerTextView);

        registerView.setOnClickListener(new View.OnClickListener() {
            /**
             * When the register textview is clicked
             *
             * @param v view
             */
            @Background
            @Override
            public void onClick(View v) {

                EditText username = (EditText) findViewById(R.id.editTextUsername);
                EditText password = (EditText) findViewById(R.id.editTextPassword);

                String user =  username.getText().toString();
                String pass =  password.getText().toString();

                if (user.equals("")) {
                    toastMsg("Please enter a username.");
                } else if (pass.equals("")) {
                    toastMsg("Please enter a password.");
                } else {
                    setAccount(user, pass);
                }

            }
        });
    }

    /**
     * method to set an account with the inputted username and password
     *
     * @param username string
     * @param password string
     */
    @Background
    void setAccount(String username, String password) {
        success = restClient.register(username, password).isResult();

        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                if (success) {
                    toastMsg("Successfully registered");
                    finish();
                } else {
                    toastMsg("Failed to register");
                }
            }
        });
    }

    /**
     * Displays a toast message
     *
     * @param message string
     */
    private void toastMsg(String message) {
        Toast toast = Toast.makeText(this, message, Toast.LENGTH_LONG);
        toast.show();
    }

}

