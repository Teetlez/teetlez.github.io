package edu.unh.cs.cs619.bulletzone.event;

import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;

public class HistoryUpdateEvent {
    public GridEventWrapper gw;

    public HistoryUpdateEvent(GridEventWrapper gw) {
        this.gw = gw;
    }
}
