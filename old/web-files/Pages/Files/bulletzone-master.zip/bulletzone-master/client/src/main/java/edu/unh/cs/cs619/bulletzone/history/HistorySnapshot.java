package edu.unh.cs.cs619.bulletzone.history;

import android.support.annotation.NonNull;

import java.io.Serializable;
import java.util.Locale;

/**
 * A class used to store the initial state of a grid
 */
public class HistorySnapshot implements Serializable {
    private int[][] grid;
    private int[][] terrainGrid;

    /**
     * Applies a given command to a snapshot to update its state
     *
     * @param command the HistoryCommand applied to the snapshot
     */
    public void apply(HistoryCommand command) {
        if (command != null) {
            grid[command.getRow()][command.getCol()] = command.getEntity();
            terrainGrid[command.getRow()][command.getCol()] = command.getTerrain();
        }
    }

    /**
     * Copies the the given grid to the snapshot if there is no current snapshot
     *
     * @param grid snapshot of the grid to copy
     * @return true if grid was copied, false if a grid already exists
     */
    public boolean setGrid(@NonNull int[][] grid) {
        if (this.grid == null) {
            this.grid = new int[grid.length][];
            for (int i = 0; i < grid.length; i++) {
                this.grid[i] = new int[grid[i].length];
                System.arraycopy(grid[i], 0, this.grid[i], 0, grid[i].length);
            }
            return true;
        } else {
            return false;
        }

    }

    public void setTerrain(@NonNull int[][] grid) {
        if (terrainGrid == null) {
            terrainGrid = new int[grid.length][];
            for (int i = 0; i < grid.length; i++) {
                terrainGrid[i] = new int[grid[i].length];
                System.arraycopy(grid[i], 0, terrainGrid[i], 0, grid[i].length);
            }
        }
    }

    /**
     * deletes the current grid snapshot
     */
    public void clear() {
        grid = null;
        terrainGrid = null;
    }

    /**
     * @return Initial snapshot of the grid
     */
    public int[][] getGrid() {
        return grid;
    }

    public int[][] getTerrainGrid() {
        return terrainGrid;
    }

    @NonNull
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (int[] arr : grid) {
            builder.append("[ ");
            for (int i : arr) {
                builder.append(String.format(Locale.US, "%d ", i));
                builder.append(" ");
            }
            builder.append("]\n");
        }
        return builder.toString();
    }
}
