package edu.unh.cs.cs619.bulletzone.ui.controller;

import android.util.Log;

import org.androidannotations.annotations.Background;
import org.androidannotations.annotations.EBean;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.adapter.StringGridAdapter;
import edu.unh.cs.cs619.bulletzone.ui.adapter.VehicleEquipAdapter;
import edu.unh.cs.cs619.bulletzone.vehicleCustomize.StatRead;
import edu.unh.cs.cs619.bulletzone.wrapper.GaragebayWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.StringArrayWrapper;

/**
 * Garage bay controller that processes inputs.
 */
@EBean
public class GarageController {
    @RestService
    protected BulletZoneRestClient restClient;
    GaragebayWrapper garagebayWrapper;
    StatRead statreader;
    int vehicleId;
    int playerId;
    VehicleEquipAdapter vAdapter; //Equipment adapter of vehicle
    StringGridAdapter sAdapter; //stats of vehicle
    Boolean isRemoved;

    /**
     * Start up initalizing variables
     * @param vehicleId Id of the vehicle that is to be used
     * @param playerId Id of the player that is to be used
     * @param vAdapter Equip adapter
     * @param sAdapter Stat adapter
     */
    public void startUp(int vehicleId, int playerId, VehicleEquipAdapter vAdapter, StringGridAdapter sAdapter) {
        statreader = new StatRead();
        this.vehicleId = vehicleId;
        this.playerId = playerId;
        this.vAdapter = vAdapter;
        this.sAdapter = sAdapter;
        isRemoved = false;
    }

    /**
     * Sends an equip request to the server and then calls views to update
     * @param item Item to equip
     */
    @Background
    public void sendEquipRequest(String item) {
        restClient.addItemToContainer(vehicleId, item);
        updateVehicleObject();
    }

    /**
     * Updates the vehicle and related Views
     * Views are stats, and item equipped
     */
    @Background
    public void updateVehicleObject() {
        garagebayWrapper = restClient.getGaragebay(playerId);

        //Get the vehicle
        GameItem vehicle = getVehicleObject();

        //After getting the vehicle update the Equipment Adapter with a list of items.
        vAdapter.setVehicle(vehicle.getItems());

        //After setting items in the equip area now update stats.
        updateStatsAsync(vehicle, statreader, sAdapter);
    }

    /**
     * Returns the vehicle object for reference in the activity
     * @return vehicle object that is being currently edited
     */
    public GameItem getVehicleObject() {
        GameItem vehicleObject;
        for (int i = 0; i < garagebayWrapper.getItems().length; i++) {
            if (garagebayWrapper.getItems()[i].getItemID() == vehicleId) {
                vehicleObject = garagebayWrapper.getItems()[i];
                return vehicleObject;
            }
        }
        Log.d("ERROR", "Failed to find the vehicle");
        return null;
    }

    /**
     * This fetches items from a category and then updates the views
     * @param select String to be selected
     * @param gridAdapterItems Grid Adapter that is to be updated
     */
    @Background
    public void SelectCategoryAsync(String select, StringGridAdapter gridAdapterItems, StringArrayWrapper items) {
        items.setGrid(restClient.getTypes(select).getGrid());
        gridAdapterItems.setStringArray(items.getGrid());
    }

    /**
     * Fetches categories
     * @param gridAdapter The gridAdapter to take the categories
     */
    @Background
    public void retrieveCategoriesAsync(StringGridAdapter gridAdapter) {
        String[] categories = restClient.getCategory().getGrid();
        gridAdapter.setStringArray(categories);
    }

    /**
     * Updates stats of the vehicle. Controller version
     * @param vehicle vehicle to calculate stats of
     * @param statreader StatRead object that will be reading the stats and calculating them.
     * @param gridAdapter Grid adapter for the view.
     */
    @Background
    public void updateStatsAsync(GameItem vehicle, StatRead statreader, StringGridAdapter gridAdapter) {
        GameItem[] list; //list of items
        list = vehicle.getItems();
        final int count = list.length; //Number of items on the tank not including the frame

        //Holds the string arrays of the items
        //To access a string array just iterate through count
        String[][] hold = new String[99][];

        //Goes through the entire list of items grabbing each string array.
        for (int i = 0; i < count; i++) {
            hold[i] = restClient.getItemStats(list[i].getTypeName()).getGrid();
        }
        //Assign the last thing as a frame.
        hold[count] = restClient.getItemStats(vehicle.getTypeName()).getGrid();

        //Calculate stats
        for (int i = 0; i <= count; i++) {
            statreader.calculateStats(hold[i]);
        }

        statreader.finalCalculation();
        gridAdapter.setStringArray(statreader.stringArrayGrab());
    }

    /**
     * Removes current vehicle from the garagebay of the player it belongs to
     */
    @Background
    public void removeVehicle() {
        restClient.removeContainerFromUserGaragebay(playerId, vehicleId);
        isRemoved = true;
    }

    /**
     * This is to check if the vehicle is removed or not for exiting
     * @return vehicle remove status
     */
    public Boolean isRemoved() {
        return isRemoved;
    }

    /**
     * This sends an unequip request
     * @param unequip Item id that is going to be unequipped
     */
    @Background
    public void sendUnequipRequest(int unequip) {
        restClient.removeItemFromContainer(vehicleId, unequip);
        updateVehicleObject();
    }
}
