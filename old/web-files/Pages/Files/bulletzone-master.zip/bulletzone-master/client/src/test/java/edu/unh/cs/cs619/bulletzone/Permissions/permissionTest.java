package edu.unh.cs.cs619.bulletzone.Permissions;

import org.androidannotations.annotations.EBean;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.controller.PermissionController;
import edu.unh.cs.cs619.bulletzone.wrapper.PermissionWrapper;

import static org.mockito.Mockito.doReturn;

@EBean
@RunWith(MockitoJUnitRunner.class)
public class permissionTest {

    PermissionController pController;

    @Mock
    BulletZoneRestClient restClient;

    Map<String, Set<String>> isOwner;
    Map<String, Set<String>> allPermissions;
    Map<String, Set<String>> noPermissions;

    PermissionWrapper isOwnerWrapper;
    PermissionWrapper allPermissionsWrapper;
    PermissionWrapper noPermissionsWrapper;

    @Before
    public void setup() {
        allPermissions = new HashMap<>();
        isOwner = new HashMap<>();
        noPermissions = new HashMap<>();

        Set<String> setAllPermissions = new HashSet<>();

        pController = new PermissionController();

        setAllPermissions.add("Add");
        setAllPermissions.add("Remove");
        setAllPermissions.add("Transfer");

        allPermissions.put("1", setAllPermissions);

        Set<String> setIsOwner = new HashSet<>();
        setIsOwner.add("Owner");
        isOwner.put("1", setIsOwner);

        allPermissionsWrapper = new PermissionWrapper();
        isOwnerWrapper = new PermissionWrapper();
        noPermissionsWrapper = new PermissionWrapper();

        allPermissionsWrapper.setPermission(allPermissions);
        isOwnerWrapper.setPermission(isOwner);
        noPermissionsWrapper.setPermission(noPermissions);
    }

    @Test
    public void test_all_permissions() {
        restClient = Mockito.mock(BulletZoneRestClient.class);
        doReturn(allPermissionsWrapper).when(restClient).getItemPermissions(1);

        pController.permissionControllerTestSet(restClient);

        assert(pController.checkPermission("1", 1, "Add"));
        assert(pController.checkPermission("1", 1, "Remove"));
        assert(pController.checkPermission("1", 1, "Transfer"));
    }

    @Test
    public void test_is_owner() {
        restClient = Mockito.mock(BulletZoneRestClient.class);
        doReturn(isOwnerWrapper).when(restClient).getItemPermissions(1);

        pController.permissionControllerTestSet(restClient);

        assert(pController.checkPermission("1", 1, "Owner"));
        assert(pController.checkPermission("1", 1, "Add"));
        assert(pController.checkPermission("1", 1, "Remove"));
        assert(pController.checkPermission("1", 1, "Transfer"));
    }

    @Test
    public void test_no_permissions() {
        restClient = Mockito.mock(BulletZoneRestClient.class);
        doReturn(noPermissionsWrapper).when(restClient).getItemPermissions(1);

        pController.permissionControllerTestSet(restClient);

        assert(!pController.checkPermission("1", 1, "Owner"));
        assert(!pController.checkPermission("1", 1, "Add"));
        assert(!pController.checkPermission("1", 1, "Remove"));
        assert(!pController.checkPermission("1", 1, "Transfer"));
    }


}
