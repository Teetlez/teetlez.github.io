package edu.unh.cs.cs619.bulletzone.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;

public class VehicleEquipAdapter extends BaseAdapter {
    private Context mContext;
    private GameItem[] gameItems;

    /**
     * Constructor for a gridview that specifically is used to display vehicle equipments
     * @param c Context
     */
    public VehicleEquipAdapter(Context c) {
        mContext = c;
    }

    /**
     * Insert the vehicle frame that you want to grab the equipment from.
     * @param gameItems Use get items of the vehicle frame.
     */
    public void setVehicle(GameItem[] gameItems) {
        this.gameItems = gameItems;
        ((Activity) mContext).runOnUiThread(this::notifyDataSetChanged);
    }

    /**
     * Get length of the array that you want to display.
     * @return Length of the array.
     */
    @Override
    public int getCount() {
        return gameItems.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView textView;

        if (convertView == null) {
            textView = new TextView(mContext);
        } else {
            textView = (TextView) convertView;
        }

        textView.setText(gameItems[position].getTypeName());

        return textView;
    }


}
