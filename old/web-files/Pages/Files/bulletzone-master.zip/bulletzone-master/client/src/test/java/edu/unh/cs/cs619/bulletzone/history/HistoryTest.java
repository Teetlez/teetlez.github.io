package edu.unh.cs.cs619.bulletzone.history;

import android.app.Application;
import android.content.Context;

import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EBean;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.LinkedList;
import java.util.Queue;

import edu.unh.cs.cs619.bulletzone.event.BusProvider;
import edu.unh.cs.cs619.bulletzone.event.GridEvent;
import edu.unh.cs.cs619.bulletzone.event.GridHistoryUpdateEvent;
import edu.unh.cs.cs619.bulletzone.event.GridUpdateEvent;
import edu.unh.cs.cs619.bulletzone.wrapper.GridEventWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;
import edu.unh.cs.cs619.bulletzone.wrapper.HistoryWrapper;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@EBean
@RunWith(MockitoJUnitRunner.class)
public class HistoryTest {
    // Frames to test against, some noise is included
    int[][][] frames = {{
            {10041002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10021004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10011000, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 10000100, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 2000, 2000, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 3000, 0, 0, 1, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {10000, 10040902, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10021004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010902, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 2000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1000, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 10000010, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 3000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 11111, 0, 0, 0, 0, 0, 0, 0},
            {10031006, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 10040802, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020504, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010904, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 11111, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0},
            {0, 0, 0, 0, 0, 1000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 10000001, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031004, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 0, 10040702, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020104, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 10010804, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 5000, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2003010, 0, 0, 0, 0, 0, 10002, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 10003210, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031002, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }, {
            {0, 0, 0, 0, 10040602, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10020014, 0, 0, 0, 0, 0, 0, 0, 10010706, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 21212, 0, 0, 0, 2000, 1000, 1900, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {10031000, 10000123, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
    }};
    @Bean
    HistoryRecorder recorder;
    @Bean
    HistoryReplay replay;

    @Bean
    BusProvider busProvider;

    @Mock
    Context mockContext;
    @Mock
    Application mockApplication;

    HistoryWrapper savedHistory;

    GridEventWrapper[] changes = new GridEventWrapper[4];

    {
        for (int i = 1; i < 5; i++) {
            changes[i - 1] = getDiff(frames[i - 1], frames[i]);
        }
    }

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        when(mockContext.getApplicationContext()).thenReturn(mockApplication);
        recorder = HistoryRecorder_.getInstance_(mockContext);
        replay = HistoryReplay_.getInstance_(mockContext);
    }

    @After
    public void cleanup() {
        recorder.clear();
    }

    private void testXFrames(int num) throws InterruptedException {
        int size = 5;
        sendFrames(num);
        savedHistory = recorder.getSave();
        for (int i = 1; i < size; i++) {
            testEvents(savedHistory.next(), changes[i - 1].getGrid());
        }
    }

    private void testEvents(GridEvent[] control, GridEvent[] test) {
        for (int i = 0; i < control.length; i++) {
            assertThat("Position should be equal", test[i].getPosition(), is(control[i].getPosition()));
            assertThat("value should be equal", test[i].getEntity(), is(control[i].getEntity()));
        }
    }

    private void sendFrames(int num) throws InterruptedException {
        recorder.onUpdateGrid(new GridUpdateEvent(new GridWrapper(frames[0])));
        for (int i = 0; i < num; i++) {
            Thread.sleep(50);
            recorder.onUpdateGrid(new GridHistoryUpdateEvent(changes[i % 4]));
        }
    }

    /**
     * Loops through the two frames and stores any differences as a GridEvent.
     *
     * @param lastFrame The previously stored frame
     * @param newFrame  The next incomming frame
     * @return The difference between the two frames as a queue of commands
     */
    private GridEventWrapper getDiff(int[][] lastFrame, int[][] newFrame) {
        Queue<GridEvent> changes = new LinkedList<>();
        // Loop through both arrays
        for (int i = 0; i < lastFrame.length; i++) {
            for (int j = 0; j < lastFrame[i].length; j++) {
                // Add commands if different
                if (newFrame[i][j] != lastFrame[i][j]) {
                    changes.add(new GridEvent((i * 16) + j, newFrame[i][j]));
                }
            }
        }
        GridEvent[] changeArray = new GridEvent[changes.size()];
        int counter = 0;
        while (!changes.isEmpty()) {
            changeArray[counter++] = changes.poll();
        }
        return new GridEventWrapper(changeArray);
    }


    @Test
    public void history_RecordSingleFrame_StoresSnapshot() {
        recorder.onUpdateGrid(new GridUpdateEvent(new GridWrapper(frames[0])));
        savedHistory = recorder.getSave();
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        assertThat("Frames should be equal", savedHistory.getSnapshot().getGrid(), is(frames[0]));
    }

    @Test
    public void history_RecordOneFrame_StoresCorrectHistory() throws InterruptedException {
        sendFrames(1);
        Thread.sleep(100);
        savedHistory = recorder.getSave();
        testEvents(savedHistory.next(), changes[0].getGrid());

    }

    @Test
    public void history_RecordFewFrames_StoresCorrectHistory() throws InterruptedException {
        testXFrames(5);
    }

    @Test
    public void history_RecordSomeFrames_StoresCorrectHistory() throws InterruptedException {
        testXFrames(10);
    }

    @Test
    public void history_RecordManyFrames_StoresCorrectHistory() throws InterruptedException {
        testXFrames(15);
    }


    @Test
    public void history_RecordLottaFrames_StoresCorrectHistory() throws InterruptedException {
        testXFrames(100);
    }

}