package edu.unh.cs.cs619.bulletzone.history;

import android.support.annotation.NonNull;

import java.io.Serializable;
import java.util.Locale;

/**
 * A class used to store changes to a int grid, used for recording/replaying history
 */
public class HistoryCommand implements Serializable {
    private short pos;
    private int entity;
    private int terrain;

    // Flag for if this command is the beginning of a new frame
    private boolean isNewFrame;

    HistoryCommand(int row, int col, int newEntity, int newTerrain) {
        pos = (short) ((row * 16) + col);
        entity = newEntity;
        terrain = newTerrain;
        isNewFrame = false;
    }

    HistoryCommand(int row, int col, int newEntity) {
        pos = (short) ((row * 16) + col);
        entity = newEntity;
        terrain = -1;
        isNewFrame = false;
    }

    HistoryCommand(int row, int col, int newEntity, int newTerrain, boolean isNewFrame) {
        pos = (short) ((row * 16) + col);
        entity = newEntity;
        terrain = newTerrain;
        this.isNewFrame = isNewFrame;
    }

    public void setNewFrame(boolean b) {
        isNewFrame = b;
    }

    public int getEntity() {
        return entity;
    }

    public int getTerrain() {
        return terrain;
    }

    public int getRow() {
        return ((int) pos) / 16;
    }

    public int getCol() {
        return ((int) pos) % 16;
    }

    public boolean isCurrentFrame() {
        return !isNewFrame;
    }


    @NonNull
    @Override
    public String toString() {
        return String.format(Locale.US, "(%d, %d): %d", getCol(), getRow(), entity);
    }
}
