package edu.unh.cs.cs619.bulletzone.event;

import edu.unh.cs.cs619.bulletzone.wrapper.GridWrapper;

public class HistorySnapshotEvent {
    public GridWrapper gw;

    public HistorySnapshotEvent(GridWrapper gw) {
        this.gw = gw;
    }
}
