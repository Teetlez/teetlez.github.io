package edu.unh.cs.cs619.bulletzone.event;

public class GridEvent {
    private long timestamp;
    private int position;
    private int entity;
    private int terrain;

    /**
     * Class to represent changes made by actions on the board.
     * @param position Position in the grid to change.
     * @param entity The new value to set the grid to.
     */
    public GridEvent(int position, int entity) {
        this.timestamp = System.currentTimeMillis();
        this.position = position;
        this.entity = entity;
    }

    public GridEvent(int position, int entity, int terrain) {
        this.timestamp = System.currentTimeMillis();
        this.position = position;
        this.entity = entity;
        this.terrain = terrain;
    }

    public GridEvent() {
        // Empty for spring
    }

    public int getTerrain() {
        return terrain;
    }

    public int getEntity() {
        return entity;
    }

    public int getPosition() {
        return position;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTerrain(int terrain) {
        this.terrain = terrain;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setEntity(int entity) {
        this.entity = entity;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
