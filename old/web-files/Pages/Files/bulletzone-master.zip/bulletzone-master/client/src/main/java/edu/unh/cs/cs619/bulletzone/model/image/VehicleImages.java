package edu.unh.cs.cs619.bulletzone.model.image;

public interface VehicleImages {
    Integer up();
    Integer down();
    Integer left();
    Integer right();
    Integer enemyUp();
    Integer enemyDown();
    Integer enemyLeft();
    Integer enemyRight();
    Integer NeutralUp();
    Integer NeutralDown();
    Integer NeutralLeft();
    Integer NeutralRight();
}
