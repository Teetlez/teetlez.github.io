package edu.unh.cs.cs619.bulletzone.ui.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.EBean;
import org.androidannotations.annotations.UiThread;

import java.util.Locale;

import edu.unh.cs.cs619.bulletzone.R;
import edu.unh.cs.cs619.bulletzone.model.SimulationGrid;

@EBean
public class HPViewAdapter {
    private Context context;
    private ProgressBar healthBar;
    private TextView healthText;

    public HPViewAdapter(Context context){
        this.context = context;
    }

    @AfterViews
    protected void AfterInjectViews(){
        healthBar = ((Activity) context).findViewById(R.id.healthBar);
        healthText = ((Activity) context).findViewById(R.id.healthText);
    }

    /**
     * Updates the health bar, health bar color, and health percentage text
     */
    public void updateHP() {
        int hp = SimulationGrid.getInstance().getPlayerHP();
        setProgress(hp);
        setProgressColor(getHPColor(hp));
        setHealthText(String.format(Locale.US, "%d%%", hp));
    }

    /**
     * Sets the health text for the health bar
     *
     * @param string what the text should display
     */
    @UiThread
    protected void setHealthText(String string) {
        healthText.setText(string);
    }

    /**
     * Sets the health bar amount from 0-100%
     *
     * @param progress the percentage amount that the health bar is filled
     */
    @UiThread
    protected void setProgress(int progress) {
        if (android.os.Build.VERSION.SDK_INT < 24) {
            healthBar.setProgress(progress);
        } else {
            healthBar.setProgress(progress, true);
        }
    }

    /**
     * Sets what color the health bar should be
     *
     * @param color The hex value of the desired color
     */
    @UiThread
    protected void setProgressColor(int color) {
        healthBar.setProgressTintList(ColorStateList.valueOf(color));
    }

    /**
     * Gets the correct color for the health bar depending on the amount of health left.
     * 100 to 67 -> Green
     * 66 to 33 -> Yellow
     * 32 to 0 -> Red
     *
     * @param hp the percentage of health
     * @return the color of the health bar in hex
     */
    private int getHPColor(int hp) {
        if (hp >= 67) return Color.GREEN;
        else if (hp >= 33) return Color.YELLOW;
        else return Color.RED;
    }
}
