package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.rest.spring.annotations.RestService;

import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.controller.PermissionController;

import static java.lang.System.exit;

@EActivity(R.layout.main_menu_activity)
public class MainMenuActivity extends Activity {
    public long playerId;

    SharedPreferences pref;
    String userName;
    int vehicleId;
    int battleSuitId;

    @Bean
    PermissionController pController;

    @RestService
    BulletZoneRestClient restClient;

    /**
     * This creates the activity
     *
     * @param savedInstanceState This is brought from previous states so that information is held.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent retrieve = getIntent();

        pref = getSharedPreferences("currentlySelected", MODE_PRIVATE);

        playerId = retrieve.getLongExtra("playerId", -1);
        if (playerId == -1) {
            Log.d("ERROR", "Was somehow able to login with an invalid playerId.");
            exit(-1);
        }
    }

    @AfterViews
    void afterViews() {
        //Start Game button
        Button startGame = findViewById(R.id.startGame);
        startGame.setOnClickListener(view -> {
            Log.d("BUTTON", "Start Game");

            userName = pref.getString("userName", "");
            vehicleId = pref.getInt("currentId", -1);
            battleSuitId = pref.getInt("currentBattleSuitId", -1);

            if (!pController.checkPermission(userName, vehicleId, "Use")) {
                Toast.makeText(MainMenuActivity.this, "You do not have permission to use this vehicle", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!pController.checkPermission(userName, vehicleId, "Use")) {
                Toast.makeText(MainMenuActivity.this, "You do not have permission to use this battle suit", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent ClientActivity = new Intent(MainMenuActivity.this, ClientActivity_.class);
            startActivity(ClientActivity);
        });

        //Customize Vehicle button
        Button customize = findViewById(R.id.customizeVehicle);
        customize.setOnClickListener(view -> {
            Log.d("BUTTON", "Tank Change");

            Intent customizeTank = new Intent(MainMenuActivity.this, VehicleSelectionActivity_.class);
            customizeTank.putExtra("playerId", playerId);
            startActivity(customizeTank);

        });

        //Replay History button
        Button replayHistory = findViewById(R.id.replayHistory);
        replayHistory.setOnClickListener(view -> {
            Log.d("BUTTON", "Replay History");

            Intent history = new Intent(MainMenuActivity.this, HistoryActivity_.class);
            startActivity(history);
        });

        //Login different Account button
        Button accountLogin = findViewById(R.id.loginRegister);
        accountLogin.setOnClickListener(view -> {
            Log.d("BUTTON", "Account Management");
                Intent login = new Intent(MainMenuActivity.this, LoginActivity_.class);
                startActivity(login);
        });
    }

    /**
     * This is called before destroying the view to save information
     *
     * @param savedInstanceState Stuff to be saved
     */
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {

        super.onSaveInstanceState(savedInstanceState);
    }
}
