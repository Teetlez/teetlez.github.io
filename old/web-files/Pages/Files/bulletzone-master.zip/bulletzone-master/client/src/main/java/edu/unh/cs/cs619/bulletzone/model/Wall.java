package edu.unh.cs.cs619.bulletzone.model;

import edu.unh.cs.cs619.bulletzone.R;

/**
 * A child class of GridCell. This class represents a Wall object
 *
 */
public class Wall extends GridCell {
    public Boolean destroyable;

    /**
     *  Constructor
     *
     * @param val value of Vehicle
     */
    public Wall(int val) {
        super(val);

        if (val == 1000) {
            destroyable = false;
            resource_ID = R.drawable.indestructiblewall;
            hp = 0;
            cell_type = "Indestructible Wall";
        }
        else {
            destroyable = true;
            resource_ID = R.drawable.wall;
            hp = val - 1000;
            cell_type = "Destructible Wall";
        }
    }

    /**
     * Be able to check if the wall is destroyable or not
     *
     * @return boolean
     */
    public Boolean isDestroyable() {
        return destroyable;
    }
}
