package edu.unh.cs.cs619.bulletzone;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.rest.spring.annotations.RestService;

import java.util.Arrays;

import edu.unh.cs.cs619.bulletzone.datalayer.GameItem;
import edu.unh.cs.cs619.bulletzone.rest.BulletZoneRestClient;
import edu.unh.cs.cs619.bulletzone.ui.adapter.StringGridAdapter;
import edu.unh.cs.cs619.bulletzone.ui.adapter.VehicleEquipAdapter;
import edu.unh.cs.cs619.bulletzone.ui.controller.GarageController;
import edu.unh.cs.cs619.bulletzone.ui.controller.PermissionController;
import edu.unh.cs.cs619.bulletzone.wrapper.StringArrayWrapper;

@EActivity(R.layout.vehicle_customize)
public class VehicleCustomizeActivity extends Activity {
    StringGridAdapter gridAdapterCategories;
    GridView gridViewCategories;
    String[] categories;
    Context mContext;

    SharedPreferences pref;
    SharedPreferences.Editor editor;

    long playerId;
    int vehicleId;

    String userName;

    StringGridAdapter gridAdapterItems;
    GridView gridViewItems;
    StringArrayWrapper items;

    VehicleEquipAdapter gridAdapterEquipped;
    GridView gridViewEquipped;

    GridView statsView;
    StringGridAdapter gridAdapterStatsView;

    @RestService
    BulletZoneRestClient restClient;

    int initialize;

    @Bean
    GarageController gController;

    @Bean
    PermissionController pController;

    /**
     * This gets the categories needed from the server
     */
    void retrieveCategoriesAsync() {
        try {
            gController.retrieveCategoriesAsync(gridAdapterCategories);
            categories = new String [5];
            categories[0] = "Frame";
            categories[1] = "Weapon";
            categories[2] = "Generator";
            categories[3] = "Engine";
            categories[4] = "Drive";

        } catch (Exception e) {
            Log.d("EXCEPTION IS", Arrays.toString(e.getStackTrace()));
        }
    }

    /**
     * This is called by the listener to show the items for a category.
     * Needs to set the category too.
     * @param select Selected category
     */
    void SelectCategoryAsync(String select) {
        try {
            //Get the items here
            gController.SelectCategoryAsync(select, gridAdapterItems, items);

        } catch (Exception e) {
            Log.d("EXCEPTION IS", Arrays.toString(e.getStackTrace()));
        }
    }

    /**
     * This creates the activity
     * @param savedInstanceState This is brought from previous states so that information is held.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Set the context for onitemclicklisteners
        mContext = this;

    }

    /**
     * Initializes the garagebay.
     */
    protected void initializeGarageBay() {
        makeEquipAdapter();
        makeStatAdapter();
        gController.startUp(vehicleId, (int) playerId, gridAdapterEquipped, gridAdapterStatsView);
        gController.updateVehicleObject();
    }

    /**
     * This is the constructor for the grid adapter specifically for equipment
     * that is current attached to the tank.
     */
    void makeEquipAdapter() {
        //Display for currently equipped. Can be used to unequip items.
        gridViewEquipped = (GridView) findViewById(R.id.currentEquipped);
        gridAdapterEquipped = new VehicleEquipAdapter(this);
        GameItem[] firstArray = new GameItem[0];
        gridAdapterEquipped.setVehicle(firstArray);
        gridViewEquipped.setAdapter(gridAdapterEquipped);

        //This listens for unequip requests by clicking on the menu.
        gridViewEquipped.setOnItemClickListener((adapterView, view, i, l) -> {
            if (!pController.checkPermission(userName, vehicleId, "Remove")) {
                Toast.makeText(mContext, "You do not have permission to remove items", Toast.LENGTH_SHORT).show();
                return;
            }
            int unequip = gController.getVehicleObject().getItems()[i].getItemID();
            gController.sendUnequipRequest(unequip);
        });
    }

    /**
     * This is the constructor for the stat display.
     */
    void makeStatAdapter() {
        //Display for the stats of the current equipped items.
        statsView = (GridView) findViewById(R.id.tankStatGridView);
        gridAdapterStatsView = new StringGridAdapter(this);
        statsView.setAdapter(gridAdapterStatsView);

        //Statreader for processing the stats.
        statsView.invalidateViews();
    }

    /**
     * Removes the currently opened vehicle from the garage bay and then returns you to the
     * selection activity
     * @param Id Vehicle Id that is to be removed
     */
    protected void removeVehicle(int Id) {

        Log.d("Before Delete Vehicle:", Integer.toString(pref.getInt("currentId", -1)));
        Log.d("Before delete Suit:", Integer.toString(pref.getInt("currentBattleSuitId", -2)));
        if (pref.getInt("currentId", -1) == Id) {
            editor.putInt("currentId", -1);
            editor.apply();
        }

        if (pref.getInt("currentBattleSuitId", -2) == vehicleId) {
            editor.putInt("currentBattleSuitId", -2);
            editor.apply();
        }
        Toast.makeText(mContext, "Successfully Deleted!", Toast.LENGTH_SHORT).show();
        Log.d("After Delete Vehicle:", Integer.toString(pref.getInt("currentId", -1)));
        Log.d("After delete Suit:", Integer.toString(pref.getInt("currentBattleSuitId", -2)));
        while (!gController.isRemoved()) {
            SystemClock.sleep(500);
        }
        finish();
    }

    @AfterViews
    protected void afterView() {
        Intent retrieve = getIntent();

        playerId = retrieve.getLongExtra("playerId", -1);
        vehicleId = retrieve.getIntExtra("editNumber", -1);
        Log.d("Editing Number is", Integer.toString(vehicleId));
        initializeGarageBay();
        gController.updateVehicleObject();

        //First time starting the activity which means that the
        //garagebay needs to initialize the gridadapter.
        initialize = 0;

        Log.d("PlayerId", Integer.toString((int) playerId));

        //Note that the preferences (outer box) is currentlySelected for its key while
        //the currently selected vehicle is "selectedVehicle"
        pref = getSharedPreferences("currentlySelected", MODE_PRIVATE);

        userName = pref.getString("userName", "");

        //This keeps track of the stored information like currently selected vehicle.
        editor = getSharedPreferences("currentlySelected", MODE_PRIVATE).edit();

        //Set up the Grid adapter for categories
        gridViewCategories = (GridView) findViewById(R.id.customizeView);
        gridAdapterCategories = new StringGridAdapter(this);
        gridViewCategories.setAdapter(gridAdapterCategories);

        //Get the categories for the grid adapter
        retrieveCategoriesAsync();

        //Set up the grid adapter for items
        gridViewItems = (GridView) findViewById(R.id.itemsGridView);
        gridAdapterItems = new StringGridAdapter(this);
        gridViewItems.setAdapter(gridAdapterItems);

        //Initial Construction
        items = new StringArrayWrapper();
        String[] initialize = new String[0];
        items.setGrid(initialize);
        gridAdapterItems.setStringArray(items.getGrid());
        gridViewItems.invalidateViews();

        //This is responsible for selecting the category.
        //This is the listener for the category grid view. I is the entry clicked.
        gridViewCategories.setOnItemClickListener((adapterView, view, i, l) -> SelectCategoryAsync(categories[i]));

        //This is responsible for listening to clicks from the item menu.
        //This is for if something in the inventory list is selected.
        gridViewItems.setOnItemClickListener((adapterView, view, i, l) -> {
            if (!pController.checkPermission(userName, vehicleId, "Add")) {
                Toast.makeText(mContext, "You do not have permission to add items", Toast.LENGTH_SHORT).show();
                return;
            }
            gController.sendEquipRequest(items.getGrid()[i]);
        });

        //Buttons at the bottom responsible for setting currently selected vehicle or tank
        Button setCurrentVehicle = findViewById(R.id.setCurrentVehicle);
        Button setCurrentBattleSuit = findViewById(R.id.setCurrentBattleSuit);
        Button eraseCurrentVehicle = findViewById(R.id.deleteVehicle);
        Button setPermissions = findViewById(R.id.permissionButton);

        setCurrentVehicle.setOnClickListener(view -> {
            if (!pController.checkPermission(userName, vehicleId, "Use")) {
                Toast.makeText(mContext, "You do not have permission to use this vehicle", Toast.LENGTH_SHORT).show();
                return;
            }

            editor.putInt("currentId", vehicleId);
            editor.apply();

            runOnUiThread(() -> Toast.makeText(mContext, "Vehicle Set!", Toast.LENGTH_SHORT).show());
        });

        setCurrentBattleSuit.setOnClickListener(view -> {
            if (!pController.checkPermission(userName, vehicleId, "Use")) {
                Toast.makeText(mContext, "You do not have permission to use this vehicle", Toast.LENGTH_SHORT).show();
                return;
            }
            if (gController.getVehicleObject().getTypeName().compareTo("Standard battle suit") == 0) {
                int test = pref.getInt("currentBattleSuitId", -2);
                Log.d("BATTLESUIT ID", Integer.toString(test));
                editor.putInt("currentBattleSuitId", vehicleId);
                editor.apply();

                runOnUiThread(() -> Toast.makeText(mContext, "Eject Suit Set!", Toast.LENGTH_SHORT).show());
            } else {
                runOnUiThread(() -> Toast.makeText(mContext, "This is not an Eject Suit!", Toast.LENGTH_SHORT).show());
            }
        });

        setPermissions.setOnClickListener(view -> {
            Intent permissions = new Intent(VehicleCustomizeActivity.this, PermissionActivity_.class);
            permissions.putExtra("vehicleId", vehicleId);
            permissions.putExtra("playerId", (int) playerId);
            startActivity(permissions);
        });

        eraseCurrentVehicle.setOnClickListener(view -> {
            if (!pController.checkPermission(userName, vehicleId, "Owner")) {
                Toast.makeText(mContext, "You do not have permission to delete this vehicle", Toast.LENGTH_SHORT).show();
                return;
            }
            gController.removeVehicle();
            removeVehicle(vehicleId);
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
