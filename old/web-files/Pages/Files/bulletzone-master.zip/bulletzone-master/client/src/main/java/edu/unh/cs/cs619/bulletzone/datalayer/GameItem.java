package edu.unh.cs.cs619.bulletzone.datalayer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GameItem {
    protected int itemID;
    protected String typeName;
    protected GameItem[] items;

    public int getItemID() {
        return itemID;
    }

    public GameItem[] getItems() {
        return items;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setItems(GameItem[] items) {
        this.items = items;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

}
