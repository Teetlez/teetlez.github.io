# What a healthy team looks like
* Criticism should be constructive
* Don't be afraid to call each other out
* Pull request comments should be actually useful and not to personal taste
* Make a comment if the code is going to be detrimental in the future
* Don't be afraid to ask for help
* Commit/push frequently (On your branch)
# How meetings will be scheduled and attended
* Every time after CS 620, Mondays or Wednesdays **(11am)**
* Live updates over the group chat message
# How commits/pushes should be handled
* Rebase off of master before merging
* Make branches for every time we fix a bug or make a new feature
* Small pull requests
* Branch for every issue
* **David N** will make sure that the project is tagged properly for grading
# Coding, naming, or commenting conventions
* Java doc explaining what everything does and variable purposes
# Who's responsible for testing what
* Everyone should be responsible for testing their own addition
* If someone starts to fall majorly behind other group members will help
# Who's responsible for updating project documents
* Everyone should be responsible for updating their own implementation
* Anything that is touched by a person, that person should make sure that the documentation is updated.
# Time expectations
* Finish everything by the second week
* Last week is spent testing/refining/debugging
# How questions on requirements are handled
* If you're responsible for it you should be the one asking the instructor